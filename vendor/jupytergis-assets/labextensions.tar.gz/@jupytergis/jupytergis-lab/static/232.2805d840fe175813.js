"use strict";(self.rspackChunk_jupytergis_jupytergis_lab=self.rspackChunk_jupytergis_jupytergis_lab||[]).push([[232],{7004(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`:root,
:host {
  --ol-background-color: white;
  --ol-accent-background-color: #F5F5F5;
  --ol-subtle-background-color: rgba(128, 128, 128, 0.25);
  --ol-partial-background-color: rgba(255, 255, 255, 0.75);
  --ol-foreground-color: #333333;
  --ol-subtle-foreground-color: #666666;
  --ol-brand-color: #00AAFF;
}

.ol-box {
  box-sizing: border-box;
  border-radius: 2px;
  border: 1.5px solid var(--ol-background-color);
  background-color: var(--ol-partial-background-color);
}

.ol-mouse-position {
  top: 8px;
  right: 8px;
  position: absolute;
}

.ol-scale-line {
  background: var(--ol-partial-background-color);
  border-radius: 4px;
  bottom: 8px;
  left: 8px;
  padding: 2px;
  position: absolute;
}

.ol-scale-line-inner {
  border: 1px solid var(--ol-subtle-foreground-color);
  border-top: none;
  color: var(--ol-foreground-color);
  font-size: 10px;
  text-align: center;
  margin: 1px;
  will-change: contents, width;
  transition: all 0.25s;
}

.ol-scale-bar {
  position: absolute;
  bottom: 8px;
  left: 8px;
}

.ol-scale-bar-inner {
  display: flex;
}

.ol-scale-step-marker {
  width: 1px;
  height: 15px;
  background-color: var(--ol-foreground-color);
  float: right;
  z-index: 10;
}

.ol-scale-step-text {
  position: absolute;
  bottom: -5px;
  font-size: 10px;
  z-index: 11;
  color: var(--ol-foreground-color);
  text-shadow: -1.5px 0 var(--ol-partial-background-color), 0 1.5px var(--ol-partial-background-color), 1.5px 0 var(--ol-partial-background-color), 0 -1.5px var(--ol-partial-background-color);
}

.ol-scale-text {
  position: absolute;
  font-size: 12px;
  text-align: center;
  bottom: 25px;
  color: var(--ol-foreground-color);
  text-shadow: -1.5px 0 var(--ol-partial-background-color), 0 1.5px var(--ol-partial-background-color), 1.5px 0 var(--ol-partial-background-color), 0 -1.5px var(--ol-partial-background-color);
}

.ol-scale-singlebar {
  position: relative;
  height: 10px;
  z-index: 9;
  box-sizing: border-box;
  border: 1px solid var(--ol-foreground-color);
}

.ol-scale-singlebar-even {
  background-color: var(--ol-subtle-foreground-color);
}

.ol-scale-singlebar-odd {
  background-color: var(--ol-background-color);
}

.ol-unsupported {
  display: none;
}

.ol-viewport,
.ol-unselectable {
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
}

.ol-viewport canvas {
  all: unset;
  overflow: hidden;
}

.ol-viewport {
  touch-action: pan-x pan-y;
}

.ol-selectable {
  -webkit-touch-callout: default;
  -webkit-user-select: text;
  -moz-user-select: text;
  user-select: text;
}

.ol-grabbing {
  cursor: -webkit-grabbing;
  cursor: -moz-grabbing;
  cursor: grabbing;
}

.ol-grab {
  cursor: move;
  cursor: -webkit-grab;
  cursor: -moz-grab;
  cursor: grab;
}

.ol-control {
  position: absolute;
  background-color: var(--ol-subtle-background-color);
  border-radius: 4px;
}

.ol-zoom {
  top: .5em;
  left: .5em;
}

.ol-rotate {
  top: .5em;
  right: .5em;
  transition: opacity .25s linear, visibility 0s linear;
}

.ol-rotate.ol-hidden {
  opacity: 0;
  visibility: hidden;
  transition: opacity .25s linear, visibility 0s linear .25s;
}

.ol-zoom-extent {
  top: 4.643em;
  left: .5em;
}

.ol-full-screen {
  right: .5em;
  top: .5em;
}

.ol-control button {
  display: block;
  margin: 1px;
  padding: 0;
  color: var(--ol-subtle-foreground-color);
  font-weight: bold;
  text-decoration: none;
  font-size: inherit;
  text-align: center;
  height: 1.375em;
  width: 1.375em;
  line-height: .4em;
  background-color: var(--ol-background-color);
  border: none;
  border-radius: 2px;
}

.ol-control button::-moz-focus-inner {
  border: none;
  padding: 0;
}

.ol-zoom-extent button {
  line-height: 1.4em;
}

.ol-compass {
  display: block;
  font-weight: normal;
  will-change: transform;
}

.ol-touch .ol-control button {
  font-size: 1.5em;
}

.ol-touch .ol-zoom-extent {
  top: 5.5em;
}

.ol-control button:hover,
.ol-control button:focus {
  text-decoration: none;
  outline: 1px solid var(--ol-subtle-foreground-color);
  color: var(--ol-foreground-color);
}

.ol-zoom .ol-zoom-in {
  border-radius: 2px 2px 0 0;
}

.ol-zoom .ol-zoom-out {
  border-radius: 0 0 2px 2px;
}

.ol-attribution {
  text-align: right;
  bottom: .5em;
  right: .5em;
  max-width: calc(100% - 1.3em);
  display: flex;
  flex-flow: row-reverse;
  align-items: center;
}

.ol-attribution a {
  color: var(--ol-subtle-foreground-color);
  text-decoration: none;
}

.ol-attribution ul {
  margin: 0;
  padding: 1px .5em;
  color: var(--ol-foreground-color);
  text-shadow: 0 0 2px var(--ol-background-color);
  font-size: 12px;
}

.ol-attribution li {
  display: inline;
  list-style: none;
}

.ol-attribution li:not(:last-child):after {
  content: " ";
}

.ol-attribution img {
  max-height: 2em;
  max-width: inherit;
  vertical-align: middle;
}

.ol-attribution button {
  flex-shrink: 0;
}

.ol-attribution.ol-collapsed ul {
  display: none;
}

.ol-attribution:not(.ol-collapsed) {
  background: var(--ol-partial-background-color);
}

.ol-attribution.ol-uncollapsible {
  bottom: 0;
  right: 0;
  border-radius: 4px 0 0;
}

.ol-attribution.ol-uncollapsible img {
  margin-top: -.2em;
  max-height: 1.6em;
}

.ol-attribution.ol-uncollapsible button {
  display: none;
}

.ol-zoomslider {
  top: 4.5em;
  left: .5em;
  height: 200px;
}

.ol-zoomslider button {
  position: relative;
  height: 10px;
}

.ol-touch .ol-zoomslider {
  top: 5.5em;
}

.ol-overviewmap {
  left: 0.5em;
  bottom: 0.5em;
}

.ol-overviewmap.ol-uncollapsible {
  bottom: 0;
  left: 0;
  border-radius: 0 4px 0 0;
}

.ol-overviewmap .ol-overviewmap-map,
.ol-overviewmap button {
  display: block;
}

.ol-overviewmap .ol-overviewmap-map {
  border: 1px solid var(--ol-subtle-foreground-color);
  height: 150px;
  width: 150px;
}

.ol-overviewmap:not(.ol-collapsed) button {
  bottom: 0;
  left: 0;
  position: absolute;
}

.ol-overviewmap.ol-collapsed .ol-overviewmap-map,
.ol-overviewmap.ol-uncollapsible button {
  display: none;
}

.ol-overviewmap:not(.ol-collapsed) {
  background: var(--ol-subtle-background-color);
}

.ol-overviewmap-box {
  border: 1.5px dotted var(--ol-subtle-foreground-color);
}

.ol-overviewmap .ol-overviewmap-box:hover {
  cursor: move;
}

.ol-overviewmap .ol-viewport:hover {
  cursor: pointer;
}
`,""]),e.d(r,{},{A:n})},2079(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a),s=e(8448),l=e(7004),d=e(5564),p=e(7365),c=e(5633),g=e(9606),m=e(8781),u=e(8367),b=e(4654),h=e(3301),j=e(1885),f=e(3629),v=e(9943),x=e(974),w=e(8179),y=e(2536),k=e(5436),z=e(2837),S=e(524),G=e(5872),I=e(2532),A=e(9836),C=e(6088),F=e(5362),M=e(7746),D=e(5891),T=e(4691),P=e(6746),W=e(2760),L=e(6187),O=e(4835),q=e(896),B=e(1399),_=e(5625),Y=e(9850),X=e(7305),H=e(3270),R=e(2981),N=e(1313),E=e(7549),J=e(8590),U=e(1345),V=e(5127),Q=e(9507),$=n()(i());$.i(s.A),$.i(l.A),$.i(d.A),$.i(p.A),$.i(c.A),$.i(g.A),$.i(m.A),$.i(u.A),$.i(b.A),$.i(h.A),$.i(j.A),$.i(f.A),$.i(v.A),$.i(x.A),$.i(w.A),$.i(y.A),$.i(k.A),$.i(z.A),$.i(S.A),$.i(G.A),$.i(I.A),$.i(A.A),$.i(C.A),$.i(F.A),$.i(M.A),$.i(D.A),$.i(T.A),$.i(P.A),$.i(W.A),$.i(L.A),$.i(O.A),$.i(q.A),$.i(B.A),$.i(_.A),$.i(Y.A),$.i(X.A),$.i(H.A),$.i(R.A),$.i(N.A),$.i(E.A),$.i(J.A),$.i(U.A),$.i(V.A),$.i(Q.A),$.push([o.id,`/* -----------------------------------------------------------------------------
| Copyright (c) Jupyter Development Team.
| Distributed under the terms of the Modified BSD License.
|---------------------------------------------------------------------------- */

/* JupyterLab modal dialogs (.jp-Dialog) use z-index: 10000, which sits above
   the notification toast container (react-toastify default: 9999). Without this
   override, error/info toasts are hidden behind the dialog backdrop while a
   dialog is open. Lift the toast container above the dialog. */
.Toastify__toast-container {
  z-index: 10001 !important;
}

.jgis-underline-indicator {
  position: relative;
  opacity: 0.7;
  padding: 0.25rem 0;
  cursor: pointer;
  text-decoration: none;
}

.jgis-underline-indicator::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 0;
  width: 0;
  height: 3px;
  transition:
    background-color 300ms ease-in,
    width 300ms ease-in,
    opacity 300ms ease-in;
  background-color: transparent;
}

.jgis-underline-indicator[data-state='active']::after {
  width: 100%;
  background-color: var(--jp-inverse-layout-color2);
}

.errors {
  color: var(--jp-warn-color0);
  font-weight: bold;
}

.jGIS-Toolbar-GroupName {
  font-size: var(--jp-ui-font-size0);
  padding-left: 3px;
}

/* Overwrite forms CSS */
.jGIS-property-panel .array-item-list {
  display: flex;
  background-color: var(--jp-layout-color0);
}

.jGIS-property-panel .rjsf .array-item:not(:last-child) {
  border-bottom: none;
  margin-bottom: unset;
  padding-bottom: unset;
}

.jGIS-property-panel .rjsf .array-item {
  flex: 1 0 0%;
  align-items: center;
}

.jGIS-property-panel .rjsf fieldset fieldset {
  padding-left: unset;
  border-left: none;
}

.jGIS-property-panel .rjsf .array-item-list:has(.field-array) {
  flex-direction: column;
}

.jp-gis-text-label {
  margin: 0;
  padding: 0;
  font-weight: bold;
  display: block;
  position: relative;
}

/*This is being upstreamed. Will remove once upstream's been fixed.*/
button.jp-mod-styled.jp-mod-accept {
  background-color: var(--jp-brand-color1) !important;
}

button.jp-mod-styled.jp-mod-reject {
  background-color: var(--jp-layout-color4) !important;
}

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

/* Height constrained to 0.5rem less than .jGIS-Mainview-Container */
.jgis-right-panel-container,
.jgis-left-panel-container {
  position: absolute;
  margin: 0.25rem;
  z-index: 40;
  max-height: calc(100% - 0.5rem);
  overflow-y: auto;
  border-radius: 8px;
  box-shadow:
    0 4px 8px 0 rgba(0, 0, 0, 0.2),
    0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.jgis-right-panel-container {
  width: 330px;
  right: 0;
}

.jgis-left-panel-container {
  width: 250px;
  left: 0;
}

/* Right-edge drag handle used to widen the left panel (see leftpanel.tsx). */
.jgis-left-panel-resize-handle {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 6px;
  cursor: ew-resize;
  z-index: 41;
}

.jgis-left-panel-resize-handle::after {
  content: '';
  position: absolute;
  top: 0;
  bottom: 0;
  right: 0;
  width: 2px;
  background: transparent;
  transition: background 120ms ease-in-out;
}

.jgis-left-panel-resize-handle:hover::after {
  background: var(--jp-brand-color1);
}

/* Mobile bottom sheet — merged panel only */
.jGIS-Mainview-Container.jgis-narrow .jgis-merged-panel-container {
  position: fixed;
  bottom: 16px;
  left: 0;
  right: 0;
  z-index: 1000;
  box-shadow: 0 -2px 8px rgba(0, 0, 0, 0.2);
  display: flex;
  flex-direction: column;
  height: 30vh;
}

/* Drag-to-resize handle */
.jGIS-Mainview-Container.jgis-narrow .jgis-resize-handle {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 24px;
  flex-shrink: 0;
  cursor: ns-resize;
}

.jGIS-Mainview-Container.jgis-narrow .jgis-resize-handle::before {
  content: '';
  width: 36px;
  height: 4px;
  border-radius: 2px;
  background-color: var(--jp-border-color1);
  opacity: 0.5;
}

/* Panel tabs fill the remaining height */
.jGIS-Mainview-Container.jgis-narrow
  .jgis-merged-panel-container
  .jgis-panel-tabs {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}

.jGIS-Mainview-Container.jgis-narrow
  .jgis-merged-panel-container
  .jgis-tabs-content[data-state='active'] {
  flex: 1;
  min-height: 0;
  height: unset;
  overflow-y: auto;
}

/* Tab list: natural-width tabs, horizontal scroll, thin scrollbar */
.jGIS-Mainview-Container.jgis-narrow
  .jgis-merged-panel-container
  .jgis-tabs-list {
  cursor: ns-resize;
  justify-content: flex-start;
  touch-action: pan-x;
  scrollbar-width: thin;
  scrollbar-color: var(--jp-border-color1) transparent;
}

.jGIS-Mainview-Container.jgis-narrow
  .jgis-merged-panel-container
  .jgis-tabs-list:active {
  cursor: ns-resize;
}

.jGIS-Mainview-Container.jgis-narrow
  .jgis-merged-panel-container
  .jgis-tabs-list::-webkit-scrollbar {
  height: 3px;
}

.jGIS-Mainview-Container.jgis-narrow
  .jgis-merged-panel-container
  .jgis-tabs-list::-webkit-scrollbar-track {
  background: transparent;
}

.jGIS-Mainview-Container.jgis-narrow
  .jgis-merged-panel-container
  .jgis-tabs-list::-webkit-scrollbar-thumb {
  background-color: var(--jp-border-color1);
  border-radius: 2px;
}

.jgis-icon-adjust {
  scale: 1.15;
}

.jgis-inline-icon {
  width: 1em;
  height: 1em;
}

.jgis-controls-toolbar {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: flex-end;
  gap: 0.5rem;
  position: absolute;
  bottom: 0.125rem;
  z-index: 1;
  padding: 0 0.125rem;
}

.jgis-controls-toolbar .ol-control,
.jgis-controls-toolbar .ol-scale-line,
.jgis-controls-toolbar .ol-full-screen {
  position: relative;
  top: unset;
  bottom: unset;
  left: unset;
  right: unset;
  margin: 0;
}

.jgis-controls-toolbar .ol-zoom {
  position: fixed;
  right: 0.125rem;
}

/* Move controls toolbar to top of map so it's not behind the bottom sheet */
.jGIS-Mainview-Container.jgis-narrow .jgis-controls-toolbar {
  top: 0.125rem;
  bottom: unset;
  align-items: flex-start;
}

body[data-notebook='specta']
  .jGIS-Mainview-Container.jgis-narrow
  .jgis-controls-toolbar {
  top: unset;
  bottom: 0.125rem;
  align-items: flex-end;
}

.jgis-vector-draw-controls {
  position: absolute;
  bottom: 1.25rem;
  right: 1.75rem;
  display: flex;
  align-items: center;
  padding: 0.375rem;
  background-color: color-mix(
    in srgb,
    var(--jp-layout-color0),
    transparent 50%
  );
  color: var(--jp-ui-font-color0);
  border-radius: 0.375rem;
  gap: 0.5rem;
  z-index: 9999;
}

.jGIS-Mainview-Container.jgis-narrow .jgis-panels-wrapper {
  position: fixed;
  top: 30px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 10px;
  margin: 0 5px;
  z-index: 1000;
  width: 60%;
}

.jGIS-Mainview-Container.jgis-narrow .jgis-left-panel-container,
.jGIS-Mainview-Container.jgis-narrow .jgis-right-panel-container {
  position: relative;
  margin: 0;
}

/* Fix for map in mobile specta view */
body[data-notebook='specta'] #main.jp-ThemedContainer {
  overflow: visible;
}

.jgis-center-content {
  text-align: center;
}

.jgis-button.jgis-bg-transparent {
  background-color: transparent;
}

.jgis-button.jgis-bg-transparent:hover {
  background-color: transparent;
}

.jgis-rotate-90 {
  rotate: 0deg;
  transition: rotate 150ms ease;
}

[data-slot='collapsible-trigger'][data-state='open'] .jgis-rotate-90 {
  rotate: 90deg;
}

[data-icon='inline-start'] {
  padding-right: 0.375rem;
}

[data-icon='inline-end'] {
  padding-left: 0.375rem;
}

.cm-editor {
  height: 100%;
}

.cm-scroller {
  overflow-y: auto;
  overflow-x: hidden;
}

svg[data-size='sm'] {
  width: 0.875rem;
  height: 0.875rem;
  flex-shrink: 0;
}

svg[data-size='md'] {
  width: 1rem;
  height: 1rem;
  flex-shrink: 0;
}

svg[data-size='lg'] {
  width: 1.25rem;
  height: 1.25rem;
  flex-shrink: 0;
}
`,""]),e.d(r,{},{A:$})},5564(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`/* -----------------------------------------------------------------------------
| Copyright (c) Jupyter Development Team.
| Distributed under the terms of the Modified BSD License.
|---------------------------------------------------------------------------- */

.jGIS-property-panel .rjsf .jp-select-wrapper select {
  background-image: unset;
}

/* Collapse the form-group row that contains our hidden field marker */
.jp-root .form-group:has(.jGIS-hidden-field) {
  display: none !important;
}

.jp-gis-object-properties-dialog .jp-Dialog-content {
  min-width: min(600px, 90vw);
  max-height: 80vh;
}

.jp-gis-object-properties-dialog .jp-Dialog-body {
  overflow: auto;
}
`,""]),e.d(r,{},{A:n})},9606(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jp-gis-filter-main {
  display: flex;
  flex-direction: column;
  padding: 10px;
  gap: 1rem;
}

.jp-gis-filter-list {
  display: flex;
  flex-direction: column;
}

.jp-gis-filter-button-container {
  display: flex;
  justify-content: space-between;
}

.jp-gis-filter-main > .jp-Dialog-button {
  width: fit-content;
  align-self: flex-end;
}

.jp-gis-logical-select {
  width: fit-content !important;
  padding: 0 8px !important;
  text-align: center;
}

.jp-gis-filter-select-container {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.jp-gis-filter-row {
  display: flex;
  justify-content: space-around;
  width: 100%;
  gap: 0.25rem;
}

.jp-gis-filter-row > select {
  text-transform: capitalize;
  padding: 0;
  text-align: center;
}

.jp-gis-filter-row > option {
  text-transform: capitalize;
  font-size: var(--jp-ui-font-size1);
}

.jp-gis-filter-row > button {
  color: var(--jp-ui-font-color0);
  background: none;
}

.jp-gis-filter-row > button:hover {
  color: var(--jp-warn-color-hover);
}

.jp-gis-filter-icon:hover {
  scale: 1.3;
  cursor: pointer;
}

.jp-gis-filter-icon > svg {
  height: 16px;
  width: 16px;
}
`,""]),e.d(r,{},{A:n})},2536(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-identify-wrapper {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.jgis-identify-card {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding: 0 0.5rem;
}

.jgis-identify-card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-weight: bold;
  font-size: var(--jp-ui-font-size1);
  cursor: pointer;
  line-height: 1.5rem;
  flex-grow: 1;
}

.jgis-identify-card-header-actions {
  display: flex;
  align-items: center;
  gap: 0.25rem;
}

.jgis-identify-content {
  display: flex;
  flex-direction: column;
  padding: 0.5rem 0.5rem 0 0.5rem;
}
`,""]),e.d(r,{},{A:n})},1378(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a),s=e(2079),l=n()(i());l.i(s.A),l.push([o.id,`/* -----------------------------------------------------------------------------
| Copyright (c) Jupyter Development Team.
| Distributed under the terms of the Modified BSD License.
|---------------------------------------------------------------------------- */
`,""]),e.d(r,{},{A:l})},2837(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-draw-custom-attributes-dialog {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.jgis-draw-custom-attributes-list {
  max-height: 16rem;
  overflow-y: auto;
}

.jgis-draw-custom-attributes-saved-row .jgis-attribute-col-key,
.jgis-draw-custom-attributes-saved-row .jgis-attribute-col-value {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.jgis-draw-custom-attributes-error {
  margin: 0;
  font-size: 0.875rem;
  color: var(--jp-error-color1);
}

.jgis-draw-custom-attributes-empty {
  margin: 0;
  padding: 0.25rem 0.375rem;
  font-size: 0.875rem;
  color: var(--jp-ui-font-color2);
}

.jgis-draw-custom-attributes-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.75rem;
}

.jgis-draw-custom-attributes-header-main {
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-width: 0;
}

.jgis-draw-custom-attributes-row {
  display: flex;
  justify-content: space-between;
}

.jgis-draw-custom-attributes-actions {
  display: flex;
  gap: 0.5rem;
}

.jgis-draw-custom-attributes-preset-save-collapse {
  overflow: hidden;
  max-height: 0;
  opacity: 0;
  pointer-events: none;
  transition:
    max-height 0.2s ease-out,
    opacity 0.2s ease-out;
}

.jgis-draw-custom-attributes-preset-save-collapse--open {
  max-height: 6rem;
  opacity: 1;
  pointer-events: auto;
}

.jgis-draw-custom-attributes-preset-save-row {
  margin-top: 0.25rem;
}

.jgis-draw-custom-attributes-preset-name-input {
  flex: 1 1 auto;
}

.jgis-draw-custom-attributes-presets-menu {
  width: min(18rem, 90vw);
}

.jgis-draw-custom-attributes-preset-item {
  justify-content: space-between;
}

.jgis-draw-custom-attributes-preset-name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
`,""]),e.d(r,{},{A:n})},7365(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jGIS-layerbrowser-FormDialog .jp-Dialog-header {
  padding: 0;
}

.jGIS-layerbrowser-FormDialog .jp-Dialog-content {
  width: calc(100% - 4rem);
  max-width: 100%;
  height: calc(100% - 2rem);
  max-height: 100%;
}

@media (max-width: 960px) {
  .jGIS-layerbrowser-FormDialog .jp-Dialog-content {
    width: 100%;
    height: 100%;
    margin: 0;
    border-radius: 0;
    padding: 0;
  }
}

.jGIS-layerbrowser-FormDialog form {
  padding: 10px;
}

.jGIS-customlayer-form {
  height: 100%;
  overflow: auto;
}

.jGIS-layer-browser-container * {
  box-sizing: border-box;
}

.jGIS-layer-browser-container {
  display: flex;
  flex-direction: column;
}

.jGIS-layer-browser-header-container {
  position: sticky;
  top: 0;
  z-index: 40;
  background-color: var(--jp-layout-color1);
}

.jGIS-layer-browser-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
  padding: 1rem 2rem;
}

.jGIS-layer-browser-header-text {
  padding-right: 1rem;
  font-weight: bold;
}

.jGIS-layer-browser-header-search-container {
  display: flex;
  align-items: center;
  flex-grow: 1;
  position: relative;
}

.jGIS-layer-browser-header-search-icon {
  position: absolute;
  top: 50%;
  left: 0.75rem;
  transform: translateY(-50%);
}

.jGIS-layer-browser-header-search {
  box-shadow: none;
  flex: 1 1 0%;
  height: 40px;
  padding: 1rem 2rem;
  padding-left: 2.5rem;
  background-color: transparent;
  border: 1px solid var(--jp-border-color1);
  border-radius: 8px;
  color: var(--jp-ui-font-color1);
}

.jGIS-layer-browser-grid {
  display: grid;
  gap: 1.25rem;
  grid-template-rows: 1fr;
  grid-template-columns: repeat(3, minmax(0px, 1fr));
  padding: 1rem 2rem;
}

@media (min-width: 1400px) {
  .jGIS-layer-browser-grid {
    grid-template-columns: repeat(5, minmax(0px, 1fr));
  }
}

@media (max-width: 960px) {
  .jGIS-layer-browser-grid {
    grid-template-columns: repeat(2, minmax(0px, 1fr));
    padding: 0.5rem;
    gap: 0.5rem;
  }

  .jGIS-layer-browser-header {
    padding: 0.5rem;
    gap: 8px;
  }

  .jGIS-layer-browser-categories {
    padding: 0 0.5rem;
    gap: 1rem;
  }
}

.jGIS-layer-browser-categories {
  display: flex;
  gap: 2rem;
  padding: 0 2rem;
  border-bottom: 2px solid var(--jp-border-color1);
}

.jGIS-layer-browser-category {
  position: relative;
  opacity: 0.7;
  padding: 0.25rem 0;
  cursor: pointer;
  text-decoration: none;
}

.jGIS-layer-browser-category::after {
  content: '';
  position: absolute;
  bottom: -2px;
  left: 0;
  width: 0px;
  height: 3px;
  transition:
    background-color 300ms ease-in,
    width 300ms ease-in,
    opacity 300ms ease-in;
  background-color: transparent;
}

.jGIS-layer-browser-category.jGIS-layer-browser-category-selected::after {
  width: 100%;
  background-color: var(--jp-inverse-layout-color2);
}

.jGIS-layer-browser-category.jGIS-layer-browser-category-selected {
  opacity: 1;
  font-weight: bold;
}

.jGIS-layer-browser-category.jGIS-layer-browser-category[data-state='active']::after {
  width: 100%;
  background-color: var(--jp-inverse-layout-color2);
}

.jGIS-layer-browser-category.jGIS-layer-browser-category[data-state='active'] {
  opacity: 1;
  font-weight: bold;
}

.jGIS-layer-browser-tile {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  position: relative;
  margin-top: 4px;
  padding: 8px;
  transition: transform 150ms ease-out;
  cursor: pointer;
  border: 1px solid var(--jp-border-color1);
  background-color: var(--jp-layout-color1);
  border-radius: 8px;
}

.jGIS-layer-browser-custom-tile {
  border: 1px solid var(--jp-border-color2);
  background-color: var(--jp-layout-color2);
}

.jGIS-layer-browser-tile:hover {
  box-shadow: var(--jp-layout-color2);
  transform: translateY(-4px);
  background-color: var(--jp-brand-color2);
}

.jGIS-layer-browser-tile-img-container {
  /* isolation: isolate; */
  /* border: medium; */
  /* background: transparent; */
  /* padding: 0px; */
  /* width: 100%; */
  aspect-ratio: 16 / 10;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  overflow: hidden;
  border-radius: 8px;
}

.jGIS-layer-browser-img {
  /* position: absolute; */
  /* height: 100%; */
  /* object-fit: cover; */
  /* box-sizing: border-box; */
  width: 100%;
}

.jGIS-layer-browser-icon {
  padding-inline: 8px;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  overflow: hidden;
  box-sizing: border-box;
  width: 32px;
  height: 32px;
  transition:
    width 125ms ease-in-out,
    background-color 125ms ease-in-out,
    opacity 150ms ease-out;
  background-color: var(--jp-accent-color1);
  border-radius: 20px;
}

.jGIS-layer-browser-tile:not(.jGIS-layer-browser-tile:hover)
  .jGIS-layer-browser-icon {
  opacity: 0;
}

.jGIS-layer-browser-added {
  display: inline-flex;
  gap: 0.35rem;
  opacity: 1 !important;
  width: 7rem;
  color: var(--jp-ui-inverse-font-color1);
}

.jGIS-layer-browser-text-container {
  padding-inline: 4px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 8px;
  flex: 1 1 0%;
  box-sizing: border-box;
}

.jGIS-layer-browser-text-info {
  display: flex;
  flex-direction: column;
  gap: 8px;
  box-sizing: border-box;
}

.jGIS-layer-browser-text-header {
  overflow: hidden;
  font-weight: bold;
  text-transform: capitalize;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.jGIS-layer-browser-text-p {
  overflow: hidden;
  text-overflow: ellipsis;
}

.jGIS-layer-browser-text-source {
  overflow: hidden;
  font-size: 0.75rem;
  font-weight: lighter;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.jGIS-layer-browser-text-description {
  -webkit-line-clamp: 2;
  -moz-box-orient: vertical;
  display: -webkit-box;
  overflow: hidden;
  text-overflow: ellipsis;
}

.jGIS-layer-browser-text-general {
  margin: 0;
}
`,""]),e.d(r,{},{A:n})},5633(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`/* -----------------------------------------------------------------------------
| Copyright (c) Jupyter Development Team.
| Distributed under the terms of the Modified BSD License.
|---------------------------------------------------------------------------- */

.jp-gis-layerPanel {
  min-height: 3em;
}

.jp-gis-layerItem {
  padding: 2px 0 2px 12px;
}

.jp-gis-layerGroup {
  display: flex;
  flex-direction: column;
}

.jp-gis-layerGroupHeader {
  display: flex;
  margin-left: -2px;
  padding-bottom: 4px;
}

.jp-gis-layerGroupHeader:hover {
  cursor: pointer;
}

.jp-gis-layerGroupCollapser {
  transform: rotate(-90deg);
  margin: auto 0;
  height: 16px;
}

.jp-gis-layerGroupCollapser.jp-mod-expanded {
  transform: rotate(0deg);
}

.jp-gis-layer {
  display: flex;
  flex-direction: row;
  /* align-items: center; */
  color: var(--jp-ui-font-color1);
}

.jp-gis-layer.jp-mod-selected,
.jp-gis-layerGroupHeader.jp-mod-selected {
  color: var(--jp-ui-inverse-font-color1);
  background: var(--jp-brand-color1);
}

.jp-gis-layer:hover:not(.jp-mod-selected) {
  cursor: pointer;
  background: var(--jp-layout-color2);
}

.jp-gis-layer.jp-mod-selected .jp-icon-selectable,
.jp-gis-layerGroupHeader.jp-mod-selected .jp-icon-selectable {
  fill: var(--jp-ui-inverse-font-color1);
}
.jp-gis-layer.jp-mod-selected path {
  fill: var(--jp-ui-inverse-font-color1);
}
.jp-gis-layer.jp-mod-selected button:hover {
  background: none;
}

.jp-gis-layer button {
  min-height: unset;
  min-width: unset;
  padding: unset;
  margin-right: 4px;
  flex-shrink: 0;
}

.jp-gis-layer.jp-mod-selected button:hover .jp-icon-selectable {
  fill: var(--jp-ui-font-color1);
}

.jp-gis-layerIcon {
  display: flex;
  align-items: center;
  flex-shrink: 0;
}

.jp-gis-layerIcon > svg {
  height: 16px;
  width: 16px;
}

.jp-gis-layerTitle {
  display: flex;
  flex-grow: 1;
  align-items: center;
}

.jp-gis-layerText:focus {
  outline: none;
}

.jp-gis-layerTitle .jp-gis-layerIcon {
  padding-right: 4px;
}

.jp-gis-layerIcon.jp-gis-mod-hidden path {
  fill: var(--jp-warn-color0);
}

.jp-gis-left-panel-input {
  background-color: transparent;
  border: 1px solid var(--jp-border-color1);
  border-radius: 8px;
  color: var(--jp-ui-font-color1);
  flex-grow: 1;
  margin-right: 4px;
  outline: none;
  padding: 2px 7px;
}

.jp-gis-left-panel-input:focus {
  border: 1px solid var(--jp-brand-color1);
}

.jp-gis-layerText {
  padding: 3px 0;
  cursor: pointer;
  flex-grow: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Wraps the shared (story-editor) Slider so it fits the layer row. */
.jp-gis-layerOpacitySlider {
  width: 72px;
  min-width: 56px;
  margin: 0 6px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
}

/* Use the JupyterLab brand blue for the filled range by default. */
.jp-gis-layerOpacitySlider .jgis-slider-range {
  background-color: var(--jp-brand-color1);
}

/* On a selected (blue) row, recolor the slider so it reads against the
   inverse background instead of showing the green accent range. */
.jp-gis-layer.jp-mod-selected .jp-gis-layerOpacitySlider .jgis-slider-track {
  background-color: color-mix(
    in srgb,
    var(--jp-ui-inverse-font-color1),
    transparent 70%
  );
}

.jp-gis-layer.jp-mod-selected .jp-gis-layerOpacitySlider .jgis-slider-range {
  background-color: var(--jp-ui-inverse-font-color1);
}

.jp-gis-layer.jp-mod-selected .jp-gis-layerOpacitySlider .jgis-slider-thumb {
  background-color: var(--jp-ui-inverse-font-color1);
  border-color: var(--jp-ui-inverse-font-color1);
}

.jp-gis-layerSlideNumber {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 18px;
  height: 18px;
  padding: 0 6px;
  margin-right: 4px;
  background-color: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  border-radius: 9999px;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  line-height: 1;
}

li .lm-Menu-itemLabel {
  text-transform: capitalize;
}

/* "More options" (⋮) button — hidden by default, shown on hover or on touch devices */
.jp-gis-layer-more-btn {
  opacity: 0;
  pointer-events: none;
  flex-shrink: 0;
}

.jp-gis-layerItem .jp-gis-layer-more-btn,
.jp-gis-layerGroupHeader .jp-gis-layer-more-btn {
  margin-right: 6px;
}

.jp-gis-layerItem:hover .jp-gis-layer-more-btn,
.jp-gis-layerGroupHeader:hover .jp-gis-layer-more-btn {
  opacity: 1;
  pointer-events: auto;
}

@media (pointer: coarse) {
  .jp-gis-layer-more-btn {
    opacity: 1;
    pointer-events: auto;
  }
}

#jp-drag-indicator {
  top: calc(-1 * var(--jp-border-width) + 1px);
  left: calc(-1 * var(--jp-border-width));
  content: '';
  height: var(--jp-private-horizontal-tab-active-top-border);
  width: calc(100% + 2 * var(--jp-border-width));
  background: var(--jp-brand-color1);
}
`,""]),e.d(r,{},{A:n})},524(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jp-openeo-configure-form {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 360px;
}

.jp-openeo-configure-form label {
  display: flex;
  flex-direction: column;
  gap: 2px;
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-configure-form input,
.jp-openeo-configure-form select {
  padding: 4px;
}

.jp-openeo-configure-hint {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
  margin: 4px 0 0;
}

.jp-openeo-add-layer {
  display: flex;
  gap: 16px;
  min-width: 720px;
  min-height: 480px;
}

.jp-openeo-add-layer-left,
.jp-openeo-add-layer-right {
  display: flex;
  flex-direction: column;
  gap: 8px;
  flex: 1;
  min-width: 0;
}

.jp-openeo-add-layer-left label,
.jp-openeo-add-layer-left fieldset {
  display: flex;
  flex-direction: column;
  gap: 2px;
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-add-layer-left input,
.jp-openeo-add-layer-left select {
  padding: 4px;
}

.jp-openeo-template-grid {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 6px;
}

.jp-openeo-template-card {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  text-align: left;
  padding: 8px;
  border: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
  cursor: pointer;
  border-radius: 4px;
}

.jp-openeo-template-card.jp-mod-selected {
  border-color: var(--jp-brand-color1);
  background: var(--jp-brand-color3);
}

.jp-openeo-template-card small {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-bbox,
.jp-openeo-temporal {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px;
  border: 1px solid var(--jp-border-color2);
  padding: 6px;
}

.jp-openeo-bbox legend,
.jp-openeo-temporal legend {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.jp-openeo-graph-preview {
  flex: 1;
  background: var(--jp-layout-color2);
  padding: 8px;
  overflow: auto;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
  white-space: pre;
  margin: 0;
  min-height: 0;
}

/* Catalog browser (collections / processes) shown in the Add Layer dialog */
.jp-openeo-filter {
  padding: 4px;
}

.jp-openeo-section {
  display: flex;
  flex-direction: column;
  border-top: 1px solid var(--jp-border-color2);
}

.jp-openeo-section-header {
  display: flex;
  align-items: center;
  gap: 6px;
  background: transparent;
  border: none;
  padding: 6px 2px;
  cursor: pointer;
  text-align: left;
  width: 100%;
  color: var(--jp-ui-font-color1);
}

.jp-openeo-count {
  margin-left: auto;
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-section-body {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.jp-openeo-id {
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
}

.jp-openeo-secondary {
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-empty {
  color: var(--jp-ui-font-color2);
  font-style: italic;
  padding: 6px;
}

/* Process graph view */
.jp-openeo-preview-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.jp-openeo-preview-toggle {
  display: inline-flex;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  overflow: hidden;
}

.jp-openeo-preview-toggle button {
  background: var(--jp-layout-color1);
  border: none;
  padding: 2px 10px;
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-preview-toggle button.jp-mod-selected {
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.jp-openeo-pg-canvas {
  flex: 1;
  min-height: 0;
  border: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color1);
}

.jp-openeo-pg-empty {
  padding: 12px;
  color: var(--jp-ui-font-color2);
}

.jp-openeo-pg-node {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: 6px;
  padding: 6px 8px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color1);
  width: 220px;
  box-sizing: border-box;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.08);
}

.jp-openeo-pg-node-result {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 2px var(--jp-brand-color3);
}

.jp-openeo-pg-node-header {
  display: flex;
  justify-content: space-between;
  gap: 6px;
  align-items: baseline;
}

.jp-openeo-pg-node-id {
  color: var(--jp-ui-font-color2);
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
}

.jp-openeo-pg-node-args {
  list-style: none;
  padding: 4px 0 0;
  margin: 0;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
}

.jp-openeo-pg-node-args li {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: var(--jp-ui-font-color2);
}

.jp-openeo-pg-node-more {
  font-style: italic;
}

.jp-openeo-pg-node-nested {
  margin-top: 4px;
  padding: 2px 4px;
  background: var(--jp-layout-color2);
  border-radius: 3px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.jp-openeo-edited-badge {
  color: var(--jp-warn-color1);
  font-style: italic;
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-reset-btn {
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  margin-left: 6px;
  padding: 2px 10px;
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-reset-btn:hover {
  background: var(--jp-layout-color3);
}

.jp-openeo-edit-toggle {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin-left: 6px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color1);
  cursor: pointer;
}

.jp-openeo-edit-hint {
  margin: 4px 0 0;
  padding: 4px 8px;
  background: var(--jp-warn-color3);
  border-left: 3px solid var(--jp-warn-color1);
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-json-editor {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;
  border: 1px solid var(--jp-border-color2);
}

.jp-openeo-json-editor-host {
  flex: 1;
  min-height: 0;
  overflow: hidden;
}

.jp-openeo-json-editor-host .cm-editor {
  height: 100%;
}

.jp-openeo-json-editor-error {
  padding: 4px 8px;
  background: var(--jp-error-color3);
  color: var(--jp-error-color1);
  font-size: var(--jp-ui-font-size0);
  font-family: var(--jp-code-font-family);
  white-space: pre-wrap;
}

.jp-openeo-validation {
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-validation-pending {
  color: var(--jp-ui-font-color2);
  font-style: italic;
}

.jp-openeo-validation-ok {
  color: var(--jp-success-color1, #2a9d2a);
}

.jp-openeo-validation-bad {
  color: var(--jp-error-color1);
}

.jp-openeo-validation-errors {
  list-style: none;
  margin: 6px 0 0;
  padding: 6px 8px;
  max-height: 140px;
  overflow: auto;
  background: var(--jp-error-color3);
  border-left: 3px solid var(--jp-error-color1);
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color1);
}

.jp-openeo-validation-errors li {
  padding: 2px 0;
  display: flex;
  gap: 4px;
  align-items: baseline;
  border-bottom: 1px dashed var(--jp-border-color3);
}

.jp-openeo-validation-errors li:last-child {
  border-bottom: none;
}

.jp-openeo-spinner {
  display: inline-block;
  animation: jp-openeo-spin 800ms linear infinite;
  color: var(--jp-ui-font-color2);
  margin-right: 4px;
}

@keyframes jp-openeo-spin {
  to {
    transform: rotate(360deg);
  }
}

.jp-openeo-validation-errors code {
  background: var(--jp-layout-color2);
  padding: 0 4px;
  margin-right: 4px;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
}

.jp-openeo-test-btn {
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  border: none;
  border-radius: 4px;
  margin-left: 6px;
  padding: 2px 10px;
  cursor: pointer;
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-test-btn:hover:not(:disabled) {
  filter: brightness(1.1);
}

.jp-openeo-test-btn:disabled {
  opacity: 0.6;
  cursor: progress;
}

.jp-openeo-test-ok,
.jp-openeo-test-bad {
  margin-top: 6px;
  padding: 6px 8px;
  border-radius: 4px;
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-test-ok {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--jp-success-color3, #d6f5d6);
  border-left: 3px solid var(--jp-success-color1, #2a9d2a);
  color: var(--jp-ui-font-color1);
}

.jp-openeo-test-ok img {
  width: 64px;
  height: 64px;
  object-fit: contain;
  background: #fff;
  border: 1px solid var(--jp-border-color2);
}

.jp-openeo-test-bad {
  background: var(--jp-error-color3);
  border-left: 3px solid var(--jp-error-color1);
  color: var(--jp-ui-font-color1);
}

.jp-openeo-test-bad pre {
  margin: 4px 0 0;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
  white-space: pre-wrap;
  word-break: break-word;
}

.jp-openeo-pg-delete-btn {
  position: absolute;
  top: 8px;
  left: 8px;
  z-index: 100;
  padding: 4px 10px;
  border-radius: 4px;
  border: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  cursor: pointer;
  font-size: var(--jp-ui-font-size0);
  line-height: 1.2;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.jp-openeo-pg-delete-btn:hover:not(:disabled) {
  background: var(--jp-error-color3);
  border-color: var(--jp-error-color1);
}

.jp-openeo-pg-delete-btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

/* --- Redesigned Add/Edit OpenEO dialog (v2) --- */
.jp-Dialog-content:has(.jp-openeo-add-layer-body) {
  max-width: 95vw;
  max-height: 92vh;
}

.jp-openeo-dialog {
  display: flex;
  gap: 12px;
  width: min(1500px, 95vw);
  height: min(860px, 90vh);
  max-width: 100%;
  font-size: var(--jp-ui-font-size1);
  overflow: hidden;
  box-sizing: border-box;
}

.jp-openeo-dialog-left {
  flex: 0 0 auto;
  width: 320px;
  min-width: 220px;
  max-width: 70%;
  display: flex;
  flex-direction: column;
  gap: 14px;
  overflow: auto;
  padding: 0 8px 0 0;
  /* Native horizontal resize handle in the bottom-right corner. */
  resize: horizontal;
  border-right: 1px solid var(--jp-border-color2);
}

.jp-openeo-dialog-right {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  gap: 6px;
  overflow: hidden;
}

.jp-openeo-section h4 {
  margin: 0 0 6px;
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-ui-font-color1);
  border-bottom: 1px solid var(--jp-border-color2);
  padding-bottom: 4px;
}

.jp-openeo-field {
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin-bottom: 8px;
}

.jp-openeo-server-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.jp-openeo-server-picker {
  display: flex;
  gap: 4px;
}

.jp-openeo-server-picker input {
  flex: 1 1 auto;
  min-width: 0;
  padding: 4px 6px;
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-server-connect {
  flex: 0 0 auto;
  white-space: nowrap;
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  border: 1px solid var(--jp-brand-color1);
  border-radius: 4px;
  padding: 4px 14px;
  cursor: pointer;
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-server-connect:hover:not(:disabled) {
  background: var(--jp-brand-color0);
}

.jp-openeo-server-connect:disabled {
  opacity: 0.55;
  cursor: default;
}

.jp-openeo-server-connected {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  background: var(--jp-layout-color2);
  border-radius: 4px;
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-server-connected code {
  flex: 1 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  background: transparent;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
  color: var(--jp-ui-font-color1);
}

.jp-openeo-server-ok {
  color: var(--jp-success-color1, #2a9d2a);
  font-weight: bold;
}

.jp-openeo-link-btn {
  background: transparent;
  border: none;
  padding: 0;
  cursor: pointer;
  color: var(--jp-brand-color1);
  font-size: var(--jp-ui-font-size0);
  text-decoration: underline;
}

.jp-openeo-link-btn:hover:not(:disabled) {
  color: var(--jp-brand-color0);
}

.jp-openeo-link-btn:disabled {
  color: var(--jp-ui-font-color3);
  text-decoration: none;
  cursor: default;
}

.jp-openeo-server-suggest {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.jp-openeo-server-chip {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  border-radius: 999px;
  padding: 2px 10px;
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
  font-family: var(--jp-code-font-family);
}

.jp-openeo-server-chip:hover {
  background: var(--jp-layout-color2);
  border-color: var(--jp-border-color1);
}

.jp-openeo-server-alert {
  padding: 8px 10px;
  border-radius: 4px;
  font-size: var(--jp-ui-font-size0);
  line-height: 1.4;
}

.jp-openeo-server-alert.jp-mod-error {
  background: var(--jp-error-color3);
  border-left: 3px solid var(--jp-error-color1);
  color: var(--jp-ui-font-color1);
}

.jp-openeo-signin-header {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 8px;
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-signin-header code {
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
  color: var(--jp-ui-font-color1);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.jp-openeo-signin-actions {
  display: flex;
  justify-content: flex-end;
}

.jp-openeo-field span {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.jp-openeo-field input,
.jp-openeo-field select {
  padding: 4px 6px;
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-section-help {
  margin: 4px 0 0;
  color: var(--jp-ui-font-color2);
  font-size: var(--jp-ui-font-size0);
  line-height: 1.4;
}

.jp-openeo-template-pills {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.jp-openeo-pill {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  border-radius: 999px;
  padding: 3px 10px;
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-pill.jp-mod-selected {
  border-color: var(--jp-brand-color1);
  background: var(--jp-brand-color3);
  color: var(--jp-ui-font-color1);
}

/* Right pane toolbar */
.jp-openeo-toolbar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 0;
  border-bottom: 1px solid var(--jp-border-color2);
}

.jp-openeo-segmented {
  display: inline-flex;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  overflow: hidden;
}

.jp-openeo-segmented button {
  background: var(--jp-layout-color1);
  border: none;
  padding: 3px 12px;
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-segmented button.jp-mod-selected {
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.jp-openeo-toolbar-toggle,
.jp-openeo-toolbar-btn {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  padding: 3px 10px;
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-toolbar-btn.jp-openeo-icon-btn {
  padding: 3px 8px;
  font-size: var(--jp-ui-font-size1);
  line-height: 1;
  min-width: 26px;
  text-align: center;
}

.jp-openeo-toolbar-toggle.jp-mod-selected {
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  border-color: var(--jp-brand-color1);
}

.jp-openeo-toolbar-btn:hover,
.jp-openeo-toolbar-toggle:hover {
  background: var(--jp-layout-color2);
}

.jp-openeo-toolbar-spacer {
  flex: 1;
}

/* Code export view (Python / R) */
.jp-openeo-code-export {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
}

.jp-openeo-code-export-controls {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0;
}

.jp-openeo-code-export-toggle {
  display: flex;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size0);
}

.jp-openeo-status {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.jp-openeo-dot {
  color: var(--jp-warn-color1);
}

.jp-openeo-status-ok {
  color: var(--jp-success-color1, #2a9d2a);
}

.jp-openeo-status-bad {
  color: var(--jp-error-color1);
}

.jp-openeo-status-pending {
  color: var(--jp-ui-font-color2);
  font-style: italic;
}

.jp-openeo-edit-hint-inline {
  margin: 4px 0 0;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  font-style: italic;
}

.jp-openeo-canvas-wrapper {
  flex: 1;
  min-height: 0;
  min-width: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  background: var(--jp-layout-color1);
}

.jp-openeo-canvas-wrapper > * {
  flex: 1;
  min-height: 0;
  min-width: 0;
}

.jp-openeo-canvas-wrapper .jp-openeo-pg-canvas {
  width: 100%;
  height: 100%;
  overflow: hidden;
  border: none;
}

.jp-openeo-canvas-wrapper openeo-model-builder {
  max-width: 100%;
  max-height: 100%;
}

/* Catalog palette (replaces the left form pane while editing). */
.jp-openeo-palette {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-height: 0;
  flex: 1 1 auto;
  animation: jp-openeo-fade-in 140ms ease-out;
}

.jp-openeo-palette-sections {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-height: 0;
  flex: 1 1 auto;
  overflow: hidden;
}

.jp-openeo-palette-sections .jp-openeo-section {
  display: flex;
  flex-direction: column;
  min-height: 0;
  flex: 0 0 auto;
}

.jp-openeo-palette-sections .jp-openeo-section.jp-mod-open {
  /* Open section flexes to share remaining height with other open sections. */
  flex: 1 1 0;
  min-height: 80px;
}

.jp-openeo-palette-body {
  overflow-y: auto;
  min-height: 0;
  flex: 1 1 auto;
  border: 1px solid var(--jp-border-color2);
  border-top: none;
  border-radius: 0 0 4px 4px;
  background: var(--jp-layout-color1);
}

.jp-openeo-palette-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 6px;
  cursor: grab;
  user-select: none;
  border-bottom: 1px solid var(--jp-border-color3);
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-palette-row:last-child {
  border-bottom: none;
}

.jp-openeo-palette-row:hover {
  background: var(--jp-layout-color2);
}

.jp-openeo-palette-row:active {
  cursor: grabbing;
  background: var(--jp-brand-color3);
}

.jp-openeo-palette-row .jp-openeo-grip {
  color: var(--jp-ui-font-color3);
  opacity: 0;
  transition: opacity 80ms ease-out;
  font-size: 14px;
  line-height: 1;
}

.jp-openeo-palette-row:hover .jp-openeo-grip {
  opacity: 1;
}

.jp-openeo-palette-row-text {
  display: flex;
  flex-direction: column;
  min-width: 0;
  flex: 1 1 auto;
  gap: 1px;
}

.jp-openeo-palette-row .jp-openeo-id {
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color1);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.jp-openeo-palette-row .jp-openeo-secondary {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

@keyframes jp-openeo-fade-in {
  from {
    opacity: 0;
    transform: translateX(-4px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}

.jp-openeo-palette-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-bottom: 4px;
  border-bottom: 1px solid var(--jp-border-color2);
}

.jp-openeo-palette-header strong {
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size1);
}

.jp-openeo-palette-back {
  background: transparent;
  border: none;
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size1);
  cursor: pointer;
  padding: 2px 6px;
  border-radius: 4px;
}

.jp-openeo-palette-back:hover {
  background: var(--jp-layout-color2);
}

.jp-openeo-palette .jp-openeo-filter {
  width: 100%;
  padding: 4px 6px;
  font-size: var(--jp-ui-font-size1);
  box-sizing: border-box;
}

.jp-openeo-draggable {
  cursor: grab;
  user-select: none;
}

.jp-openeo-draggable:active {
  cursor: grabbing;
}

.jp-openeo-draggable .jp-openeo-list-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 6px;
  border-radius: 3px;
  border: 1px solid transparent;
}

.jp-openeo-draggable:hover .jp-openeo-list-row {
  background: var(--jp-layout-color2);
  border-color: var(--jp-border-color2);
}

.jp-openeo-grip {
  color: var(--jp-ui-font-color3);
  font-size: var(--jp-ui-font-size1);
  line-height: 1;
}

/* Drop target on the graph canvas. */
.jp-openeo-canvas-wrapper.jp-mod-drop-target {
  outline: 2px dashed var(--jp-brand-color1);
  outline-offset: -2px;
  background: var(--jp-brand-color3);
}

.jp-openeo-drop-overlay {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 5;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-brand-color1);
  color: var(--jp-ui-font-color1);
  padding: 8px 14px;
  border-radius: 6px;
  font-size: var(--jp-ui-font-size1);
  box-shadow: var(--jp-elevation-z2);
  pointer-events: none;
}

.jp-openeo-canvas-wrapper {
  position: relative;
}

/* Native CSS resize replaces the custom splitter. */

/* Process-graph entry rendered as a regular form field so it sits
   naturally inside the auto-generated property form. */
.jp-openeo-pg-field {
  padding: 6px 12px;
}

.jp-openeo-pg-field .jp-FormGroup-fieldLabel {
  padding-left: 0;
}

.jp-openeo-pg-field-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding-left: 12px;
  margin-top: 4px;
}

.jp-openeo-pg-field-help {
  margin: 0;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.jp-openeo-pg-field-btn {
  align-self: flex-start;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 14px;
  font-size: var(--jp-ui-font-size1);
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color1);
  border-radius: 3px;
  color: var(--jp-ui-font-color1);
  cursor: pointer;
}

.jp-openeo-pg-field-btn:hover {
  background: var(--jp-layout-color2);
  border-color: var(--jp-brand-color1);
  color: var(--jp-brand-color1);
}

.jp-openeo-pg-field-icon svg {
  width: 14px;
  height: 14px;
  fill: currentColor;
}

.jp-openeo-pg-field-icon svg [fill] {
  fill: currentColor;
}
`,""]),e.d(r,{},{A:n})},5891(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-badge {
  display: inline-flex;
  align-items: center;
  border-radius: 9999px;
  border: 1px solid transparent;
  padding: 2px 0.5rem;
  font-size: 0.75rem;
  font-weight: 600;
  outline: none;
  color: var(--jp-ui-inverse-font-color1);
  background-color: var(--jp-brand-color0);
  width: max-content;
  word-break: break-word;
  max-width: 200px;
  text-align: center;
}

.jgis-badge:hover {
  background-color: color-mix(in srgb, var(--jp-brand-color0) 80%, transparent);
}

.jgis-badge[data-variant='secondary'] {
  border: 1px solid transparent;
  background-color: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  transition: background-color 0.3s ease;
}

.jgis-badge[data-variant='secondary']:focus {
  border-width: 2px;
  border-color: var(--jp-border-color0);
  box-shadow: 0 0 0 3px var(--jp-border-color0);
}

.jgis-badge[data-variant='destructive'] {
  border: 1px solid transparent;
  background-color: color-mix(in srgb, var(--jp-error-color1) 90%, transparent);
  color: var(--jp-ui-inverse-font-color1);
}

.jgis-badge[data-variant='destructive']:hover {
  background-color: color-mix(in srgb, var(--jp-error-color1) 80%, transparent);
}

.jgis-badge[data-variant='destructive']:focus {
  background-color: var(--jp-error-color1);
}

.jgis-badge[data-variant='outline'] {
  color: var(--jp-ui-font-color1);
  background-color: transparent;
  border: 1px solid color-mix(in srgb, var(--jp-border-color1) 80%, transparent);
}

.jgis-badge[data-variant='outline']:hover {
  background-color: color-mix(
    in srgb,
    var(--jp-ui-font-color1) 10%,
    transparent
  );
}
`,""]),e.d(r,{},{A:n})},5872(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-button {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  border-radius: var(--jp-border-radius, 0.375rem);
  font-size: 0.875rem;
  font-weight: 600;
  outline: none;
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  border: 0.0375rem solid
    color-mix(in srgb, var(--jp-border-color1), transparent 20%);
  transition: background-color 0.2s ease;
  height: 1.5rem;
  padding: 1rem 0.5rem;
  max-width: 20rem;
  gap: 0.25rem;
}

.jgis-button:hover {
  cursor: pointer;
  background-color: color-mix(
    in srgb,
    var(--jp-layout-color2),
    transparent 20%
  );
  transition: background-color 0.2s ease;
}

.jgis-button:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px
    color-mix(in srgb, var(--jp-ui-font-color0), transparent 50%);
}

.jgis-button:disabled {
  pointer-events: none;
  opacity: 0.5;
}

.jgis-button:disabled:focus-visible {
  outline: none;
  box-shadow: none;
}

.jgis-button[data-variant='destructive'] {
  background-color: var(--jp-error-color0);
  color: var(--jp-ui-inverse-font-color0);
  transition: background-color 0.2s ease;
}

.jgis-button[data-variant='destructive']:hover {
  background-color: color-mix(in srgb, var(--jp-error-color0), transparent 10%);
}

.jgis-button[data-variant='outline'] {
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  transition:
    background-color 0.2s ease,
    color 0.2s ease;
}

.jgis-button[data-variant='outline']:hover {
  cursor: pointer;
  background-color: color-mix(
    in srgb,
    var(--jp-ui-font-color0),
    transparent 95%
  );
  color: var(--jp-ui-font-color2);
}

.jgis-button[data-variant='secondary'] {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color0);
  transition: background-color 0.2s ease;
}

.jgis-button[data-variant='secondary']:hover {
  background-color: color-mix(
    in srgb,
    var(--jp-layout-color2),
    transparent 10%
  );
}

.jgis-button[data-variant='ghost'] {
  background-color: transparent;
  border: 1px solid transparent;
  color: var(--jp-ui-font-color0);
  display: flex;
  align-items: center;
}

.jgis-button[data-variant='ghost']:hover {
  background-color: color-mix(
    in srgb,
    var(--jp-ui-font-color0),
    transparent 90%
  );
}

.jgis-button[data-variant='link'] {
  color: var(--jp-ui-font-color0);
  background-color: transparent;
  text-decoration: none;
  transition: text-decoration 0.2s ease;
  border: none;
  padding: 0;
  height: max-content;
  width: max-content;
}

.jgis-button[data-variant='link']:hover {
  color: var(--jp-layout-color0);
  text-decoration-color: var(--jp-ui-font-color0);
}

.jgis-button[data-variant='icon'] {
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 2rem;
  width: 2rem;
  padding: 0;
  border-radius: 9999px;
}

/* sizing */
.jgis-button[data-size='xs'] {
  padding: 0.5rem 0.25rem;
}

.jgis-button[data-size='sm'] {
  border-radius: var(--jp-border-radius, 0.375rem);
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}

.jgis-button[data-size='lg'] {
  height: 2.75rem;
  border-radius: var(--jp-border-radius, 0.375rem);
  padding-left: 2rem;
  padding-right: 2rem;
}

.jgis-button[data-size='icon'] {
  height: 2.5rem;
  width: 2.5rem;
}

.jgis-button[data-size='icon-sm'] {
  height: 1rem;
  width: 1rem;
}

.jgis-button[data-size='icon-md'] {
  height: 1.5rem;
  width: 1.5rem;
}

.jgis-button[data-variant='icon'] > svg,
.jgis-button[data-variant='icon'] > [data-icon] {
  height: 1rem;
  width: 1rem;
  flex-shrink: 0;
}
`,""]),e.d(r,{},{A:n})},9507(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-button-group {
  display: flex;
  width: fit-content;
  align-items: stretch;
}

.jgis-button-group > *:focus-visible {
  position: relative;
  z-index: 10;
}

.jgis-button-group:has(> [data-slot='button-group']) {
  gap: 0.5rem;
}

.jgis-button-group > [data-slot='select-trigger']:not([class*='w-']) {
  width: fit-content;
}

.jgis-button-group > input {
  flex: 1 1 0%;
}

.jgis-button-group:has(select[aria-hidden='true']:last-child)
  > [data-slot='select-trigger']:last-of-type {
  border-top-right-radius: 0.5rem;
  border-bottom-right-radius: 0.5rem;
}

.jgis-button-group[data-orientation='horizontal'] > *:not(:first-child) {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  border-left-width: 0;
}

.jgis-button-group[data-orientation='horizontal'] > *:not(:last-child) {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}

.jgis-button-group[data-orientation='horizontal'] > *:first-child {
  border-top-left-radius: 0.5rem;
  border-bottom-left-radius: 0.5rem;
}

.jgis-button-group[data-orientation='horizontal'] > *:last-child {
  border-top-right-radius: 0.5rem;
  border-bottom-right-radius: 0.5rem;
}

.jgis-button-group[data-orientation='vertical'] {
  flex-direction: column;
}

.jgis-button-group[data-orientation='vertical'] > *:not(:first-child) {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  border-top-width: 0;
}

.jgis-button-group[data-orientation='vertical'] > *:not(:last-child) {
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
}

.jgis-button-group[data-orientation='vertical'] > *:first-child {
  border-top-left-radius: 0.5rem;
  border-top-right-radius: 0.5rem;
}

.jgis-button-group[data-orientation='vertical'] > *:last-child {
  border-bottom-left-radius: 0.5rem;
  border-bottom-right-radius: 0.5rem;
}

.jgis-button-group-text {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color2);
  padding-left: 0.625rem;
  padding-right: 0.625rem;
  font-size: 0.875rem;
  line-height: 1.25rem;
  font-weight: 500;
}

.jgis-button-group-text svg {
  pointer-events: none;
}

.jgis-button-group-text svg:not([class*='size-']) {
  width: 1rem;
  height: 1rem;
}

.jgis-button-group-separator {
  position: relative;
  align-self: stretch;
  background-color: var(--jp-border-color0);
}

.jgis-button-group-separator[data-orientation='horizontal'] {
  margin-left: 1px;
  margin-right: 1px;
  width: auto;
}

.jgis-button-group-separator[data-orientation='vertical'] {
  margin-top: 1px;
  margin-bottom: 1px;
  height: auto;
}
`,""]),e.d(r,{},{A:n})},5362(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-calendar-container {
  padding: 0.75rem;
  background-color: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color0);
  border-radius: var(--jp-border-radius);
}

.jgis-calendar-months {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  justify-content: center;
}

@media (min-width: 640px) {
  .jgis-calendar-months {
    flex-direction: row;
  }
}

.jgis-calendar-month {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}

.jgis-calendar-month-caption {
  display: flex;
  justify-content: center;
  padding-top: 0.25rem;
  position: relative;
  align-items: center;
}

.jgis-calendar-caption-label {
  font-size: 0.875rem;
  line-height: 1.25rem;
  font-weight: 500;
}

.jgis-calendar-nav {
  gap: 0.25rem;
  display: flex;
  align-items: center;
}

.jgis-calendar-button-previous {
  height: 1.75rem;
  width: 1.75rem;
  background-color: transparent;
  padding: 0;
  opacity: 0.5;
  position: absolute;
  left: 1.25rem;
  top: 1.25rem;
  border: 1px solid transparent;
}

.jgis-calendar-button-previous:hover {
  opacity: 1;
}

.jgis-calendar-button-next {
  height: 1.75rem;
  width: 1.75rem;
  background-color: transparent;
  padding: 0;
  opacity: 0.5;
  position: absolute;
  right: 1.25rem;
  top: 1.25rem;
  border: 1px solid transparent;
}

.jgis-calendar-button-next:hover {
  opacity: 1;
}

.jgis-calendar-month-grid {
  width: 100%;
  border-collapse: collapse;
  gap: 0.25rem;
}

.jgis-calendar-weekdays {
  display: flex;
}

.jgis-calendar-weekday {
  color: var(--jp-ui-font-color2);
  border-radius: 0.375rem;
  width: 2.25rem;
  font-weight: 400;
  font-size: 0.8rem;
}

.jgis-calendar-week {
  display: flex;
  width: 100%;
  margin-top: 0.5rem;
}

.jgis-calendar-day {
  height: 2.25rem;
  width: 2.25rem;
  text-align: center;
  font-size: 0.875rem;
  line-height: 1.25rem;
  padding: 0;
  position: relative;
  border-radius: 0.25rem;
}

.jgis-calendar-day-button {
  height: 2.25rem;
  width: 2.25rem;
  padding: 0;
  font-weight: 400;
  opacity: 1;
  border: none;
  background-color: transparent;
  cursor: pointer;
  color: inherit;
}

.jgis-calendar-day-button.selected {
  border-radius: 0.375rem 0.375rem 0.375rem 0.375rem;
}

.jgis-calendar-day-button.range-end {
  border-radius: 0 0.375rem 0.375rem 0;
}

.jgis-calendar-day-button.range-middle {
  border-radius: 0;
}

.jgis-calendar-day-selected {
  background-color: var(--jp-accent-color1);
  color: var(--jp-ui-inverse-font-color0);
}

.jgis-calendar-day-selected:hover {
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color0);
}

.jgis-calendar-day-selected:focus {
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color0);
}

.jgis-calendar-day-today {
  background-color: var(--jp-accent-color0);
  color: var(--jp-ui-font-color0);
}

.jgis-calendar-day-outside {
  color: var(--jp-ui-font-color2);
  opacity: 0.5;
}

.jgis-calendar-day-outside.selected {
  background-color: var(--jp-accent-color0);
  color: var(--jp-ui-font-color2);
  opacity: 0.3;
}

.jgis-calendar-day-disabled {
  color: var(--jp-ui-font-color2);
  opacity: 0.5;
}

.jgis-calendar-day-range-middle {
  background-color: var(--jp-accent-color0);
  color: var(--jp-ui-font-color0);
}

.jgis-calendar-hidden {
  visibility: hidden;
}

.jgis-select-trigger-focus {
  display: flex;
  background-color: var(--jp-accent-color0);
  color: var(--jp-ui-inverse-font-color0);
  width: fit-content;
  gap: 0.25rem;
  border: none;
  align-items: center;
  justify-content: center;
}

.jgis-time-period-select-trigger {
  background-color: var(--jp-accent-color0);
  color: var(--jp-ui-font-color0);
  width: 65px;
}

.jgis-time-picker-input {
  width: 48px;
  text-align: center;
  font-family: monospace;
  font-size: 1rem;
  line-height: 1.5rem;
  font-feature-settings: 'tnum';
  caret-color: transparent;
}

.jgis-time-picker-input::-webkit-inner-spin-button {
  appearance: none;
}

.jgis-time-picker-input:focus {
  background-color: var(--jp-accent-color0);
  color: var(--jp-ui-font-color0);
}

.jgis-time-picker-container {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}

.jgis-time-picker-label {
  cursor: pointer;
}

.jgis-time-picker-clock-icon {
  margin-right: 0.5rem;
  height: 1rem;
  width: 1rem;
}

.jgis-date-time-picker-button {
  width: 100%;
  justify-content: flex-start;
  text-align: left;
  font-weight: 400;
}

.jgis-date-time-picker-button-muted {
  color: var(--jp-ui-font-color2);
}

.jgis-date-time-picker-calendar-icon {
  margin-right: 0.5rem;
  height: 1rem;
  width: 1rem;
}

.jgis-date-time-picker-popover-content {
  width: auto;
  padding: 0;
}

.jgis-date-time-picker-time-section {
  border-top: 1px solid var(--jp-border-color0);
  padding: 0.75rem;
}

.jgis-time-period-selector-container {
  display: grid;
  gap: 0.25rem;
  text-align: center;
}

.jgis-time-period-select-container {
  display: flex;
  height: 2.5rem;
  align-items: center;
}

/* Unset width and border when popover contains calendar */
.jgis-popover-content:has(> .jgis-calendar-container) {
  width: unset;
  border: unset;
}
`,""]),e.d(r,{},{A:n})},4691(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-checkbox {
  height: 1rem;
  width: 1rem;
  flex-shrink: 0;
  border-radius: 0.125rem;
  background-color: var(--jp-inverse-layout-color0);
  border: 1px solid color-mix(in srgb, var(--jp-border-color0), transparent 20%);
  outline: none;
  cursor: pointer;
  padding: 0;
}

.jgis-checkbox:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}

.jgis-checkbox[data-state='checked'] {
  background-color: var(--jp-ui-font-color0);
  color: var(--jp-layout-color0);
}

.jgis-checkbox-indicator {
  display: flex;
  align-items: center;
  justify-content: center;
  color: currentColor;
}
`,""]),e.d(r,{},{A:n})},7549(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`/* Shared base styles for Select and Combobox buttons */
/* More specific selector to override button base styles */
.jgis-button.jgis-combobox-button,
.jgis-button.jgis-select-button {
  display: flex;
  justify-content: space-between;
  align-items: center;
  white-space: preserve-breaks;
  padding: 1rem 0.5rem;
  box-sizing: border-box;
  border-radius: var(--jp-border-radius, 0.375rem);
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  font-size: 0.875rem;
  /* min-height: 1.125rem; */
  height: 1.5rem;
  max-width: none;
  gap: 0;
}

.jgis-combobox-button-text,
.jgis-select-button-text {
  flex: 1;
  min-width: 0;
  overflow-wrap: break-word;
}

.jgis-combobox-icon,
.jgis-select-icon {
  margin-left: 0.5rem;
  margin-top: 0.125rem;
  height: 1rem;
  width: 1rem;
  flex-shrink: 0;
  opacity: 0.5;
}

/* Shared Popover styles */
.jgis-combobox-popover,
.jgis-select-popover {
  width: 200px;
  padding: 0;
  border-radius: var(--jp-border-radius, 0.375rem);
}

/* Check icon for Combobox (multi-select) */
.jgis-combobox-check-icon {
  margin-right: 0.5rem;
  height: 1rem;
  width: 1rem;
  flex-shrink: 0;
}

/* Modifier classes - use higher specificity to override base */
.jgis-button.jgis-combobox-button--full-width,
.jgis-button.jgis-select-button--full-width {
  width: 100%;
}

.jgis-button.jgis-combobox-button--max-width-200,
.jgis-button.jgis-select-button--max-width-200 {
  max-width: 200px;
}

.jgis-button.jgis-combobox-button--no-radius,
.jgis-button.jgis-select-button--no-radius {
  border-radius: 0;
}

.jgis-button.jgis-combobox-button--queryable-input,
.jgis-button.jgis-select-button--queryable-input {
  padding: 0.25rem 1rem;
  border-radius: 0;
}
`,""]),e.d(r,{},{A:n})},1313(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`/* Command Root */
.jgis-command {
  display: flex;
  height: 100%;
  width: 100%;
  flex-direction: column;
  overflow: hidden;
  border-radius: 0.375rem;
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
}

/* Command Dialog specific styles */
.jgis-command [cmdk-group-heading] {
  color: var(--jp-ui-font-color2);
  padding: 0 0.5rem;
  font-weight: 500;
}

.jgis-command [data-slot='command-input-wrapper'] {
  height: 3rem;
}

.jgis-command [cmdk-group] {
  padding: 0 0.5rem;
}

.jgis-command [cmdk-group]:not([hidden]) ~ [cmdk-group] {
  padding-top: 0;
}

.jgis-command [cmdk-input-wrapper] svg {
  height: 1.25rem;
  width: 1.25rem;
}

.jgis-command [cmdk-input] {
  height: 1.5rem;
  box-sizing: border-box;
  padding: 1rem 0.5rem;
}

.jgis-command [cmdk-item] {
  padding: 0 0.5rem;
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
}

.jgis-command [cmdk-item] svg {
  height: 1.25rem;
  width: 1.25rem;
}

/* Command Input Wrapper */
.jgis-command-input-wrapper {
  display: flex;
  height: 2.25rem;
  align-items: center;
  gap: 0.5rem;
  border-bottom: 1px solid var(--jp-border-color0);
  padding: 0.25rem 0.75rem;
}

.jgis-command-input-wrapper .size-4 {
  width: 1rem;
  height: 1rem;
  flex-shrink: 0;
  opacity: 0.5;
}

/* Command Input */
.jgis-command-input {
  display: flex;
  height: 1rem;
  width: 100%;
  border-radius: 0.375rem;
  background-color: transparent;
  padding-top: 0.75rem;
  padding-bottom: 0.75rem;
  font-size: 0.875rem;
  outline: none;
}

.jgis-command-input::placeholder {
  color: var(--jp-ui-font-color2);
}

.jgis-command-input:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}

/* Command List */
.jgis-command-list {
  max-height: 300px;
  scroll-padding: 0.25rem 0;
  overflow-x: hidden;
  overflow-y: auto;
}

/* Command Empty */
.jgis-command-empty {
  padding-top: 1.5rem;
  padding-bottom: 1.5rem;
  text-align: center;
  font-size: 0.875rem;
}

/* Command Group */
.jgis-command-group {
  color: var(--jp-ui-font-color0);
  overflow: hidden;
  padding: 0.25rem;
}

.jgis-command-group [cmdk-group-heading] {
  color: var(--jp-ui-font-color2);
  padding: 0 0.5rem;
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
  font-size: 0.75rem;
  font-weight: 500;
}

/* Command Separator */
.jgis-command-separator {
  background-color: var(--jp-border-color0);
  margin: 0 -0.25rem;
  height: 1px;
}

/* Command Item */
.jgis-command-item {
  position: relative;
  display: flex;
  cursor: default;
  align-items: center;
  gap: 0.5rem;
  border-radius: 0.125rem;
  padding: 0 0.5rem;
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
  font-size: 0.875rem;
  outline: none;
  user-select: none;
}

.jgis-command-item[data-selected='true'] {
  background-color: var(--jp-layout-color1);
  color: var(--jp-ui-font-color0);
}

.jgis-command-item svg:not([class*='text-']) {
  color: var(--jp-ui-font-color2);
}

.jgis-command-item svg {
  pointer-events: none;
  flex-shrink: 0;
}

.jgis-command-item svg:not([class*='size-']) {
  width: 1rem;
  height: 1rem;
}

.jgis-command-item[data-disabled='true'] {
  pointer-events: none;
  opacity: 0.5;
}

/* Command Shortcut */
.jgis-command-shortcut {
  color: var(--jp-ui-font-color2);
  margin-left: auto;
  font-size: 0.75rem;
  letter-spacing: 0.1em;
}
`,""]),e.d(r,{},{A:n})},2760(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`@keyframes dialog-fade-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes dialog-fade-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}

@keyframes dialog-zoom-in {
  from {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translate(-50%, -50%) scale(1);
  }
}

@keyframes dialog-zoom-out {
  from {
    opacity: 1;
    transform: translate(-50%, -50%) scale(1);
  }
  to {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.95);
  }
}

.jgis-dialog-overlay {
  position: fixed;
  inset: 0;
  z-index: 50;
  background-color: color-mix(in srgb, black, transparent 50%);
}

/* react-remove-scroll (Radix modal) injects position:relative on body when it opens
   overwrite it with higher specificity on JupyterLab's themed body */
body.jp-ThemedContainer[data-scroll-locked] {
  position: static !important;
}

.jgis-dialog-overlay[data-state='open'] {
  animation: dialog-fade-in 0.2s ease-in-out;
}

.jgis-dialog-overlay[data-state='closed'] {
  animation: dialog-fade-out 0.2s ease-in-out;
}

.jgis-dialog-content {
  position: fixed;
  top: 50%;
  left: 50%;
  z-index: 60;
  display: grid;
  width: 100%;
  max-width: calc(100% - 2rem);
  transform: translate(-50%, -50%);
  gap: 1rem;
  border-radius: 0.5rem;
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color0);
  padding: 1rem;
  box-shadow:
    0 10px 15px -3px rgba(0, 0, 0, 0.1),
    0 4px 6px -2px rgba(0, 0, 0, 0.05);
  transition-duration: 200ms;
}

@media (min-width: 640px) {
  .jgis-dialog-content {
    max-width: 32rem;
  }
}

.jgis-dialog-content[data-state='open'] {
  animation:
    dialog-fade-in 0.2s ease-in-out,
    dialog-zoom-in 0.2s ease-in-out;
}

.jgis-dialog-content[data-state='closed'] {
  animation:
    dialog-fade-out 0.2s ease-in-out,
    dialog-zoom-out 0.2s ease-in-out;
}

.jgis-button.jgis-dialog-close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0.75rem;
  opacity: 0.7;
  transition: opacity 0.15s ease-in-out;
  outline: none;
  border: none;
}

.jgis-dialog-close:hover {
  opacity: 1;
  cursor: pointer;
}

.jgis-dialog-close:focus {
  opacity: 1;
  box-shadow: 0 0 0 2px var(--jp-ui-font-color0);
  outline: none;
}

.jgis-dialog-close:disabled {
  pointer-events: none;
}

.jgis-dialog-close[data-state='open'] {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color2);
}

.jgis-dialog-close svg {
  pointer-events: none;
  flex-shrink: 0;
  width: 1rem;
  height: 1rem;
}

.jgis-dialog-header {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  text-align: center;
}

@media (min-width: 640px) {
  .jgis-dialog-header {
    text-align: left;
  }
}

.jgis-dialog-footer {
  display: flex;
  flex-direction: column-reverse;
  gap: 0.5rem;
}

@media (min-width: 640px) {
  .jgis-dialog-footer {
    flex-direction: row;
    justify-content: flex-end;
  }
}

.jgis-dialog-title {
  font-size: 1.125rem;
  line-height: 1;
  font-weight: 600;
  margin: 0;
}

.jgis-dialog-description {
  font-size: 0.875rem;
  color: var(--jp-ui-font-color2);
}

.jgis-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
`,""]),e.d(r,{},{A:n})},6187(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`@keyframes drawer-fade-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes drawer-fade-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}

.jgis-drawer-overlay {
  position: fixed;
  inset: 0;
  z-index: 50;
  background-color: color-mix(in srgb, black, transparent 90%);
  backdrop-filter: blur(2px);
}

.jgis-drawer-overlay[data-state='open'] {
  animation: drawer-fade-in 0.2s ease-out;
}

.jgis-drawer-overlay[data-state='closed'] {
  animation: drawer-fade-out 0.2s ease-in;
}

.jgis-drawer-content {
  position: fixed;
  z-index: 50;
  display: flex;
  flex-direction: column;
  font-size: 0.875rem;
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  border-color: var(--jp-border-color0);
}

/* Bottom */
.jgis-drawer-content[data-vaul-drawer-direction='bottom'] {
  left: 0;
  right: 0;
  bottom: 0;
  margin-top: 6rem;
  max-height: 80vh;
  border-top-width: 1px;
  border-top-style: solid;
  border-radius: 0.75rem 0.75rem 0 0;
}

/* Top */
.jgis-drawer-content[data-vaul-drawer-direction='top'] {
  left: 0;
  right: 0;
  top: 0;
  margin-bottom: 6rem;
  max-height: 80vh;
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-radius: 0 0 0.75rem 0.75rem;
}

/* Left */
.jgis-drawer-content[data-vaul-drawer-direction='left'] {
  top: 0;
  bottom: 0;
  left: 0;
  width: 75%;
  border-right-width: 1px;
  border-right-style: solid;
  border-radius: 0 0.75rem 0.75rem 0;
}

@media (min-width: 640px) {
  .jgis-drawer-content[data-vaul-drawer-direction='left'] {
    max-width: 24rem;
  }
}

/* Right */
.jgis-drawer-content[data-vaul-drawer-direction='right'] {
  top: 0;
  bottom: 0;
  right: 0;
  width: 75%;
  border-left-width: 1px;
  border-left-style: solid;
  border-radius: 0.75rem 0 0 0.75rem;
}

@media (min-width: 640px) {
  .jgis-drawer-content[data-vaul-drawer-direction='right'] {
    max-width: 24rem;
  }
}

.jgis-drawer-handle {
  display: none;
  margin: 1rem auto 0;
  height: 0.25rem;
  width: 100px;
  flex-shrink: 0;
  border-radius: 9999px;
  background-color: var(--jp-layout-color2);
}

.jgis-drawer-content[data-vaul-drawer-direction='bottom'] .jgis-drawer-handle {
  display: block;
}

.jgis-drawer-header {
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
  padding: 1rem;
}

.jgis-drawer-content[data-vaul-drawer-direction='bottom'] .jgis-drawer-header,
.jgis-drawer-content[data-vaul-drawer-direction='top'] .jgis-drawer-header {
  text-align: center;
}

@media (min-width: 768px) {
  .jgis-drawer-header {
    gap: 0.125rem;
    text-align: left;
  }
}

.jgis-drawer-footer {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding: 1rem;
  margin-top: auto;
}

.jgis-drawer-title {
  font-size: 1rem;
  font-weight: 500;
  color: var(--jp-ui-font-color0);
}

.jgis-drawer-description {
  font-size: 0.875rem;
  color: var(--jp-ui-font-color2);
}
`,""]),e.d(r,{},{A:n})},7746(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`@keyframes jgis-dropdown-menu-animate-in {
  from {
    opacity: 0;
    transform: scale(0.95);
  }

  to {
    opacity: 1;
    transform: scale(1);
  }
}

@keyframes jgis-dropdown-menu-animate-out {
  from {
    opacity: 1;
    transform: scale(1);
  }

  to {
    opacity: 0;
    transform: scale(0.95);
  }
}

.jgis-dropdown-menu-content,
.jgis-dropdown-menu-sub-content {
  z-index: 50;
  min-width: 8rem;
  overflow: hidden;
  border-radius: 0.5rem;
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color2);
  padding: 0.25rem;
  color: var(--jp-ui-font-color0);
  box-shadow: 0 4px 6px
    color-mix(in srgb, var(--jp-layout-color0), transparent 50%);
  transform-origin: var(--radix-dropdown-menu-content-transform-origin);
}

.jgis-dropdown-menu-content {
  max-height: var(--radix-dropdown-menu-content-available-height);
  width: fit-content;
  overflow-x: hidden;
  overflow-y: auto;
}

.jgis-dropdown-menu-content[data-state='open'],
.jgis-dropdown-menu-sub-content[data-state='open'] {
  animation: jgis-dropdown-menu-animate-in 0.1s ease-out;
}

.jgis-dropdown-menu-content[data-state='closed'],
.jgis-dropdown-menu-sub-content[data-state='closed'] {
  overflow: hidden;
  animation: jgis-dropdown-menu-animate-out 0.1s ease-in;
}

.jgis-dropdown-menu-item,
.jgis-dropdown-menu-checkbox-item,
.jgis-dropdown-menu-radio-item,
.jgis-dropdown-menu-sub-trigger {
  position: relative;
  display: flex;
  cursor: default;
  user-select: none;
  align-items: center;
  gap: 0.375rem;
  border-radius: 0.375rem;
  padding: 0.25rem 0.375rem;
  font-size: 0.875rem;
  outline: none;
}

.jgis-dropdown-menu-item[data-inset='true'],
.jgis-dropdown-menu-checkbox-item[data-inset='true'],
.jgis-dropdown-menu-radio-item[data-inset='true'],
.jgis-dropdown-menu-sub-trigger[data-inset='true'],
.jgis-dropdown-menu-label[data-inset='true'] {
  padding-left: 1.75rem;
}

.jgis-dropdown-menu-item:focus,
.jgis-dropdown-menu-checkbox-item:focus,
.jgis-dropdown-menu-radio-item:focus,
.jgis-dropdown-menu-sub-trigger:focus {
  background-color: color-mix(
    in srgb,
    var(--jp-ui-font-color0),
    transparent 92%
  );
}

.jgis-dropdown-menu-sub-trigger[data-state='open'] {
  background-color: color-mix(
    in srgb,
    var(--jp-ui-font-color0),
    transparent 92%
  );
}

.jgis-dropdown-menu-item[data-disabled='true'],
.jgis-dropdown-menu-checkbox-item[data-disabled='true'],
.jgis-dropdown-menu-radio-item[data-disabled='true'] {
  pointer-events: none;
  opacity: 0.5;
}

.jgis-dropdown-menu-item[data-variant='destructive'] {
  color: var(--jp-error-color1);
}

.jgis-dropdown-menu-item[data-variant='destructive']:focus {
  background-color: color-mix(in srgb, var(--jp-error-color1) 15%, transparent);
  color: var(--jp-error-color1);
}

.jgis-dropdown-menu-item svg,
.jgis-dropdown-menu-checkbox-item svg,
.jgis-dropdown-menu-radio-item svg,
.jgis-dropdown-menu-sub-trigger svg {
  pointer-events: none;
  flex-shrink: 0;
  height: 1rem;
  width: 1rem;
}

.jgis-dropdown-menu-item[data-variant='destructive'] svg {
  color: var(--jp-error-color1);
}

.jgis-dropdown-menu-checkbox-item,
.jgis-dropdown-menu-radio-item {
  padding-right: 2rem;
}

.jgis-dropdown-menu-checkbox-item-indicator,
.jgis-dropdown-menu-radio-item-indicator {
  pointer-events: none;
  position: absolute;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
}

.jgis-dropdown-menu-label {
  padding: 0.25rem 0.375rem;
  font-size: 0.75rem;
  font-weight: 500;
  color: var(--jp-ui-font-color2);
}

.jgis-dropdown-menu-separator {
  margin: 0.25rem -0.25rem;
  height: 1px;
  background-color: var(--jp-border-color1);
}

.jgis-dropdown-menu-shortcut {
  margin-left: auto;
  font-size: 0.75rem;
  letter-spacing: 0.05em;
  color: var(--jp-ui-font-color2);
}

.jgis-dropdown-menu-item:focus .jgis-dropdown-menu-shortcut {
  color: inherit;
}

.jgis-dropdown-menu-icon {
  margin-left: auto;
  height: 1rem;
  width: 1rem;
}
`,""]),e.d(r,{},{A:n})},3270(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-error-banner {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  padding: 0.5rem 0.75rem;
  border-radius: 0.375rem;
  border: 1px solid transparent;
  font-size: 0.8125rem;
  line-height: 1.4;
  color: var(--jp-ui-font-color1);
}

.jgis-error-banner-icon {
  display: flex;
  align-items: center;
  flex-shrink: 0;
}

.jgis-error-banner-icon svg {
  width: 1rem;
  height: 1rem;
}

.jgis-error-banner-message {
  flex: 1 1 auto;
  min-width: 0;
  word-break: break-word;
}

.jgis-error-banner-dismiss {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  padding: 0;
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  opacity: 0.7;
  transition: opacity 0.15s ease-in-out;
}

.jgis-error-banner-dismiss:hover,
.jgis-error-banner-dismiss:focus-visible {
  opacity: 1;
}

.jgis-error-banner-dismiss svg {
  width: 0.875rem;
  height: 0.875rem;
}

.jgis-error-banner[data-variant='info'] {
  border-color: color-mix(in srgb, var(--jp-info-color1) 40%, transparent);
  background-color: color-mix(in srgb, var(--jp-info-color1) 12%, transparent);
}

.jgis-error-banner[data-variant='info'] .jgis-error-banner-icon {
  color: var(--jp-info-color1);
}

.jgis-error-banner[data-variant='warning'] {
  border-color: color-mix(in srgb, var(--jp-warn-color1) 40%, transparent);
  background-color: color-mix(in srgb, var(--jp-warn-color1) 12%, transparent);
}

.jgis-error-banner[data-variant='warning'] .jgis-error-banner-icon {
  color: var(--jp-warn-color1);
}

.jgis-error-banner[data-variant='error'] {
  border-color: color-mix(in srgb, var(--jp-error-color1) 40%, transparent);
  background-color: color-mix(in srgb, var(--jp-error-color1) 12%, transparent);
}

.jgis-error-banner[data-variant='error'] .jgis-error-banner-icon {
  color: var(--jp-error-color1);
}
`,""]),e.d(r,{},{A:n})},2981(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-error-tip-icon {
  color: var(--jp-error-color1);
}

.jgis-error-tip-content {
  max-width: 20rem;
}
`,""]),e.d(r,{},{A:n})},9850(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-hover-card-trigger {
  display: inline-flex;
  align-items: center;
  padding: 0;
  margin: 0;
  border: none;
  background: transparent;
  color: var(--jp-ui-font-color0);
  cursor: help;
  line-height: 1;
}

.jgis-hover-card-trigger:hover {
  color: var(--jp-ui-font-color0);
}

.jp-Dialog.jp-ThemedContainer .jp-Dialog-content .jgis-hover-card-trigger,
.jp-Dialog.jp-ThemedContainer .jp-Dialog-body .jgis-hover-card-trigger {
  color: var(--jp-ui-font-color0);
}

.jp-Dialog.jp-ThemedContainer .jp-Dialog-content .jgis-hover-card-trigger:hover,
.jp-Dialog.jp-ThemedContainer .jp-Dialog-body .jgis-hover-card-trigger:hover {
  color: var(--jp-ui-font-color0);
}

.jgis-hover-card-content {
  position: relative;
  z-index: 99999;
  width: 16rem;
  padding: 0.625rem;
  border-radius: 0.5rem;
  font-size: 0.875rem;
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  border: 1px solid
    color-mix(in srgb, var(--jp-ui-font-color0), transparent 90%);
  box-shadow:
    0 4px 6px -1px rgba(0, 0, 0, 0.1),
    0 2px 4px -2px rgba(0, 0, 0, 0.1);
  outline: none;
  transform-origin: var(--radix-hover-card-content-transform-origin);
  transition-duration: 100ms;
}

.jgis-hover-card-content[data-state='open'][data-side='bottom'] {
  animation: popover-slide-in-from-top 100ms ease-out;
}

.jgis-hover-card-content[data-state='open'][data-side='top'] {
  animation: popover-slide-in-from-bottom 100ms ease-out;
}

.jgis-hover-card-content[data-state='open'][data-side='left'] {
  animation: popover-slide-in-from-right 100ms ease-out;
}

.jgis-hover-card-content[data-state='open'][data-side='right'] {
  animation: popover-slide-in-from-left 100ms ease-out;
}

.jgis-hover-card-content[data-state='open']:not([data-side]) {
  animation: popover-fade-zoom-in 100ms ease-out;
}

.jgis-hover-card-content[data-state='closed'] {
  animation: popover-fade-zoom-out 100ms ease-in;
}
`,""]),e.d(r,{},{A:n})},7305(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-info-tip-content {
  display: flex;
  flex-direction: column;
}

.jgis-info-tip-content a {
  text-decoration: revert;
  color: var(--jp-content-link-color);
}

.jgis-info-tip-collapsible {
  display: flex;
  flex-direction: column;
  padding-top: 0.5rem;
}

.jgis-info-tip-collapsible-trigger {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding-top: 0.25rem;
  cursor: pointer;
}

.jgis-info-tip-more-info {
  font-size: var(--jp-ui-font-size0);
  font-weight: 500;
  color: var(--jp-ui-font-color2);
  line-height: 1.2;
  letter-spacing: 0.01em;
  user-select: none;
}

[data-slot='collapsible-trigger']:hover .jgis-info-tip-more-info {
  color: var(--jp-ui-font-color1);
}

.jgis-info-tip-collapsible-content {
  overflow: hidden;
}

.jgis-info-tip-collapsible-content[data-state='open'] {
  animation: jgis-info-tip-collapsible-down 200ms ease-out;
}

.jgis-info-tip-collapsible-content[data-state='closed'] {
  animation: jgis-info-tip-collapsible-up 200ms ease-out;
}

@keyframes jgis-info-tip-collapsible-down {
  from {
    height: 0;
    opacity: 0;
    transform: translateY(-0.375rem);
  }

  to {
    height: var(--radix-collapsible-content-height);
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes jgis-info-tip-collapsible-up {
  from {
    height: var(--radix-collapsible-content-height);
    opacity: 1;
    transform: translateY(0);
  }

  to {
    height: 0;
    opacity: 0;
    transform: translateY(-0.375rem);
  }
}
`,""]),e.d(r,{},{A:n})},8590(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`[data-slot='input'] {
  box-sizing: border-box;
  height: 2.25rem;
  width: auto;
  min-width: 0;
  border-radius: var(--jp-border-radius, 0.375rem);
  border: 1px solid var(--jp-border-color1);
  background-color: transparent;
  padding: 0.25rem 0.5rem;
  font-size: 1rem;
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  transition:
    color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  outline: none;
  color: var(--jp-ui-font-color1);
}

[data-slot='input']::placeholder {
  color: var(--jp-ui-font-color2);
}

[data-slot='input']::selection {
  background-color: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
}

[data-slot='input']:focus-visible {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 3px rgba(var(--jp-brand-color1-rgb), 0.1);
}

[data-slot='input'][aria-invalid='true'] {
  border-color: var(--jp-error-color1);
  box-shadow: 0 0 0 3px rgba(var(--jp-error-color1-rgb), 0.2);
}

[data-slot='input']:disabled {
  pointer-events: none;
  cursor: not-allowed;
  opacity: 0.5;
}

[data-slot='input']::file-selector-button {
  color: var(--jp-ui-font-color1);
  display: inline-flex;
  height: 1.75rem;
  border: 0;
  background-color: transparent;
  font-size: 0.875rem;
  font-weight: 500;
  margin-right: 0.75rem;
}

@media (min-width: 768px) {
  [data-slot='input'] {
    font-size: 0.875rem;
  }
}
`,""]),e.d(r,{},{A:n})},1345(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-native-select {
  position: relative;
  width: fit-content;
}

.jgis-native-select:has(select:disabled) {
  opacity: 0.5;
}

[data-slot='native-select'] {
  box-sizing: border-box;
  height: 2rem;
  width: 100%;
  min-width: 0;
  appearance: none;
  border-radius: var(--jp-border-radius, 0.375rem);
  border: 1px solid var(--jp-border-color1);
  background-color: transparent;
  padding: 0.25rem 2rem 0.25rem 0.625rem;
  font-size: 0.875rem;
  color: var(--jp-ui-font-color1);
  transition:
    color 0.15s ease-in-out,
    border-color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  outline: none;
  user-select: none;
  cursor: pointer;
}

[data-slot='native-select']::selection {
  background-color: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
}

[data-slot='native-select']:focus {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 3px rgba(var(--jp-brand-color1-rgb), 0.1);
}

[data-slot='native-select']:focus-visible {
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 3px rgba(var(--jp-brand-color1-rgb), 0.1);
}

[data-slot='native-select'][aria-invalid='true'] {
  border-color: var(--jp-error-color1);
  box-shadow: 0 0 0 3px rgba(var(--jp-error-color1-rgb), 0.2);
}

[data-slot='native-select']:disabled {
  pointer-events: none;
  cursor: not-allowed;
}

[data-slot='native-select'][data-size='sm'] {
  height: 1.75rem;
  padding-top: 0.125rem;
  padding-bottom: 0.125rem;
  border-radius: var(--jp-border-radius);
}

.jgis-native-select-icon {
  pointer-events: none;
  position: absolute;
  top: 50%;
  right: 0.625rem;
  width: 1rem;
  height: 1rem;
  transform: translateY(-50%);
  color: var(--jp-ui-font-color2);
  user-select: none;
  flex-shrink: 0;
}

[data-slot='native-select-option'],
[data-slot='native-select-optgroup'] {
  background: Canvas;
  color: CanvasText;
}
`,""]),e.d(r,{},{A:n})},6088(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-pagination {
  margin-left: auto;
  margin-right: auto;
  display: flex;
  width: 100%;
  justify-content: center;
}

.jgis-pagination-content {
  margin-left: auto;
  margin-right: auto;
  display: flex;
  width: 100%;
  justify-content: space-evenly;
  list-style-type: none;
  gap: 0.25rem;
  padding-left: unset;
  align-items: center;
}

.jgis-pagination-link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  border-radius: 0.375rem;
  font-size: 0.875rem;
  font-weight: 500;
  transition-property: color, background-color, border-color;
  transition-duration: 0.2s;
  transition-timing-function: ease;
  outline: none;
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  border: 0.0375rem solid
    color-mix(in srgb, var(--jp-border-color0), transparent 80%);
  transition: background-color 0.2s ease;
  padding: 0.25rem;
}

.jgis-pagination-link:hover {
  background-color: color-mix(
    in srgb,
    var(--jp-layout-color0),
    transparent 90%
  );
}

.jgis-pagination-link:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px
    color-mix(in srgb, var(--jp-layout-color2), transparent 50%);
}

.jgis-pagination-link:disabled {
  pointer-events: none;
  opacity: 0.5;
}

.jgis-pagination-link:disabled:focus-visible {
  outline: none;
  box-shadow: none;
}

.jgis-pagination-link[data-variant='destructive'] {
  background-color: var(--jp-error-color0);
  color: var(--jp-ui-font-color0);
  transition: background-color 0.2s ease;
}

.jgis-pagination-link[data-variant='destructive']:hover {
  background-color: color-mix(in srgb, var(--jp-error-color0), transparent 90%);
}

.jgis-pagination-link[data-variant='outline'] {
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color2);
  transition:
    background-color 0.2s ease,
    color 0.2s ease;
}

.jgis-pagination-link[data-variant='ghost']:hover,
.jgis-pagination-link[data-variant='outline']:hover {
  background-color: var(--jp-accent-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.jgis-pagination-link[data-variant='secondary'] {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color2);
  transition: background-color 0.2s ease;
}

.jgis-pagination-link[data-variant='secondary']:hover {
  background-color: color-mix(
    in srgb,
    var(--jp-layout-color0),
    transparent 80%
  );
}

.jgis-pagination-link[data-variant='ghost'] {
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
}

.jgis-pagination-link[data-variant='link'] {
  color: var(--jp-ui-font-color0);
  text-decoration: underline;
  text-underline-offset: 0.25rem;
  transition: text-decoration 0.2s ease;
  border: none;
  padding: 0;
}

.jgis-pagination-link[data-variant='link']:hover {
  color: color-mix(in srgb, var(--jp-ui-font-color0), transparent 80%);
  text-decoration-color: var(--jp-ui-font-color0);
}

.jgis-pagination-link[data-size='sm'] {
  height: 2.25rem;
  border-radius: 0.375rem;
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}

.jgis-pagination-link[data-size='lg'] {
  height: 2.75rem;
  border-radius: 0.375rem;
  padding-left: 2rem;
  padding-right: 2rem;
}

.jgis-pagination-link[data-size='icon'] {
  height: 1.5rem;
  width: 1.5rem;
}

.jgis-pagination-previous {
  gap: 0.25rem;
  padding-left: 0.625rem;
  display: flex;
  cursor: pointer;
  margin-right: 0.5rem;
  color: var(--jp-ui-font-color0);
  background-color: var(--jp-layout-color1);
}

.jgis-pagination-next {
  gap: 0.25rem;
  padding-right: 0.625rem;
  display: flex;
  cursor: pointer;
  margin-left: 0.5rem;
  color: var(--jp-ui-font-color0);
  background-color: var(--jp-layout-color1);
}

.jgis-pagination-ellipsis {
  display: flex;
  height: 2.25rem;
  width: 2.25rem;
  align-items: center;
  justify-content: center;
}
`,""]),e.d(r,{},{A:n})},5625(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`@keyframes popover-fade-zoom-in {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@keyframes popover-fade-zoom-out {
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.95);
  }
}

@keyframes popover-slide-in-from-top {
  from {
    opacity: 0;
    transform: scale(0.95) translateY(-0.5rem);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

@keyframes popover-slide-in-from-bottom {
  from {
    opacity: 0;
    transform: scale(0.95) translateY(0.5rem);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

@keyframes popover-slide-in-from-left {
  from {
    opacity: 0;
    transform: scale(0.95) translateX(-0.5rem);
  }
  to {
    opacity: 1;
    transform: scale(1) translateX(0);
  }
}

@keyframes popover-slide-in-from-right {
  from {
    opacity: 0;
    transform: scale(0.95) translateX(0.5rem);
  }
  to {
    opacity: 1;
    transform: scale(1) translateX(0);
  }
}

.jgis-popover-content {
  position: relative;
  z-index: 50;
  display: flex;
  flex-direction: column;
  gap: 0.625rem;
  width: 18rem;
  padding: 0.625rem;
  border-radius: 0.5rem;
  font-size: 0.875rem;
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  border: 1px solid
    color-mix(in srgb, var(--jp-ui-font-color0), transparent 90%);
  box-shadow:
    0 4px 6px -1px rgba(0, 0, 0, 0.1),
    0 2px 4px -2px rgba(0, 0, 0, 0.1);
  outline: none;
  transform-origin: var(--radix-popover-content-transform-origin);
  transition-duration: 100ms;
}

.jgis-popover-content[data-state='open'][data-side='bottom'] {
  animation: popover-slide-in-from-top 100ms ease-out;
}

.jgis-popover-content[data-state='open'][data-side='top'] {
  animation: popover-slide-in-from-bottom 100ms ease-out;
}

.jgis-popover-content[data-state='open'][data-side='left'] {
  animation: popover-slide-in-from-right 100ms ease-out;
}

.jgis-popover-content[data-state='open'][data-side='right'] {
  animation: popover-slide-in-from-left 100ms ease-out;
}

.jgis-popover-content[data-state='open']:not([data-side]) {
  animation: popover-fade-zoom-in 100ms ease-out;
}

.jgis-popover-content[data-state='closed'] {
  animation: popover-fade-zoom-out 100ms ease-in;
}

.jgis-popover-header {
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
  font-size: 0.875rem;
}

.jgis-popover-title {
  font-weight: 500;
}

.jgis-popover-description {
  color: var(--jp-ui-font-color2);
}
`,""]),e.d(r,{},{A:n})},5436(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-attribute-row {
  display: flex;
  align-items: center;
  gap: 0.25rem;
  padding: 0.25rem 0.375rem;
}

.jgis-attribute-rows > .jgis-attribute-row:nth-child(odd) {
  background-color: var(--jp-layout-color1);
}

.jgis-attribute-rows > .jgis-attribute-row:nth-child(even) {
  background-color: var(--jp-layout-color0);
}

.jgis-attribute-rows > .jgis-attribute-row:first-child {
  border-top-left-radius: var(--jp-border-radius);
  border-top-right-radius: var(--jp-border-radius);
}

.jgis-attribute-rows > .jgis-attribute-row:last-child {
  border-bottom-left-radius: var(--jp-border-radius);
  border-bottom-right-radius: var(--jp-border-radius);
}

.jgis-attribute-row-add {
  justify-content: flex-end;
  padding-right: 0;
}

.jgis-attribute-row-editor {
  align-items: center;
}

.jgis-attribute-col-key {
  flex: 0 0 clamp(7rem, 30%, 12rem);
  min-width: 0;
  max-width: clamp(7rem, 30%, 12rem);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.jgis-attribute-col-value {
  flex: 1 1 auto;
  min-width: 0;
  max-width: 100%;
  overflow-wrap: anywhere;
}

.jgis-attribute-col-actions {
  display: inline-flex;
  flex: 0 0 auto;
  align-self: center;
}

.jgis-attribute-add-button {
  justify-content: center;
}
`,""]),e.d(r,{},{A:n})},6746(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-radio-group {
  display: grid;
  gap: 0.75rem;
}

.jgis-radio-group-item {
  aspect-ratio: 1 / 1;
  width: 1rem;
  height: 1rem;
  flex-shrink: 0;
  border-radius: 9999px !important;
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color0);
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  transition:
    color 0.15s ease-in-out,
    box-shadow 0.15s ease-in-out;
  outline: none;
  cursor: pointer;
}

.jgis-radio-group-item:focus-visible {
  border-color: var(--jp-ui-font-color0);
  box-shadow: 0 0 0 3px
    color-mix(in srgb, var(--jp-ui-font-color0), transparent 50%);
}

.jgis-radio-group-item[aria-invalid='true'] {
  border-color: var(--jp-error-color0, #dc2626);
  box-shadow: 0 0 0 3px
    color-mix(in srgb, var(--jp-error-color0, #dc2626), transparent 80%);
}

.jgis-radio-group-item:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}

.jgis-radio-group-indicator {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.jgis-radio-group-indicator-icon {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0.5rem;
  height: 0.5rem;
  transform: translate(-50%, -50%);
  fill: currentColor;
}
`,""]),e.d(r,{},{A:n})},5127(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-separator {
  flex-shrink: 0;
  background-color: var(--jp-border-color0);
}

.jgis-separator[data-orientation='horizontal'] {
  height: 1px;
  width: 100%;
}

.jgis-separator[data-orientation='vertical'] {
  width: 1px;
  align-self: stretch;
}
`,""]),e.d(r,{},{A:n})},4835(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`@keyframes sheet-fade-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes sheet-fade-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}

@keyframes sheet-slide-in-right {
  from {
    transform: translateX(100%);
  }
  to {
    transform: translateX(0);
  }
}

@keyframes sheet-slide-out-right {
  from {
    transform: translateX(0);
  }
  to {
    transform: translateX(100%);
  }
}

@keyframes sheet-slide-in-left {
  from {
    transform: translateX(-100%);
  }
  to {
    transform: translateX(0);
  }
}

@keyframes sheet-slide-out-left {
  from {
    transform: translateX(0);
  }
  to {
    transform: translateX(-100%);
  }
}

@keyframes sheet-slide-in-top {
  from {
    transform: translateY(-100%);
  }
  to {
    transform: translateY(0);
  }
}

@keyframes sheet-slide-out-top {
  from {
    transform: translateY(0);
  }
  to {
    transform: translateY(-100%);
  }
}

@keyframes sheet-slide-in-bottom {
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
}

@keyframes sheet-slide-out-bottom {
  from {
    transform: translateY(0);
  }
  to {
    transform: translateY(100%);
  }
}

.jgis-sheet-overlay {
  position: fixed;
  inset: 0;
  z-index: 50;
  background-color: color-mix(in srgb, black, transparent 90%);
  backdrop-filter: blur(2px);
  transition-duration: 0.1s;
}

.jgis-sheet-overlay[data-state='open'] {
  animation: sheet-fade-in 0.1s ease-out;
}

.jgis-sheet-overlay[data-state='closed'] {
  animation: sheet-fade-out 0.1s ease-in;
}

.jgis-sheet-content {
  position: fixed;
  z-index: 50;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  font-size: 0.875rem;
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  border-color: var(--jp-border-color0);
  box-shadow:
    0 10px 15px -3px rgba(0, 0, 0, 0.1),
    0 4px 6px -2px rgba(0, 0, 0, 0.05);
  transition-duration: 0.2s;
  transition-timing-function: ease-in-out;
  background-clip: padding-box;
  overflow: scroll;
}

/* Right */
.jgis-sheet-content[data-side='right'] {
  top: 0;
  right: 0;
  bottom: 0;
  height: 100%;
  width: 75%;
  border-left-width: 1px;
  border-left-style: solid;
}

.jgis-sheet-content[data-side='right'][data-state='open'] {
  animation:
    sheet-fade-in 0.2s ease-out,
    sheet-slide-in-right 0.2s ease-out;
}

.jgis-sheet-content[data-side='right'][data-state='closed'] {
  animation:
    sheet-fade-out 0.2s ease-in,
    sheet-slide-out-right 0.2s ease-in;
}

@media (min-width: 640px) {
  .jgis-sheet-content[data-side='right'] {
    max-width: 50%;
  }
}

/* Left */
.jgis-sheet-content[data-side='left'] {
  top: 0;
  bottom: 0;
  left: 0;
  height: 100%;
  width: 75%;
  border-right-width: 1px;
  border-right-style: solid;
}

.jgis-sheet-content[data-side='left'][data-state='open'] {
  animation:
    sheet-fade-in 0.2s ease-out,
    sheet-slide-in-left 0.2s ease-out;
}

.jgis-sheet-content[data-side='left'][data-state='closed'] {
  animation:
    sheet-fade-out 0.2s ease-in,
    sheet-slide-out-left 0.2s ease-in;
}

@media (min-width: 640px) {
  .jgis-sheet-content[data-side='left'] {
    max-width: 24rem;
  }
}

/* Top */
.jgis-sheet-content[data-side='top'] {
  left: 0;
  right: 0;
  top: 0;
  height: auto;
  border-bottom-width: 1px;
  border-bottom-style: solid;
}

.jgis-sheet-content[data-side='top'][data-state='open'] {
  animation:
    sheet-fade-in 0.2s ease-out,
    sheet-slide-in-top 0.2s ease-out;
}

.jgis-sheet-content[data-side='top'][data-state='closed'] {
  animation:
    sheet-fade-out 0.2s ease-in,
    sheet-slide-out-top 0.2s ease-in;
}

/* Bottom */
.jgis-sheet-content[data-side='bottom'] {
  left: 0;
  right: 0;
  bottom: 0;
  height: auto;
  border-top-width: 1px;
  border-top-style: solid;
}

.jgis-sheet-content[data-side='bottom'][data-state='open'] {
  animation:
    sheet-fade-in 0.2s ease-out,
    sheet-slide-in-bottom 0.2s ease-out;
}

.jgis-sheet-content[data-side='bottom'][data-state='closed'] {
  animation:
    sheet-fade-out 0.2s ease-in,
    sheet-slide-out-bottom 0.2s ease-in;
}

.jgis-sheet-close {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
}

.jgis-sheet-header {
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
  padding: 0 1rem;
}

.jgis-sheet-footer {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding: 1rem;
  margin-top: auto;
}

.jgis-sheet-title {
  font-size: 1rem;
  font-weight: 500;
  color: var(--jp-ui-font-color0);
}

.jgis-sheet-description {
  font-size: 0.875rem;
  color: var(--jp-ui-font-color2);
}
`,""]),e.d(r,{},{A:n})},1399(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-slider {
  position: relative;
  display: flex;
  width: 100%;
  touch-action: none;
  align-items: center;
  user-select: none;
}

.jgis-slider[data-disabled] {
  opacity: 0.5;
}

.jgis-slider[data-orientation='vertical'] {
  height: 100%;
  min-height: 10rem;
  width: auto;
  flex-direction: column;
}

.jgis-slider-track {
  position: relative;
  flex-grow: 1;
  overflow: hidden;
  border-radius: 9999px;
  background-color: var(--jp-layout-color3);
}

.jgis-slider[data-orientation='horizontal'] .jgis-slider-track {
  height: 0.375rem;
  width: 100%;
}

.jgis-slider[data-orientation='vertical'] .jgis-slider-track {
  height: 100%;
  width: 0.375rem;
}

.jgis-slider-range {
  position: absolute;
  background-color: var(--jp-accent-color1);
  user-select: none;
}

.jgis-slider[data-orientation='horizontal'] .jgis-slider-range {
  height: 100%;
}

.jgis-slider[data-orientation='vertical'] .jgis-slider-range {
  width: 100%;
}

.jgis-slider-thumb {
  position: relative;
  display: block;
  width: 0.75rem;
  height: 0.75rem;
  flex-shrink: 0;
  border-radius: 9999px;
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color0);
  user-select: none;
  transition:
    color 150ms cubic-bezier(0.4, 0, 0.2, 1),
    box-shadow 150ms cubic-bezier(0.4, 0, 0.2, 1);
  outline: none;
  cursor: pointer;
}

.jgis-slider-thumb::after {
  content: '';
  position: absolute;
  inset: -0.5rem;
}

.jgis-slider-thumb:hover,
.jgis-slider-thumb:focus-visible,
.jgis-slider-thumb:active {
  box-shadow: 0 0 0 3px
    color-mix(in srgb, var(--jp-brand-color1), transparent 50%);
}

.jgis-slider-thumb:focus-visible {
  outline: none;
}

.jgis-slider-thumb:disabled {
  pointer-events: none;
  opacity: 0.5;
}
`,""]),e.d(r,{},{A:n})},896(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-switch {
  display: inline-flex;
  height: 1.15rem;
  width: 2.5rem;
  padding: 2px;
  flex-shrink: 0;
  align-items: center;
  border-radius: 9999px !important;
  border: 1px solid transparent;
  /* border: 1px solid var(--jp-brand-color3); */
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  transition: all 150ms cubic-bezier(0.4, 0, 0.2, 1);
  outline: none;
  cursor: pointer;
}

/* JupyterLab dialogs add jp-mod-styled to buttons; undo flat-button sizing. */
button.jgis-switch.jp-mod-styled {
  height: 1.15rem;
  width: 2.5rem;
  min-width: 2.5rem;
  padding: 2px;
  border: 1px solid transparent;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
}

.jgis-switch:focus-visible {
  border-color: var(--jp-border-color0);
  box-shadow: 0 0 0 3px
    color-mix(in srgb, var(--jp-ui-font-color0), transparent 50%);
}

.jgis-switch:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}

.jgis-switch[data-state='checked'] {
  background-color: var(--jp-accent-color1);
}

.jgis-switch[data-state='unchecked'] {
  background-color: var(--jp-layout-color3);
}

.jgis-switch:hover[data-state='checked'] {
  background-color: var(--jp-accent-color1);
}

.jgis-switch:hover[data-state='unchecked'] {
  background-color: var(--jp-layout-color3);
}

button.jgis-switch.jp-mod-styled:hover[data-state='checked'] {
  background-color: var(--jp-accent-color1);
}

button.jgis-switch.jp-mod-styled:hover[data-state='unchecked'] {
  background-color: var(--jp-layout-color3);
}

.jgis-switch-thumb {
  background-color: var(--jp-layout-color1);
  pointer-events: none;
  display: block;
  width: 0.75rem;
  height: 0.75rem;
  border-radius: 9999px;
  box-shadow: none;
  transition: transform 150ms cubic-bezier(0.4, 0, 0.2, 1);
  transform: translateX(0);
}

.jgis-switch-thumb[data-state='checked'] {
  transform: translateX(1.4rem);
}

.jgis-switch-thumb[data-state='unchecked'] {
  transform: translateX(0);
}

@media (prefers-color-scheme: dark) {
  .jgis-switch-thumb[data-state='unchecked'] {
    background-color: var(--jp-ui-font-color0);
  }

  .jgis-switch-thumb[data-state='checked'] {
    background-color: var(--jp-layout-color1);
  }
}
`,""]),e.d(r,{},{A:n})},9836(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-panel-tabs {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: var(--jp-layout-color0);
}

.jgis-tabs-list {
  display: inline-flex;
  height: 2.5rem;
  align-items: center;
  justify-content: space-evenly;
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color0);
  cursor: grab;
  gap: 1rem;
  width: 100%;
  font-size: 9px;
  overflow-x: auto;
}

.jgis-tabs-list:active {
  cursor: grabbing;
}

.jgis-tabs-trigger {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
  border-radius: 0.25rem;
  padding: 0.25rem 0.5rem;
  font-size: var(--jp-ui-font-size2);
  font-weight: 500;
  outline: none;
  transition: all 0.3s ease;
  border: 1px solid transparent;
  background-color: transparent;
}

.jgis-tabs-trigger:focus-visible {
  box-shadow:
    0 0 0 2px var(--jp-accent-color0),
    0 0 0 4px var(--jp-accent-color0);
}

.jgis-tabs-trigger:disabled {
  pointer-events: none;
  opacity: 0.5;
}

.jgis-tabs-trigger[data-state='active'] {
  background-color: var(--jp-layout-color2);
  color: var(--jp-ui-font-color0);
  box-shadow: 0 1px 2px
    color-mix(in srgb, var(--jp-layout-color0), transparent 90%);
}

.jgis-tabs-content {
  outline: none;
  width: 100%;
  overflow-y: auto;
  /* max-height: 480px; */
  padding-top: 0.5rem;
}

.jgis-tabs-content:focus-visible {
  outline: none;
  box-shadow:
    0 0 0 2px var(--jp-accent-color0),
    0 0 0 4px var(--jp-accent-color0);
}
`,""]),e.d(r,{},{A:n})},2532(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-toggle {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 0.375rem;
  font-size: var(--jp-ui-font-size1);
  font-weight: 500;
  padding: 0.5rem 1rem;
  transition:
    color 0.3s,
    background-color 0.3s;
  outline: none;
  color: var(--jp-ui-font-color0);
  background-color: var(--jp-layout-color0);
  border: 1px solid transparent;
}

.jgis-toggle:hover {
  background-color: color-mix(
    in srgb,
    var(--jp-ui-font-color0),
    transparent 90%
  );
  color: var(--jp-ui-inverse-font-color0);
}

.jgis-toggle:focus-visible {
  box-shadow:
    0 0 0 2px var(--jp-accent-color0),
    0 0 0 4px var(--jp-accent-color0);
}

.jgis-toggle:disabled {
  pointer-events: none;
  opacity: 0.5;
}

.jgis-toggle[data-state='on'] {
  text-decoration: underline;
  text-underline-offset: 4px;
  color: var(--jp-accent-color0);
}

.jgis-toggle-default {
  background-color: transparent;
}

.jgis-toggle-outline {
  border: 1px solid var(--jp-border-color0);
  background-color: transparent;
  transition:
    background-color 0.3s,
    color 0.3s;
  color: inherit;
}

.jgis-toggle-outline:hover {
  background-color: var(--jp-accent-color0);
  color: var(--jp-ui-inverse-font-color0);
}

.jgis-toggle-default-size {
  height: 2.5rem;
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}

.jgis-toggle-small-size {
  height: 2.25rem;
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}

.jgis-toggle-large-size {
  height: 2.25rem;
  padding-left: 0.625rem;
  padding-right: 0.625rem;
}

.jgis-toggle-group-context {
  display: flex;
  align-items: center;
  justify-content: start;
  gap: 0.25rem;
}
`,""]),e.d(r,{},{A:n})},4654(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`/* Specta presentation progress bar (segment stepper) */

:root {
  --jgis-specta-dot-fill-outer: var(--jp-accent-color0);
  --jgis-specta-dot-fill-inner: var(--jp-accent-color3);
  --jgis-specta-track-fill: color-mix(
    in srgb,
    var(--jp-accent-color1) 80%,
    transparent
  );
  --jgis-specta-track-default: var(--jp-border-color0);
  --jgis-specta-smooth: cubic-bezier(0, 0.72, 0.58, 1);
}

.jgis-specta-progress .jgis-specta-progress-bar {
  display: flex;
  flex-direction: row-reverse;
  margin: auto auto 0;
  width: 31.25rem;
  max-width: 40%;
}

.jgis-specta-progress .jgis-specta-bar-segment {
  display: flex;
  flex-grow: 1;
  position: relative;
  align-items: center;
  justify-content: center;
}

/* Track fill line; :not(:last-child) below adds width/position for the connector */
.jgis-specta-progress .jgis-specta-bar-segment::after {
  content: '';
  position: absolute;
  height: 0.25rem;
  top: calc(50% - 0.125rem);
  transition: transform var(--jgis-specta-transition-duration, 0.06s)
    var(--jgis-specta-smooth);
  transform: scaleX(0);
  background: var(--jgis-specta-track-fill);
  transform-origin: left;
  z-index: 5;
}

/* Filled state: track line + dot */
.jgis-specta-progress .jgis-specta-bar-segment[data-filled]::after {
  transform: scaleX(1);
}

/* Connector bar only when there is a segment to the right */
.jgis-specta-progress .jgis-specta-bar-segment:not(:last-child)::before,
.jgis-specta-progress .jgis-specta-bar-segment:not(:last-child)::after {
  content: '';
  width: calc(100% - 1.5rem);
  position: absolute;
  right: calc(50% + 0.75rem);
}

.jgis-specta-progress .jgis-specta-bar-segment:not(:last-child)::before {
  height: 0.5rem;
  top: calc(50% - 0.25rem);
  background: var(--jgis-specta-track-default);
}

.jgis-specta-progress .jgis-specta-bar-segment:not(:last-child)::after {
  transition-delay: 0s;
}

.jgis-specta-progress .jgis-specta-progress-input {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 1.875rem;
  height: 1.875rem;
  margin: 0;
  padding: 0;
  border: 3px solid var(--jgis-specta-track-default);
  border-radius: 50%;
  background: transparent;
  cursor: pointer;
  box-shadow:
    inset 2px 2px 4px rgba(0, 0, 0, 0.3),
    2px 2px 8px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  z-index: 2;
}

.jgis-specta-progress .jgis-specta-progress-input:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: 2px;
}

.jgis-specta-progress .jgis-specta-progress-input::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: radial-gradient(
    circle at center,
    var(--jgis-specta-dot-fill-inner),
    var(--jgis-specta-dot-fill-outer)
  );
  transform: scale(0.3);
  opacity: 0;
  transition:
    transform 0.2s var(--jgis-specta-smooth),
    opacity 0.2s var(--jgis-specta-smooth);
  pointer-events: none;
}

.jgis-specta-progress
  .jgis-specta-bar-segment[data-filled]
  .jgis-specta-progress-input::before {
  transform: none;
  opacity: 1;
}

/* Dot fill delay: 0 when going prev; after track duration when data-direction="next" */
.jgis-specta-progress
  .jgis-specta-bar-segment:not(:last-child)
  .jgis-specta-progress-input::before {
  transition-delay: 0s;
}
.jgis-specta-progress[data-direction='next']
  .jgis-specta-bar-segment:not(:last-child)
  .jgis-specta-progress-input::before {
  transition-delay: var(--jgis-specta-transition-duration, 0.3s);
}

.jgis-specta-progress {
  box-sizing: border-box;
  position: fixed;
  bottom: 1.125rem;
  width: 100%;
  z-index: 40;
}

.jgis-specta-progress *,
.jgis-specta-progress *::before,
.jgis-specta-progress *::after {
  box-sizing: inherit;
}
`,""]),e.d(r,{},{A:n})},3629(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-stac-browser-collection {
  flex-wrap: wrap;
  margin-top: 0.5rem;
}

.jgis-stac-browser-section-item {
  border-radius: 1rem;
  cursor: pointer;
}

.jgis-button.jgis-stac-browser-results-item {
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  white-space: normal;
  height: auto;
}

.jgis-stac-browser-results-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  word-break: break-word;
  padding: 0.25rem;
  margin-right: 0.5rem;
  align-self: center;
}

.jgis-stac-datepicker-full-width {
  width: 100%;
}

.jgis-stac-datepicker-button {
  padding: 0 0.5rem;
  width: 100%;
}

.jgis-stac-browser-filters-panel {
  min-height: 145px;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  align-items: flex-start;
  padding: 0 0.5rem;
}

.jgis-stac-filter-trigger {
  max-width: fit-content;
  border: 1px solid var(--jp-border-color0);
  padding: 0.5rem;
  cursor: pointer;
  font-weight: bold;
  display: flex;
  align-items: center;
  gap: 0.15rem;
}

.jgis-stac-filter-trigger:disabled {
  cursor: not-allowed;
}

.jgis-stac-filter-section-container {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.jgis-stac-filter-section-badges {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
}

.jgis-stac-datepicker-icon {
  width: 1rem;
  height: 1rem;
}

.jgis-stac-badge {
  gap: 0.25rem;
  padding-right: 0.3rem;
}

.jgis-stac-badge-icon:hover {
  background-color: color-mix(in srgb, var(--jp-error-color0), transparent 20%);
}

.jgis-stac-filter-extension-panel {
  padding: 0 1rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.jgis-stac-filter-extension-section {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.jgis-stac-filter-extension-label {
  font-size: 0.875rem;
  font-weight: 500;
}

.jgis-stac-filter-extension-select {
  max-width: 200px;
}

.jgis-stac-filter-extension-input[data-slot='input'] {
  height: 1.5rem;
  padding: 1rem 0.5rem;
}

.jgis-stac-filter-extension-button-container {
  padding-top: 0.5rem;
  border-top: 1px solid var(--jp-border-color0);
}

.jgis-stac-filter-extension-button {
  padding: 0.5rem 1rem;
  border-radius: var(--jp-border-radius, 0.375rem);
  border: 1px solid var(--jp-border-color0);
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  cursor: pointer;
  box-sizing: border-box;
}

.jgis-stac-panel-tabs-list {
  border-radius: 0;
}

.jgis-stac-panel-placeholder {
  padding: 1rem;
  text-align: center;
  color: var(--jp-ui-font-color2);
}

.jgis-stac-panel-provider-select-container {
  margin: 0 1rem 1rem 1rem;
}

.jgis-stac-panel-provider-select {
  width: 100%;
  padding: 0.5rem;
}

/* QueryableComboBox styles */
.jgis-queryable-combo-container {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

/* Modifiers for queryable combo - uses shared combobox base */
.jgis-queryable-combo-button {
  width: 100%;
}

/* More specific selector to override Input styles for queryable combo */
.jgis-input.jgis-queryable-combo-input,
.jgis-queryable-combo-input[data-slot='input'] {
  padding: 0.5rem;
  /* padding-left: 1rem; */
  height: 1.5rem;
}

/* More specific selector to override combobox button styles for operator Select */
.jgis-button.jgis-combobox-button.jgis-queryable-combo-operator {
  padding: 0.25rem;
}

/* More specific selector to override button base styles for Select/SingleDatePicker buttons */
/* Include jgis-combobox-button to increase specificity for Select components */
.jgis-button.jgis-combobox-button.jgis-queryable-combo-input,
.jgis-button.jgis-queryable-combo-input {
  padding: 0.5rem;
  /* padding-left: 1rem; */
  height: 1.5rem;
}

.jgis-button.jgis-combobox-button.jgis-queryable-combo-input
  > .jgis-combobox-button-text {
  text-align: left;
}

/* More specific selector to override button base styles */
.jgis-button.jgis-queryable-combo-input-date-picker {
  justify-content: flex-start;
}

.jgis-queryable-combo-input.jgis-combobox-button-text {
  display: flex;
  justify-content: flex-start;
}

.jgis-queryable-rows-container {
  display: grid;
  grid-template-columns: auto auto 1fr;
  align-items: center;
  gap: 0.5rem;
}

.jgis-queryable-row {
  display: contents;
}

.jgis-stac-queryable-filters {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.jgis-stac-queryable-filters-radio-group {
  display: flex;
  gap: 0.5rem;
}

.jgis-stac-queryable-filters-radio-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

/* StacPanelResults styles */
.jgis-stac-panel-results-pagination {
  margin-top: 0;
}

.jgis-panel-tab-content.jgis-panel-tab-content-stac-panel {
  padding-top: 0;
  border-top: 1px solid var(--jp-border-color0);
}

.jgis-panel-tab-content.jgis-panel-tab-content-stac-panel
  .jgis-stac-panel-tabs-list {
  border-radius: 0;
}
`,""]),e.d(r,{},{A:n})},8367(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-status-bar {
  display: flex;
  justify-content: space-around;
  align-items: center;
  height: 16px;
  background-color: var(--jp-layout-color1);
  font-size: var(--jp-ui-font-size0);
  z-index: 1000;
}

.jgis-status-bar-item {
  flex: 0 0 content;
}

.jgis-status-bar-coords {
  min-width: 160px;
}
`,""]),e.d(r,{},{A:n})},974(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-story-editor-dialog .jp-Dialog-header {
  font-weight: bold;
}

.jgis-story-editor-dialog .jp-Dialog-content {
  width: calc(90% - 4rem);
  max-width: 56rem;
  height: fit-content;
  max-height: 80%;
  overflow: auto;
}

.jgis-story-editor-dialog:has(.jgis-story-editor) .jp-Dialog-content {
  max-width: 72rem;
  width: min(calc(92vw - 4rem), 72rem);
  max-height: 85vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

@media (max-width: 960px) {
  .jgis-story-editor-dialog .jp-Dialog-header {
    display: none;
  }

  .jgis-story-editor-dialog .jp-Dialog-content {
    width: 100%;
    max-width: 100%;
    max-height: 90%;
    margin: 0;
    border-radius: 0;
    padding-left: 8px;
    padding-right: 8px;
  }
}

.jgis-story-editor {
  display: flex;
  flex-direction: column;
  min-height: min(70vh, 40rem);
  max-height: min(78vh, 44rem);
  gap: 0.75rem;
}

.jgis-story-editor-stack {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.jgis-story-editor-stack--tight {
  gap: 0.5rem;
}

.jgis-story-editor-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex-wrap: wrap;
  font-size: 0.8rem;
}

.jgis-story-editor-split {
  display: flex;
  gap: 1rem;
  align-items: start;
}

.jgis-story-editor-split > * {
  flex: 1 1 0;
  min-width: 0;
}

.jgis-story-editor-slider {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex: 1 1 0;
}

.jgis-story-editor-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.25rem;
  align-items: center;
}

.jgis-story-editor-label {
  font-size: 0.78rem;
  font-weight: 600;
  color: var(--jp-ui-font-color1);
}

.jgis-story-editor-eyebrow {
  font-size: 0.72rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: var(--jp-ui-font-color2);
}

.jgis-story-editor-help {
  margin: 0;
  font-size: 0.8rem;
  color: var(--jp-ui-font-color2);
  line-height: 1.4;
}

.jgis-story-editor-field-error {
  margin: 0;
  font-size: 0.8rem;
  color: var(--jp-error-color1);
}

.jgis-story-editor-field {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  font-size: 0.8rem;
}

.jgis-story-editor-field > span {
  color: var(--jp-ui-font-color2);
}

.jgis-story-editor-block {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.jgis-story-editor-section {
  border: 1px solid var(--jp-border-color0);
  border-radius: var(--jp-border-radius);
  background-color: var(--jp-layout-color0);
}

.jgis-story-editor-section-trigger {
  display: flex;
  gap: 1rem;
  align-items: center;
  cursor: pointer;
  padding: 0.5rem 0.25rem;
  background-color: var(--jp-layout-color0);
  border-radius: var(--jp-border-radius);
}

.jgis-story-editor-section-trigger[data-state='open'] {
  background-color: var(--jp-layout-color3);
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
}

.jgis-story-editor-section-trigger span {
  font-weight: bold;
}

.jgis-story-editor-section-body {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  min-width: 0;
  max-width: 100%;
}

.jgis-story-editor-section-body[data-state='open'] {
  padding: 0.5rem;
}

.jgis-story-editor-surface {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  padding: 0.25rem;
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color1);
  overflow: hidden;
}

.jgis-story-editor-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
  flex-shrink: 0;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid var(--jp-border-color1);
}

.jgis-story-editor-context-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 0.5rem;
  min-width: 0;
}

.jgis-story-editor-toolbar-title[data-slot='input'] {
  flex: 1 1 12rem;
  min-width: 8rem;
  max-width: 24rem;
  height: 1.75rem;
  padding: 0.125rem 0.375rem;
  font-size: 0.875rem;
  font-weight: 600;
  border-color: transparent;
  box-shadow: none;
  background-color: transparent;
}

.jgis-story-editor-toolbar-title[data-slot='input']:hover {
  border-color: var(--jp-brand-color2);
  background-color: var(--jp-layout-color1);
}

.jgis-story-editor-toolbar-title[data-slot='input']:focus-visible {
  border-color: var(--jp-brand-color1);
  background-color: var(--jp-layout-color1);
  box-shadow: 0 0 0 2px
    color-mix(in srgb, var(--jp-brand-color1) 20%, transparent);
}

.jgis-story-editor-context-meta-group {
  display: flex;
  gap: 0.75rem;
  justify-content: center;
  align-items: center;
  flex-shrink: 0;
}

.jgis-story-editor-context-meta {
  font-size: 0.8rem;
  color: var(--jp-ui-font-color2);
}

.jgis-story-editor-settings-sheet-body {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  padding: 0 1rem 1rem;
  overflow: auto;
}

.jgis-native-select.jgis-story-editor-story-type-native-select {
  width: 100%;
}

.jgis-story-editor-settings-section {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding-top: 0.25rem;
  border-top: 1px solid var(--jp-border-color2);
}

.jgis-story-editor-width-custom {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 0.35rem;
  align-items: center;
  max-width: fit-content;
}

.jgis-story-editor-toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  font-size: 0.8rem;
}

.jgis-story-editor-main {
  display: flex;
  flex: 1;
  min-height: 0;
  gap: 0;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  overflow: hidden;
}

.jgis-story-editor-segment-list {
  flex: 0 0 15%;
  min-width: 9.5rem;
  max-width: 12rem;
  display: flex;
  flex-direction: column;
  background: var(--jp-layout-color1);
  border-right: 1px solid var(--jp-border-color1);
}

.jgis-story-editor-field > input,
.jgis-story-editor-field > textarea {
  width: 100%;
}

.jgis-story-editor-segment-list-header {
  padding: 0.5rem 0.75rem;
  border-bottom: 1px solid var(--jp-border-color2);
}

.jgis-story-editor-segment-list-items {
  flex: 1;
  overflow: auto;
  padding: 0.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.jgis-story-editor-segment-drag-wrapper {
  border-radius: var(--jp-border-radius);
}

.jgis-story-editor-segment-row {
  display: flex;
  align-items: stretch;
  gap: 0.125rem;
}

.jgis-story-editor-segment-drag-handle {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 1.25rem;
  flex-shrink: 0;
  cursor: grab;
  color: var(--jp-ui-font-color3);
  border-radius: var(--jp-border-radius);
}

.jgis-story-editor-segment-drag-handle:hover {
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color2);
}

.jgis-story-editor-segment-drag-handle:active {
  cursor: grabbing;
}

.jgis-story-editor-segment-row .jgis-story-editor-segment-item {
  flex: 1;
  min-width: 0;
}

.jgis-story-editor-segment-list-empty {
  margin: 0.5rem;
  font-size: 0.75rem;
}

.jgis-story-editor-workspace-empty {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 12rem;
  padding: 1.5rem;
  font-size: 0.85rem;
  text-align: center;
}

.jgis-story-editor-workspace-empty p {
  margin: 0;
  color: var(--jp-ui-font-color2);
}

.jgis-story-editor-segment-item {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  grid-template-areas:
    'index title'
    'index type';
  gap: 0.125rem 0.375rem;
  width: 100%;
  padding: 0.625rem 0.5rem;
  border: 1px solid transparent;
  border-radius: var(--jp-border-radius);
  background: transparent;
  color: var(--jp-ui-font-color1);
  font: inherit;
  text-align: left;
  cursor: pointer;
}

/* JupyterLab dialogs add jp-mod-styled to buttons; undo flat-button sizing. */
button.jgis-story-editor-segment-item.jp-mod-styled {
  height: auto;
  line-height: normal;
  padding: 0.625rem 0.5rem;
  letter-spacing: normal;
  text-align: left;
  border: 1px solid transparent;
}

.jgis-story-editor-segment-item:hover {
  background: var(--jp-layout-color2);
}

.jgis-story-editor-segment-item--selected,
button.jgis-story-editor-segment-item.jp-mod-styled.jgis-story-editor-segment-item--selected {
  background: color-mix(in srgb, var(--jp-brand-color1) 12%, transparent);
  border-color: color-mix(in srgb, var(--jp-brand-color1) 35%, transparent);
}

.jgis-story-editor-segment-item-index {
  grid-area: index;
  align-self: center;
  font-size: 0.75rem;
  color: var(--jp-ui-font-color2);
}

.jgis-story-editor-segment-item-title {
  grid-area: title;
  min-width: 0;
  font-size: 0.82rem;
  font-weight: 500;
  color: var(--jp-ui-font-color1);
  white-space: break-spaces;
}

.jgis-story-editor-segment-item-type {
  grid-area: type;
  min-width: 0;
  font-size: 0.68rem;
  color: var(--jp-ui-font-color2);
}

.jgis-story-editor-add-segment {
  margin: 0.5rem;
  width: calc(100% - 1rem);
}

.jgis-story-editor-segment-list--mobile {
  flex: none;
  flex-direction: row;
  align-items: center;
  gap: 0.5rem;
  max-width: none;
  min-width: 0;
  max-height: none;
  padding: 0.5rem;
  border-right: none;
  border-bottom: 1px solid var(--jp-border-color1);
}

.jgis-story-editor-segment-list--mobile .jgis-story-editor-segment-picker {
  flex: 1 1 auto;
  min-width: 0;
}

.jgis-story-editor-segment-list--mobile .jgis-story-editor-add-segment {
  flex: 0 0 auto;
  width: auto;
  min-width: 2.25rem;
  margin: 0;
  justify-content: center;
}

.jgis-story-editor-segment-list--mobile .jgis-story-editor-segment-list-empty {
  flex: 1 1 auto;
  margin: 0;
}

.jgis-story-editor-workspace {
  flex: 1;
  min-width: 0;
  overflow: auto;
  background: var(--jp-layout-color0);
}

.jgis-story-editor-segment {
  padding: 0.75rem 1rem 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.jgis-story-editor-segment-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.75rem;
}

.jgis-story-editor-segment-mode-picker {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem;
}

.jgis-story-editor-segment-mode-picker
  .jgis-button.jgis-story-editor-segment-mode-card {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 0.25rem;
  padding: 0.625rem 0.75rem;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color1);
  color: inherit;
  font: inherit;
  text-align: left;
  height: auto;
  max-width: unset;
  cursor: pointer;
}

.jgis-story-editor-segment-mode-picker
  .jgis-button.jgis-story-editor-segment-mode-card
  strong {
  font-size: 0.85rem;
}

.jgis-story-editor-segment-mode-picker
  .jgis-button.jgis-story-editor-segment-mode-card
  span {
  font-size: 0.72rem;
  color: var(--jp-ui-font-color2);
  line-height: 1.35;
}

.jgis-story-editor-segment-mode-picker
  .jgis-button.jgis-story-editor-segment-mode-card--selected {
  border-color: var(--jp-brand-color1);
  background: color-mix(
    in srgb,
    var(--jp-brand-color1) 8%,
    var(--jp-layout-color1)
  );
}

.jgis-story-map-interaction-bar-root {
  pointer-events: auto;
}

.jGIS-Mainview-Container:has(.jgis-story-map-interaction-bar-root) {
  position: relative;
}

.jgis-story-map-interaction-bar-root--overlay-bottom {
  position: absolute;
  left: 50%;
  bottom: 1.25rem;
  transform: translateX(-50%);
  z-index: 50;
}

.jgis-story-map-interaction-bar-root--main-top-left {
  position: absolute;
  top: 0.75rem;
  left: 0.75rem;
  bottom: auto;
  transform: none;
  z-index: 50;
}

.jgis-story-map-interaction-bar {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.625rem 0.875rem;
  border-radius: var(--jp-border-radius);
  border: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color1);
  box-shadow: 0 4px 16px
    color-mix(in srgb, var(--jp-shadow-ambient-color, #000) 18%, transparent);
}

.jgis-story-map-interaction-bar-message {
  margin: 0;
  font-size: 0.82rem;
  color: var(--jp-ui-font-color1);
  white-space: nowrap;
}

.jgis-story-map-interaction-bar-actions {
  display: flex;
  gap: 0.375rem;
  flex-shrink: 0;
}

.jgis-narrow .jgis-story-map-interaction-bar-root--overlay-bottom {
  left: 0.75rem;
  right: 0.75rem;
  width: auto;
  transform: none;
}

.jgis-narrow .jgis-story-map-interaction-bar {
  flex-direction: column;
  align-items: stretch;
  gap: 0.5rem;
  width: 100%;
  box-sizing: border-box;
}

.jgis-narrow .jgis-story-map-interaction-bar-message {
  white-space: normal;
  overflow-wrap: break-word;
}

.jgis-narrow .jgis-story-map-interaction-bar-actions {
  width: 100%;
  flex-wrap: nowrap;
  flex-shrink: 1;
}

.jgis-narrow .jgis-story-map-interaction-bar-actions > .jgis-button,
.jgis-narrow .jgis-story-map-interaction-bar-actions > button {
  flex: 1 1 0;
  min-width: 0;
}

.jgis-story-editor-segment-image-card-media {
  display: block;
  width: auto;
  height: auto;
  max-width: 100%;
  object-fit: contain;
}

.jgis-story-editor-markdown-tabs {
  border-top-left-radius: var(--jp-border-radius);
  border-top-right-radius: var(--jp-border-radius);
}

.jgis-story-editor-markdown-tabs .jgis-tabs-trigger {
  font-size: 0.75rem;
  padding: 0.2rem 0.45rem;
  color: var(--jp-ui-font-color2);
}

.jgis-tabs-content.jgis-story-editor-markdown-tab-content {
  padding-top: 0;
}

/* forceMount keeps the CodeMirror host mounted
Radix won't set hidden so do it manually */
.jgis-tabs-content.jgis-story-editor-markdown-tab-content[data-state='inactive'] {
  display: none;
}

.jgis-story-editor-markdown {
  border: 1px solid var(--jp-border-color1);
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
  background: var(--jp-layout-color1);
}

.jgis-story-editor-markdown-host {
  width: 100%;
  box-sizing: border-box;
  padding: 0;
}

.jgis-story-editor-markdown-editor {
  width: 100%;
}

.jgis-story-editor-markdown-editor .cm-editor {
  outline: none;
  background: transparent;
}

.jgis-story-editor-markdown-editor .cm-editor.cm-focused {
  outline: none;
}

.jgis-story-editor-markdown-host:focus-within {
  border-color: var(--jp-brand-color1);
  border-radius: var(--jp-border-radius);
}

.jgis-story-editor-markdown-preview {
  min-height: 6rem;
  overflow: auto;
}

.jgis-story-editor-segment-layer-grid {
  --jgis-story-editor-segment-layer-columns: minmax(0, 1fr) 3.5rem 5rem 4.5rem
    3.5rem 2.5rem;
  border-radius: var(--jp-border-radius);
  overflow: hidden;
}

.jgis-story-editor-segment-layer-header,
.jgis-story-editor-segment-layer-row {
  box-sizing: border-box;
  display: grid;
  grid-template-columns: var(--jgis-story-editor-segment-layer-columns);
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
}

.jgis-story-editor-segment-layer-header {
  font-size: 0.625rem;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--jp-ui-font-color2);
  background-color: var(--jp-layout-color2);
  border-bottom: 1px solid var(--jp-border-color2);
}

.jgis-story-editor-segment-layer-header > span:not(:first-child) {
  text-align: center;
}

.jgis-story-editor-segment-layer-list {
  padding: 0;
  margin: 0;
  list-style: none;
}

.jgis-story-editor-segment-layer-list
  > .jgis-story-editor-segment-layer-row:nth-child(odd) {
  background-color: var(--jp-layout-color1);
}

.jgis-story-editor-segment-layer-list
  > .jgis-story-editor-segment-layer-row:nth-child(even) {
  background-color: var(--jp-layout-color0);
}

.jgis-story-editor-segment-layer-name-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.jgis-story-editor-segment-layer-opacity {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.125rem;
  min-width: 0;
}

.jgis-story-editor-segment-layer-opacity input[type='range'] {
  width: 100%;
  min-width: 0;
}

.jgis-story-editor-segment-layer-opacity-value {
  font-size: 0.625rem;
  color: var(--jp-ui-font-color2);
  line-height: 1;
}

.jgis-story-editor-segment-layer-override,
.jgis-story-editor-segment-layer-reset,
.jgis-story-editor-segment-layer-visibility,
.jgis-story-editor-segment-layer-symbology {
  display: flex;
  justify-content: center;
  align-items: center;
}

.jgis-story-editor-segment-layer-override-icon {
  height: 1rem;
  width: 1rem;
  color: var(--jp-brand-color1);
}

.jgis-story-editor-segment-layer-grid--mobile {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  overflow: visible;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-list {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-row {
  grid-template-columns: minmax(0, 1fr) 1rem 1.75rem;
  grid-template-areas:
    'name override reset'
    'opacity opacity visibility'
    'symbology symbology symbology';
  gap: 0.5rem 0.625rem;
  padding: 0.625rem 0.75rem;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background-color: var(--jp-layout-color1);
  min-width: 0;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-name-text {
  grid-area: name;
  max-width: 100%;
  min-width: 0;
  font-weight: 600;
  white-space: normal;
  overflow-wrap: break-word;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-visibility {
  grid-area: visibility;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-opacity {
  grid-area: opacity;
  flex-direction: row;
  align-items: center;
  gap: 0.5rem;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-symbology {
  grid-area: symbology;
  justify-content: stretch;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-override {
  grid-area: override;
  width: 1rem;
  justify-self: center;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-reset {
  grid-area: reset;
  width: 1.75rem;
  justify-self: end;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-list
  > .jgis-story-editor-segment-layer-row:nth-child(odd),
.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-list
  > .jgis-story-editor-segment-layer-row:nth-child(even) {
  background-color: var(--jp-layout-color1);
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-opacity
  .jgis-slider,
.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-opacity
  [data-slot='slider'] {
  flex: 1 1 auto;
  min-width: 0;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-opacity-value {
  flex: 0 0 auto;
  min-width: 2.25rem;
  text-align: right;
  font-size: 0.75rem;
}

.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-symbology
  > .jgis-button,
.jgis-story-editor-segment-layer-grid--mobile
  .jgis-story-editor-segment-layer-symbology
  > button {
  width: 100%;
}

.jgis-story-editor-sheet-container {
  padding: 0 0.5rem;
}

.jgis-story-editor-sheet-footer {
  box-sizing: border-box;
  align-self: center;
  width: 100%;
  max-width: 20rem;
}

@media (max-width: 960px) {
  .jgis-story-editor {
    min-height: 0;
    max-height: none;
    height: 100%;
  }

  /* Title on its own row; actions below */
  .jgis-story-editor-context-bar {
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: stretch;
    gap: 0.375rem;
  }

  .jgis-story-editor-toolbar-title[data-slot='input'] {
    flex: none;
    width: 100%;
    min-width: 0;
    max-width: none;
  }

  .jgis-story-editor-context-meta-group {
    gap: 0.375rem;
    justify-content: flex-start;
  }

  .jgis-story-editor-context-badge {
    margin-right: auto;
  }

  .jgis-story-editor-opacity-row {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 0.5rem;
    align-items: center;
  }

  .jgis-story-editor-opacity-value {
    min-width: 2.5rem;
    text-align: right;
    font-variant-numeric: tabular-nums;
    color: var(--jp-ui-font-color2);
  }

  .jgis-story-editor-main {
    flex-direction: column;
  }

  /* Segment list chrome when the dialog is narrow */
  .jgis-story-editor-segment-list:not(.jgis-story-editor-segment-list--mobile) {
    flex: none;
    max-width: none;
    min-width: 0;
    max-height: none;
    border-right: none;
    border-bottom: 1px solid var(--jp-border-color1);
  }

  .jgis-story-editor-workspace {
    min-height: 0;
  }

  .jgis-story-editor-segment {
    padding: 0.625rem 0.75rem 1rem;
    gap: 0.625rem;
  }

  .jgis-story-editor-segment-header {
    align-items: center;
    gap: 0.5rem;
  }

  .jgis-story-editor-segment-header > div {
    flex: 1 1 auto;
    min-width: 0;
  }

  .jgis-story-editor-segment-header
    .jgis-story-editor-toolbar-title[data-slot='input'] {
    max-width: none;
  }

  /* Side-by-side mode chips; hide descriptions */
  .jgis-story-editor-segment-mode-picker {
    grid-template-columns: 1fr 1fr;
  }

  .jgis-story-editor-segment-mode-picker
    .jgis-button.jgis-story-editor-segment-mode-card {
    align-items: center;
    padding: 0.5rem 0.625rem;
  }

  .jgis-story-editor-segment-mode-picker
    .jgis-button.jgis-story-editor-segment-mode-card
    span {
    display: none;
  }

  .jgis-story-editor-row {
    flex-direction: column;
    align-items: stretch;
  }

  .jgis-story-editor-split {
    flex-direction: column;
  }

  .jgis-story-editor-row > .jgis-button,
  .jgis-story-editor-row > button {
    width: 100%;
  }
}
`,""]),e.d(r,{},{A:n})},9943(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-story-viewer-panel {
  padding: 1rem;
}

.jgis-story-segment-container {
  width: 100%;
  animation: fadeIn 0.3s ease;
  /* animation-duration is set dynamically via inline style from segment.transition.time */
}

.jgis-story-segment-container--no-segment-animation {
  animation: none;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

.jgis-story-viewer-panel * {
  box-sizing: border-box;
}

.jgis-story-viewer-image-container {
  position: relative;
  width: 100%;
  height: 30%;
}

.jgis-story-viewer-image {
  width: 100%;
  height: 100%;
  max-height: 50vh;
  object-fit: contain;
  display: block;
  border-radius: var(--jp-border-radius);
}

.jgis-story-viewer-nav-container {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  padding-bottom: 0.25rem;
}

.jgis-panels-wrapper .jgis-story-viewer-nav-container-specta-mod {
  position: fixed;
  left: 0;
  right: 0;
  width: 100vw;
  z-index: 1000;
}

.jgis-story-navbar {
  display: flex;
  gap: 8px;
  justify-content: center;
}

.jgis-story-navbar .jgis-button.jgis-story-navbar-button {
  color: var(--jp-ui-inverse-font-color0);
  background-color: var(--jp-inverse-layout-color0);
}

.jgis-story-viewer-image-container
  .jgis-story-viewer-nav-container
  .jgis-story-navbar
  .jgis-story-navbar-button {
  color: var(--jp-ui-font-color0);
  background-color: var(--jp-layout-color0);
}

.jgis-story-viewer-caption-container {
  display: flex;
  align-items: center;
  padding-top: 1rem;
}

.jgis-story-navbar.jgis-story-navbar-specta-mod {
  position: fixed;
  top: 50%;
  width: 100%;
  justify-content: space-between;
}

.jgis-story-navbar-specta-mod > .jgis-button {
  padding: 0;
}

.jgis-story-viewer-title {
  text-align: center;
}

.jgis-story-viewer-caption {
  text-align: center;
  margin: 0 auto;
}

.jgis-story-viewer-content p,
.jgis-story-viewer-content span,
.jgis-story-viewer-content li {
  font-size: var(--jp-ui-font-size2);
}

.jgis-story-viewer-content > ul {
  padding-left: 1rem;
}

.jgis-right-panel-container.jgis-specta-right-panel-container-mod {
  width: 55%;
  height: 100%;
  margin: unset;
  top: unset;
  box-shadow: unset;
  max-height: unset;
  border-bottom-right-radius: 0;
  border-top-right-radius: 0;
}

.jgis-specta-story-panel-container {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  background: linear-gradient(
    to left,
    color-mix(
        in srgb,
        var(--jgis-specta-panel-color, var(--jp-layout-color0))
          calc(var(--jgis-story-panel-opacity, 1) * 100%),
        transparent
      )
      49%,
    color-mix(
        in srgb,
        var(--jgis-specta-panel-color, var(--jp-layout-color0))
          calc(var(--jgis-story-panel-opacity, 1) * 60%),
        transparent
      )
      65%,
    color-mix(
        in srgb,
        var(--jgis-specta-panel-color, var(--jp-layout-color0))
          calc(var(--jgis-story-panel-opacity, 1) * 50%),
        transparent
      )
      70%,
    transparent 100%
  );
}

.jgis-specta-story-panel-container--solid {
  background: color-mix(
    in srgb,
    var(--jgis-specta-panel-color, var(--jp-layout-color0))
      calc(var(--jgis-story-panel-opacity, 1) * 100%),
    transparent
  );
}

.jgis-story-viewer-panel-specta-mod {
  height: 100%;
  width: 45%;
  font-size: var(--jp-ui-font-size3);
  padding-right: 0.7rem;
  color: var(--jgis-specta-text-color, var(--jp-ui-font-color1));
  background-color: transparent;
  overflow-y: auto;
  max-height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: safe center;
}

.jgis-mainview-stage {
  --jgis-story-title-bar-height: 2.5rem;
}

.jgis-story-title-bar {
  height: var(--jgis-story-title-bar-height);
  position: relative;
  z-index: 50;
  display: flex;
  justify-content: space-around;
  align-items: center;
  gap: 0.25rem;
  padding: 0 0.75rem;
  box-sizing: border-box;
  background-color: color-mix(in srgb, var(--jp-layout-color1), transparent 8%);
  pointer-events: auto;
  min-width: 0;
  overflow: hidden;
}

.jgis-story-title-bar-scroll-btn,
.jgis-story-title-bar-menu-btn {
  flex-shrink: 0;
  min-width: 2rem;
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}

.jgis-story-title-bar--mobile {
  display: grid;
  grid-template-columns: 1fr;
  align-items: center;
  padding: 0.5rem 0;
  overflow: visible;
}

.jgis-story-title-bar--mobile > * {
  grid-area: 1 / 1;
}

.jgis-story-title-bar--mobile .jgis-story-title-bar-menu-btn {
  justify-self: start;
  position: relative;
  z-index: 1;
}

.jgis-story-title-bar-active-segment {
  justify-self: center;
  max-width: calc(100% - 4rem);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  text-align: center;
  pointer-events: none;
  opacity: 1;
  font-weight: bold;
}

.jgis-story-title-bar-active-segment[data-slide-direction] {
  animation: jgis-story-title-bar-active-segment-enter 0.5s ease-out both;
}

.jgis-story-title-bar-active-segment[data-slide-direction='next'] {
  --jgis-story-title-bar-slide-offset: 0.35rem;
}

.jgis-story-title-bar-active-segment[data-slide-direction='prev'] {
  --jgis-story-title-bar-slide-offset: -0.35rem;
}

@keyframes jgis-story-title-bar-active-segment-enter {
  from {
    opacity: 0;
    transform: translateY(var(--jgis-story-title-bar-slide-offset));
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.jgis-story-title-bar-segments {
  display: flex;
  flex-wrap: nowrap;
  gap: 1.5rem;
  margin-top: 3px;
  min-width: 0;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior-x: contain;
  touch-action: pan-x;
  scrollbar-width: none;
  overflow-x: auto;
  overflow-y: hidden;
}

.jgis-story-title-bar-label {
  position: relative;
  opacity: 0.7;
  padding: 0.25rem 0;
  cursor: pointer;
  text-decoration: none;
}

.jgis-story-title-bar-label[data-state='active'] {
  opacity: 1;
  font-weight: bold;
}

.jgis-story-title-bar-segment {
  flex-shrink: 0;
  white-space: nowrap;
  border: none;
  background: transparent;
  font: inherit;
  color: inherit;
}

.jgis-popover-content.jgis-story-title-bar-segment-menu {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  min-width: 12rem;
  max-height: 16rem;
  overflow-y: auto;
  padding: 0.5rem;
  width: calc(var(--radix-popper-available-width) - 1rem);
  margin: 0 0.5rem;
  box-sizing: border-box;
}

.jgis-story-title-bar-segment-menu-item {
  width: 100%;
  border: none;
  background: transparent;
  font: inherit;
  color: inherit;
  cursor: pointer;
}

.jgis-story-stage-scroll-host {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: var(--jgis-story-title-bar-height);
  overflow-y: auto;
  overscroll-behavior: contain;
  z-index: 1;
  pointer-events: none;
  visibility: hidden;
}

.jgis-story-stage-overlay {
  position: absolute;
  inset: 0;
  top: var(--jgis-story-title-bar-height);
  z-index: 5;
}

.jgis-story-stage-overlay--sized {
  bottom: auto;
}

.jgis-story-stage-overlay--transitioning {
  overflow: hidden;
}

.jgis-story-segment-transition-stack {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  display: flex;
  flex-direction: column;
  transform: translateY(
    calc(
      var(--jgis-segment-transition-progress, 0) * -1 *
        var(--jgis-transition-translate, var(--jgis-handoff-gap-height, 100%))
    )
  );
}

.jgis-story-segment-transition-gap {
  flex-shrink: 0;
  height: var(--jgis-handoff-gap-height, 100%);
  width: 100%;
  pointer-events: none;
}

.jgis-story-segment-transition-stack .jgis-story-segment-overlay-pane {
  position: relative;
  flex-shrink: 0;
}

.jgis-story-stage-overlay-content {
  box-sizing: border-box;
  /* Background-only opacity so text stays fully opaque. */
  background-color: color-mix(
    in srgb,
    var(--jgis-specta-bg-color, var(--jp-layout-color0))
      calc(var(--jgis-story-markdown-segment-opacity, 1) * 100%),
    transparent
  );
  padding: 1rem;
}

.jgis-story-segment-overlay-pane {
  position: absolute;
  left: 0;
  right: 0;
  overflow: hidden;
}

.jgis-story-markdown-scroll-pane {
  top: 0;
  height: auto;
  box-sizing: border-box;
  width: var(--jgis-story-overlay-content-width, 100%);
}

.jgis-story-segment-transition-stack .jgis-story-map-scroll-pane {
  height: var(--jgis-handoff-gap-height, 100%);
  min-height: var(--jgis-handoff-gap-height, 100%);
}

.jgis-story-map-scroll-pane {
  top: 0;
  height: 100%;
  max-height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  box-sizing: border-box;
  background-color: transparent;
  padding-inline: 1rem;
}

.jgis-story-map-overlay-content {
  width: 25%;
  max-height: 100%;
  overflow: auto;
  padding: 1.25rem;
  box-sizing: border-box;
  border-radius: 8px;
  /* Background-only opacity so text stays fully opaque. */
  background-color: color-mix(
    in srgb,
    var(--jgis-specta-bg-color, var(--jp-layout-color0))
      calc(var(--jgis-story-panel-opacity, 1) * 100%),
    transparent
  );
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.06),
    0 4px 12px rgba(0, 0, 0, 0.1),
    0 12px 28px rgba(0, 0, 0, 0.08);
}

.jgis-story-segment-overlay-pane.jgis-story-markdown-scroll-pane:not(
    .jgis-story-markdown-scroll-pane--measure
  )
  .jgis-story-stage-overlay-content {
  box-sizing: border-box;
}

.jgis-story-markdown-scroll-pane--constrained-width
  .jgis-story-stage-overlay-content {
  border-radius: 8px;
}

.jgis-story-markdown-scroll-pane--constrained-width-bottom
  .jgis-story-stage-overlay-content {
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}

.jgis-story-markdown-scroll-pane--constrained-width-top
  .jgis-story-stage-overlay-content {
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}

.jgis-story-markdown-measure-host {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  visibility: hidden;
  pointer-events: none;
  z-index: -1;
}

.jgis-story-markdown-scroll-pane--measure {
  position: relative;
  height: auto;
}

.jgis-story-virtual-track {
  box-sizing: border-box;
  width: 100%;
  flex-shrink: 0;
  pointer-events: none;
}

.jGIS-property-panel
  .jp-FormGroup-content
  fieldset
  .jp-inputFieldWrapper
  > input#root_presentationBgColor,
.jGIS-property-panel
  .jp-FormGroup-content
  fieldset
  .jp-inputFieldWrapper
  > input#root_presentationTextColor {
  height: revert;
}

.jgis-mobile-specta-trigger-wrapper {
  position: fixed;
  bottom: 0.125rem;
  right: 0.125rem;
}

/* Full-viewport touch scroll driver; segment UI is on ListStoryStageOverlay. */
.jgis-story-mobile-list-scroll {
  position: fixed;
  inset: 0;
  z-index: 6;
  top: var(--jgis-story-title-bar-height);
  width: 100%;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior: contain;
  touch-action: pan-y;
  background: transparent;
}

/* Mobile list only (scroll driver mounted); desktop list keeps 25% map cards. */
.jgis-mainview-stage:has(.jgis-story-mobile-list-scroll)
  .jgis-story-map-scroll-pane {
  padding-left: 1rem;
}

.jgis-mainview-stage:has(.jgis-story-mobile-list-scroll)
  .jgis-story-map-overlay-content {
  width: fit-content;
  background-color: color-mix(
    in srgb,
    var(--jgis-specta-bg-color, var(--jp-layout-color0))
      calc(var(--jgis-story-panel-opacity, 1) * 90%),
    transparent
  );
}

.jgis-mainview-stage:has(.jgis-story-mobile-list-scroll)
  .jgis-story-viewer-image-section {
  opacity: 0.9;
}

/* Hierarchy: .form-group > .jp-FormGroup-content > .jp-objectFieldWrapper > #jgis-source-properties-field */
.form-group:has(
  .jp-FormGroup-content .jp-objectFieldWrapper #jgis-source-properties-field
) {
  padding: 0;
}

/* #jgis-source-properties-field and .jGIS-property-panel are siblings; remove padding on the panel's outer wrapper */
.form-group:has(
    .jp-FormGroup-content .jp-objectFieldWrapper #jgis-source-properties-field
  ):has(.jGIS-property-panel)
  .jGIS-property-panel
  .jGIS-property-outer {
  padding: 0;
}

.jp-arrayFieldWrapper legend {
  border-bottom: none;
}

.jgis-symbology-override-collapsible-trigger {
  display: flex;
  gap: 1rem;
  align-items: center;
  cursor: pointer;
  padding: 0.5rem 0.25rem;
  background-color: var(--jp-layout-color0);
  border-radius: var(--jp-border-radius);
}

.jgis-symbology-override-collapsible-trigger[data-state='open'] {
  background-color: var(--jp-layout-color3);
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
}

.jgis-symbology-override-collapsible-trigger span {
  font-weight: bold;
}
`,""]),e.d(r,{},{A:n})},8179(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,"@import url(https://fonts.googleapis.com/css2?family=Source+Serif+4:ital,opsz,wght@0,8..60,200..900;1,8..60,200..900&display=swap);"]),n.push([o.id,"@import url(https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,100..900;1,100..900&display=swap);"]),n.push([o.id,"@import url(https://fonts.googleapis.com/css2?family=Source+Code+Pro:ital,wght@0,200..900;1,200..900&family=Work+Sans:ital,wght@0,100..900;1,100..900&display=swap);"]),n.push([o.id,`/* Specta article typography for story rendermime markdown.
 * Port of specta/style/article.css with .jgis-story-rendered-markdown scoping
 * and a 1rem body baseline (no 20px media overrides). */

.jgis-story-rendered-markdown .specta-article-host-widget {
  --jp-content-font-family: 'Source Serif 4', Georgia, serif;
  --jp-code-font-family:
    'Source Code Pro', Menlo, Monaco, 'Courier New', Courier, monospace;
  --jp-code-font-size: 0.875rem;
  /* So .jp-RenderedHTMLCommon { color: var(--jp-content-font-color1) } uses specta text. */
  --jp-content-font-color1: var(
    --jgis-specta-text-color,
    var(--jp-content-font-color1)
  );
  font-family: var(--jp-content-font-family);
  font-size: 1rem;
  line-height: 1.6;
  max-width: 100ch;
  margin: 0 auto;
  padding-bottom: 2rem;
}

#jgis-story-segment-content
  .jgis-story-rendered-markdown
  .specta-article-host-widget.specta-cell-content {
  margin: 0;
  padding-bottom: 0;
}

.jgis-story-rendered-markdown .specta-article-host-widget .jp-Collapser-child,
.jgis-story-rendered-markdown
  .specta-article-host-widget
  .jp-collapseHeadingButton,
.jgis-story-rendered-markdown .specta-article-host-widget .jp-InputPrompt,
.jgis-story-rendered-markdown .specta-article-host-widget .jp-InputCollapser,
.jgis-story-rendered-markdown
  .specta-article-host-widget
  .jp-InternalAnchorLink {
  display: none;
}

.jgis-story-rendered-markdown
  .specta-article-host-widget
  .specta-article-outputs-panel {
  font-size: 1rem;
  line-height: 1.6;
  width: 100%;
}

.jgis-story-rendered-markdown .specta-article-host-widget .specta-cell-output {
  max-width: 680px;
  margin: auto;
}

.jgis-story-rendered-markdown
  .specta-article-host-widget
  .specta-article-outputs-panel
  .jp-MarkdownOutput {
  padding-left: 0 !important;
  padding-right: 0 !important;
}

.jgis-story-rendered-markdown
  .specta-article-host-widget
  .specta-article-outputs-panel
  .specta-item-widget {
  padding: 0 !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget h1 {
  font-family: 'Work Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
  letter-spacing: -0.014em;
  line-height: 1.2;
  margin-bottom: 1.5rem;
  margin-top: 1.5em !important;
  font-size: 2rem;
  font-weight: 700;
  font-style: normal;
}

.jgis-story-rendered-markdown .specta-article-host-widget h2 {
  font-family: 'Work Sans', 'Helvetica Neue', Helvetica, Arial, sans-serif;
  margin-top: 1em !important;
  font-size: 1.6em;
}

.jgis-story-rendered-markdown .specta-article-host-widget h3 {
  margin-top: 1em !important;
  font-size: 1.3em;
}

.jgis-story-rendered-markdown .specta-article-host-widget h4 {
  margin-top: 1em;
  font-size: 1.2em;
}

.jgis-story-rendered-markdown .specta-article-host-widget h5 {
  margin-top: 1em;
  font-size: 1.1em;
}

.jgis-story-rendered-markdown .specta-article-host-widget h6 {
  margin-top: 1em;
  font-size: 1em;
}

.jgis-story-rendered-markdown .specta-article-host-widget p {
  font-size: 1rem;
  line-height: 1.6;
  margin-bottom: 1.2em;
}

.jgis-story-rendered-markdown .specta-article-host-widget a {
  text-decoration: none;
}

.jgis-story-rendered-markdown .specta-article-host-widget a:hover {
  text-decoration: underline;
}

.jgis-story-rendered-markdown .specta-article-host-widget pre {
  background-color: var(--jp-cell-editor-background) !important;
  padding: 2rem !important;
  border-radius: 4px !important;
  border: 1px solid var(--jp-cell-editor-border-color) !important;
  overflow-x: auto;
  margin: 0 !important;
  margin-top: 3.5rem !important;
  font-size: 0.85em !important;
  line-height: 1.4 !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget pre code {
  background-color: transparent !important;
  padding: 0;
  font-size: 0.875rem !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget code {
  padding: 0.2em 0.4em;
  border-radius: 4px;
  font-size: 0.875rem !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget p code {
  font-size: 75% !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget img {
  max-width: 100%;
  height: auto;
  display: block;
  margin: 1.5em auto;
  border-radius: 4px;
}

.jgis-story-rendered-markdown .specta-article-host-widget blockquote {
  border-left: 3px solid;
  padding-left: 1rem;
  margin: 1.2em 0;
  font-style: italic;
  color: var(--jp-ui-font-color2);
  font-size: 1em;
}

.jgis-story-rendered-markdown .specta-article-host-widget blockquote p {
  margin-bottom: 0.4em;
}

.jgis-story-rendered-markdown .specta-article-host-widget ul,
.jgis-story-rendered-markdown .specta-article-host-widget ol {
  margin-bottom: 1.2em;
  padding-left: 1.5em;
  font-size: 1rem;
  line-height: 1.6;
}

.jgis-story-rendered-markdown .specta-article-host-widget li {
  margin-bottom: 0.4em;
}

.jgis-story-rendered-markdown .specta-article-host-widget hr {
  border: 0;
  height: 1px;
  margin: 2em 0;
}

.jgis-story-rendered-markdown .specta-article-host-widget table {
  width: 100%;
  border-collapse: collapse;
  margin: 1.2em 0;
  font-size: 0.9em;
}

.jgis-story-rendered-markdown .specta-article-host-widget th,
.jgis-story-rendered-markdown .specta-article-host-widget td {
  border: 1px solid;
  padding: 0.375rem 0.625rem;
  text-align: left;
}

.jgis-story-rendered-markdown .specta-article-host-widget th {
  font-weight: bold;
}

.jgis-story-rendered-markdown .specta-article-host-widget h1 + p,
.jgis-story-rendered-markdown .specta-article-host-widget h2 + p,
.jgis-story-rendered-markdown .specta-article-host-widget h3 + p,
.jgis-story-rendered-markdown .specta-article-host-widget h4 + p,
.jgis-story-rendered-markdown .specta-article-host-widget h5 + p {
  margin-top: 0.66em !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget .jp-CodeCell {
  padding: 0 !important;
  margin-top: 2.5rem !important;
}

.jgis-story-rendered-markdown
  .specta-article-host-widget
  .jp-OutputArea
  > .jp-OutputArea-child:first-child {
  margin-top: 2.5rem !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget .jp-InputArea-editor {
  padding: 2rem !important;
  border-radius: 4px !important;
  background-color: var(--jp-cell-editor-background) !important;
}

.jgis-story-rendered-markdown
  .specta-article-host-widget
  .jp-InputArea-editor
  > div.cm-editor {
  background: transparent !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget .cm-content {
  padding: 0 !important;
}

.jgis-story-rendered-markdown .specta-article-host-widget .jp-MarkdownOutput {
  padding-left: 0 !important;
  padding-right: 0 !important;
}

/* Bigger screen */
@media screen and (min-width: 728px) {
  .jgis-story-rendered-markdown
    .specta-article-host-widget
    .specta-article-outputs-panel {
    font-size: 1rem;
    line-height: 1.7;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget h1 {
    font-size: 2.625rem;
    font-style: normal;
    font-weight: 700;
    margin-top: 1.8em !important;
    margin-bottom: 2rem;
    line-height: 1.25;
    letter-spacing: -0.011em;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget h2 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-top: 1.25em !important;
    line-height: 1.25;
    margin-bottom: 0 !important;
    letter-spacing: -0.016em;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget h3 {
    letter-spacing: 0;
    line-height: 1.2;
    font-size: 1.3em;
    margin-top: 1.72em !important;
    font-weight: 700;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget h4 {
    font-size: 1.3em;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget h5 {
    font-size: 1.2em;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget h6 {
    font-size: 1.1em;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget p,
  .jgis-story-rendered-markdown .specta-article-host-widget ul,
  .jgis-story-rendered-markdown .specta-article-host-widget ol {
    letter-spacing: -0.003em;
    line-height: 1.7;
    font-size: 1rem;
    margin-top: 2.1em;
    margin-bottom: 0 !important;
    font-style: normal;
    word-break: break-word;
    font-weight: 400;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget li {
    margin-bottom: 0.5em;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget pre {
    font-size: 0.9em;
    padding: 0.9375rem;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget pre code,
  .jgis-story-rendered-markdown .specta-article-host-widget code {
    font-size: 0.9em;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget blockquote {
    font-size: 1.1em;
    margin: 1.5em 0;
    padding-left: 1.25rem;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget table {
    font-size: 0.95em;
    margin: 1.5em 0;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget th,
  .jgis-story-rendered-markdown .specta-article-host-widget td {
    padding: 0.5rem 0.75rem;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget img {
    margin: 2em auto;
  }

  .jgis-story-rendered-markdown .specta-article-host-widget .jp-CodeCell {
    margin-top: 3.5rem !important;
  }

  .jgis-story-rendered-markdown
    .specta-article-host-widget
    .jp-OutputArea
    > .jp-OutputArea-child:first-child {
    margin-top: 3.5rem !important;
  }

  .jgis-story-rendered-markdown
    .specta-article-host-widget
    .specta-cell-output-big {
    max-width: 1192px;
  }

  .jgis-story-rendered-markdown
    .specta-article-host-widget
    .specta-cell-output-big
    .jp-Cell {
    max-width: 680px;
    margin: auto;
  }

  .jgis-story-rendered-markdown
    .specta-article-host-widget
    .specta-cell-output-big
    .jp-Cell.jp-MarkdownCell {
    max-width: 1192px;
    margin: auto;
  }

  .jgis-story-rendered-markdown
    .specta-article-host-widget
    .specta-cell-output-full {
    max-width: 100%;
  }

  .jgis-story-rendered-markdown
    .specta-article-host-widget
    .specta-cell-output-full
    .jp-Cell {
    max-width: 680px;
    margin: auto;
  }

  .jgis-story-rendered-markdown
    .specta-article-host-widget
    .specta-cell-output-full
    .jp-Cell.jp-MarkdownCell {
    max-width: 100%;
    margin: auto;
  }
}
`,""]),e.d(r,{},{A:n})},8781(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`select,
select option {
  text-transform: capitalize;
}

.jp-gis-symbology-dialog .jp-Dialog-header {
  font-weight: bold;
}

.jp-gis-symbology-dialog .jp-Dialog-content {
  width: calc(80% - 4rem);
  max-width: 80%;
  height: fit-content;
  max-height: 80%;
}

@media (max-width: 960px) {
  .jp-gis-symbology-dialog .jp-Dialog-content {
    width: 100%;
    max-width: 100%;
    max-height: 90%;
    margin: 0;
    border-radius: 0;
    padding-left: 8px;
    padding-right: 8px;
  }
}

.jp-gis-symbology-row {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  gap: 2rem;
}

.jp-gis-symbology-row label {
  font-size: var(--jp-ui-font-size2);
  flex: 0 1 auto;
}

.jp-gis-symbology-row > .jp-select-wrapper,
.jp-gis-symbology-row > .jp-mod-styled,
.jp-gis-symbology-row > .jp-gis-rgba-picker {
  flex: 1 0 50%;
  max-width: 50%;
}

.jp-gis-color-ramp-div {
  display: flex;
  flex: 1 1 50%;
  max-width: 50%;
  justify-content: space-between;
  align-items: baseline;
}

.jp-gis-color-ramp-div > .jp-select-wrapper {
  flex: 1 0 40%;
}

.jp-gis-color-ramp-div:last-child {
  flex-shrink: 0;
}

.jp-gis-color-ramp-div > input {
  max-width: 25%;
}

.jp-gis-layer-symbology-container {
  display: flex;
  flex-direction: column;
  gap: 13px;
  border-top: 1px solid var(--jp-border-color2);
  padding-top: 8px;
}

.jp-gis-layer-symbology-container .jp-select-wrapper {
  margin-bottom: unset;
}

.jp-gis-color-ramp-container {
  display: flex;
  flex-direction: column;
  gap: 13px;
}

.jp-gis-stop-container {
  display: flex;
  flex-direction: column;
  gap: 0.1rem;
}

.jp-gis-stop-labels {
  display: flex;
  font-weight: bold;
  font-size: var(--jp-ui-font-size1);
  gap: 0.25rem;
  padding-bottom: 0.25rem;
}

.jp-gis-stop-labels > span {
  flex: 0 0 18%;
}

.jp-gis-color-row {
  display: flex;
  width: 100%;
  gap: 0.25rem;
  height: 32px;
}

.jp-gis-color-row-value-input {
  flex: 0 1 18%;
  min-width: 0px;
}

.jp-gis-color-row-output-input {
  flex-grow: 1;
}

.jp-gis-color-row > button {
  color: var(--jp-ui-font-color0);
  background: none;
  padding-right: 0px;
}

.jp-gis-symbology-button-container {
  padding-top: 0.5rem;
}

.jp-gis-color-ramp-dropdown {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  position: absolute;
  overflow-x: hidden;
  overflow-y: auto;
  visibility: hidden;
  z-index: 40;
  flex: 1 1 auto;
  width: 97%;
  max-height: 20rem;
  background: var(--jp-input-background);
  padding-left: 8px;
  border: var(--jp-border-width) solid var(--jp-input-border-color);
  border-radius: 0;
  outline: none;
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
}

.jp-gis-open {
  visibility: visible;
}

.jp-gis-color-ramp-entry {
  display: flex;
  align-items: center;
  font-size: var(--jp-ui-font-size2);
  color: var(--jp-ui-font-color0);
  text-transform: capitalize;
  cursor: pointer;
  position: relative;
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
}

.jp-gis-color-label {
  color: white;
  padding-left: 10px;
  position: absolute;
  text-shadow: 0px 0px 4px black;

  transition: transform 0.3s ease;
  transform-origin: left bottom;
}

.jp-gis-color-ramp-entry:not(.jp-gis-selected-entry):hover .jp-gis-color-label {
  transform: translateX(6px);
}

.jp-gis-color-ramp-warning {
  position: absolute;
  right: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.jp-gis-color-ramp-warning .jgis-hover-card-trigger {
  color: white !important;
  filter: drop-shadow(0 0 2px black);
}

.jp-gis-color-canvas {
  margin: 0 -7px;
  border-radius: 4px;
  width: 100%;
  max-height: 38px;
}

.jp-gis-color-canvas-display {
  width: 100%;
  height: 30px;
  visibility: initial;
  border-radius: var(--jp-border-radius);
}

.jp-Dialog-content:has(.jp-gis-heatmap),
.jp-Dialog-body:has(.jp-gis-heatmap) {
  overflow: visible;
}

.jp-gis-canvas-button-wrapper {
  flex: 1 0 50%;
  max-width: 50%;
  position: relative;
}

#jp-gis-canvas-button.jp-gis-canvas-button {
  margin: 0;
  padding: 0 1px 0 0;
  width: 100%;
}

.jp-gis-selected-entry {
  width: 100%;
}

.jp-gis-rgba-inputs {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 6px;
}

.jp-gis-rgba-field {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 0 0 auto;
  gap: 2px;
}

.jp-gis-rgba-field label {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  line-height: 1;
}

.jp-gis-rgba-field input {
  width: 4ch;
  text-align: center;
  padding: 1px 2px;
  -moz-appearance: textfield;
}

.jp-gis-rgba-field input::-webkit-outer-spin-button,
.jp-gis-rgba-field input::-webkit-inner-spin-button {
  -webkit-appearance: none;
}

/* ---------------------------------------------------------------------------
 * Grammar layer sections
 * --------------------------------------------------------------------------*/

.jp-gis-grammar-layer-section {
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  margin-bottom: 8px;
  overflow: hidden;
  background: color-mix(in srgb, var(--jp-layout-color2) 50%, transparent);
}

.jp-gis-grammar-layer-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 6px;
  background: color-mix(in srgb, var(--jp-layout-color2) 50%, transparent);
}

.jp-gis-grammar-layer-label {
  font-size: var(--jp-ui-font-size1);
  font-weight: 600;
  color: var(--jp-ui-font-color1);
  flex: 1 0 auto;
}

.jp-gis-grammar-transform-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 6px;
  background: color-mix(in srgb, var(--jp-layout-color2) 50%, transparent);
  border-bottom: 1px solid var(--jp-border-color2);
  font-size: var(--jp-ui-font-size1);
}

.jp-gis-grammar-transform-row label {
  color: var(--jp-ui-font-color2);
  white-space: nowrap;
}

.jp-gis-grammar-transform-row input,
.jp-gis-grammar-transform-row [data-slot='native-select'],
.jp-gis-grammar-transform-row select,
.jp-gis-grammar-transform-row .jgis-native-select {
  background: transparent;
  background-color: transparent;
  border-color: transparent;
}

.jp-gis-grammar-transform-row .jgis-button,
.jp-gis-grammar-layer-header .jgis-button,
.jp-gis-grammar-layer-section > .jp-gis-grammar-when-row .jgis-button {
  background: transparent;
  background-color: transparent;
  border-color: transparent;
}

/* ---------------------------------------------------------------------------
 * Grammar reorder pill (drag handle + arrows above each rule)
 * --------------------------------------------------------------------------*/

/* Desktop: horizontal row with sidebar left of rule */
.jp-gis-grammar-drag-wrapper {
  display: flex;
  flex-direction: row;
  align-items: stretch;
  padding-left: 5px;
  padding-right: 8px; /* A little more on the right because of the scroll bar */
}

.jp-gis-grammar-drag-wrapper > .jp-gis-grammar-rule {
  flex: 1;
  min-width: 0;
}

/* Vertical sidebar: ↑ ⠿ ↓ stacked */
.jp-gis-grammar-reorder-bar {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0;
  padding: 2px 0;
  color: var(--jp-ui-font-color3);
  background: color-mix(in srgb, var(--jp-layout-color2) 50%, transparent);
  border: 1px solid var(--jp-border-color2);
  border-right: none;
  border-radius: 4px 0 0 4px;
}

.jp-gis-grammar-reorder-bar + .jp-gis-grammar-rule {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.jp-gis-grammar-reorder-bar .jgis-button {
  height: 20px;
  width: 22px;
  padding: 0;
  border: none;
  border-radius: 0;
  color: var(--jp-ui-font-color3);
  background: none;
}

.jp-gis-grammar-reorder-bar .jgis-button:hover:not(:disabled) {
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color3);
}

.jp-gis-grammar-reorder-bar .jgis-button:disabled {
  opacity: 0.3;
}

.jp-gis-grammar-drag-handle {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 20px;
  flex-shrink: 0;
  cursor: grab;
  color: var(--jp-ui-font-color3);
}

.jp-gis-grammar-drag-handle:hover {
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color3);
}

.jp-gis-grammar-drag-handle:active {
  cursor: grabbing;
}

/* Mobile: horizontal bar on top */
@media (max-width: 960px) {
  .jp-gis-grammar-drag-wrapper {
    flex-direction: column;
  }

  .jp-gis-grammar-reorder-bar {
    flex-direction: row;
    justify-content: flex-start;
    padding: 0 2px;
    border-right: 1px solid var(--jp-border-color2);
    border-bottom: none;
    border-radius: 4px 4px 0 0;
  }

  .jp-gis-grammar-reorder-bar + .jp-gis-grammar-rule {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    border-bottom-left-radius: 4px;
  }
}

/* ---------------------------------------------------------------------------
 * Grammar rule rows
 * --------------------------------------------------------------------------*/

.jp-gis-grammar-rule {
  border: 1px solid var(--jp-border-color2);
  border-radius: 4px;
  overflow: hidden;
  background: var(--jp-layout-color0);
}

/* Desktop: horizontal flow — input → scale+preview → output */
.jp-gis-grammar-rule-grid {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 6px;
}

.jp-gis-grammar-section {
  display: contents;
}

.jp-gis-grammar-scale-section {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: 1;
  min-width: 0;
}

.jp-gis-grammar-scale-section .jp-gis-grammar-preview-btn {
  min-width: 0;
}

.jp-gis-grammar-output-section {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.jp-gis-grammar-encoding-row {
  display: flex;
  align-items: center;
  gap: 4px;
}

.jp-gis-grammar-encoding-select {
  min-width: 0;
}

.jp-gis-grammar-encoding-select .jgis-combobox-button,
.jp-gis-grammar-encoding-select .jgis-native-select {
  width: 100%;
  box-sizing: border-box;
}

.jp-gis-grammar-rule-grid [data-slot='native-select'],
.jp-gis-grammar-transform-row [data-slot='native-select'] {
  border-color: transparent;
}

.jp-gis-grammar-rule-grid [data-slot='native-select']:hover,
.jp-gis-grammar-transform-row [data-slot='native-select']:hover {
  border-color: var(--jp-border-color1);
}

/* Mobile: stacked top-to-bottom */
@media (max-width: 960px) {
  .jp-gis-grammar-rule-grid {
    flex-direction: column;
    align-items: stretch;
  }

  .jp-gis-grammar-section {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .jp-gis-grammar-input-section {
    display: contents;
  }

  .jp-gis-grammar-scale-section {
    flex-direction: column;
    align-items: flex-start;
  }

  .jp-gis-grammar-rule-grid > .jp-gis-grammar-arrow {
    align-self: flex-start;
    text-align: left;
    transform: rotate(90deg);
  }

  .jp-gis-grammar-scale-section .jgis-native-select {
    align-self: flex-start;
  }
}

.jp-gis-grammar-rule-editor {
  border-top: 1px solid var(--jp-border-color2);
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  background: var(--jp-layout-color0);
}

.jp-gis-grammar-action-btn {
  background: transparent;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius, 0.375rem);
  color: var(--jp-ui-font-color1);
  font-size: var(--jp-ui-font-size1);
  padding: 4px 12px;
  cursor: pointer;
  width: fit-content;
}

.jp-gis-grammar-action-btn:hover {
  background: var(--jp-layout-color2);
}

.jp-gis-grammar-action-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Preview button spans all encoding rows — stretches vertically */
.jp-gis-grammar-preview-btn {
  background: none;
  border: 1px solid transparent;
  border-radius: 4px;
  padding: 4px 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  align-self: stretch;
  justify-content: flex-start;
  gap: 6px;
  min-width: 0;
  min-height: 36px;
  overflow: hidden;
}

.jp-gis-grammar-preview-btn:hover {
  border-color: var(--jp-border-color2);
}

.jp-gis-grammar-preview-chevron {
  flex-shrink: 0;
  color: var(--jp-ui-font-color3);
  font-size: 12px;
  line-height: 1;
}

.jp-gis-grammar-preview-btn:hover {
  background: color-mix(in srgb, var(--jp-layout-color2) 40%, transparent);
}

.jp-gis-grammar-preview-btn:hover .jp-gis-grammar-preview-chevron {
  color: var(--jp-ui-font-color1);
}

.jp-gis-scale-preview {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: var(--jp-ui-font-size1);
  min-height: 16px;
  overflow: hidden;
  width: 100%;
}

.jp-gis-scale-meta {
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-ui-font-color2);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.jp-gis-scale-swatch {
  flex-shrink: 0;
  width: 18px;
  height: 18px;
  border-radius: 3px;
  border: 1px solid var(--jp-border-color1);
  display: inline-block;
}

.jp-gis-scale-dot {
  flex-shrink: 0;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  display: inline-block;
}

.jp-gis-grammar-arrow {
  color: var(--jp-ui-font-color2);
  text-align: center;
  padding: 0 2px;
}

.jp-gis-grammar-delete-btn {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--jp-ui-font-color2);
  padding: 0 4px;
  font-size: 16px;
  line-height: 1;
}

/* When clause */

.jp-gis-grammar-layer-section > .jp-gis-grammar-when-row {
  background: color-mix(in srgb, var(--jp-layout-color2) 50%, transparent);
}

.jp-gis-grammar-when-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 4px;
  padding: 3px 6px 4px;
  border-top: 1px solid var(--jp-border-color3);
  background: var(--jp-layout-color1);
}

.jp-gis-grammar-when-label {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
  font-style: italic;
  flex-shrink: 0;
}

.jp-gis-grammar-when-op {
  height: 20px;
  padding: 0 4px;
  font-size: var(--jp-ui-font-size0);
  border-radius: 10px;
  border: 1px solid transparent;
  background: var(--jp-layout-color0);
  color: var(--jp-ui-font-color1);
  cursor: pointer;
}

.jp-gis-grammar-when-chip {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  padding: 1px 6px;
  background: var(--jp-layout-color0);
  border: 1px solid transparent;
  border-radius: 10px;
  font-size: var(--jp-ui-font-size0);
  white-space: nowrap;
}

.jp-gis-grammar-when-chip button {
  background: none;
  border: none;
  padding: 0 0 0 2px;
  cursor: pointer;
  line-height: 1;
  color: var(--jp-ui-font-color2);
  font-size: 11px;
}

.jgis-button.jp-gis-grammar-when-add-btn {
  background: transparent;
  background-color: transparent;
  border: 1px dashed var(--jp-border-color2);
  border-radius: 10px;
  padding: 1px 8px;
  cursor: pointer;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color2);
}

.jp-gis-grammar-when-add-btn:hover {
  border-color: var(--jp-brand-color1);
  color: var(--jp-brand-color1);
}

.jp-gis-grammar-when-form {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  flex-wrap: nowrap;
}

.jp-gis-grammar-when-form .jgis-native-select {
  flex: 0 0 auto;
}

/* Make when-form selects compact to match the when-row height */
.jp-gis-grammar-when-form [data-slot='native-select'] {
  height: 24px;
  font-size: var(--jp-ui-font-size0);
  padding-top: 0;
  padding-bottom: 0;
  border-color: transparent;
}

/* Make when-form inputs compact too */
.jp-gis-grammar-when-form [data-slot='input'],
.jp-gis-grammar-when-form input {
  height: 24px;
  font-size: var(--jp-ui-font-size0);
  border-color: var(--jp-border-color2);
  box-shadow: none;
}

/* Icon buttons in the when-form should be transparent, not white */
.jp-gis-grammar-when-form .jgis-button {
  background: transparent;
  background-color: transparent;
  border-color: transparent;
}

.jgis-button.jp-gis-grammar-when-form-cancel {
  color: var(--jp-error-color0);
}

/* Domain min/max pair inside a symbology row */
.jp-gis-domain-inputs {
  display: flex;
  gap: 4px;
  flex: 1 0 50%;
  max-width: 50%;
}

@media (max-width: 960px) {
  .jp-gis-symbology-row {
    flex-wrap: wrap;
    gap: 0.5rem;
  }

  .jp-gis-symbology-row > .jp-select-wrapper,
  .jp-gis-symbology-row > .jp-mod-styled,
  .jp-gis-symbology-row > .jp-gis-rgba-picker,
  .jp-gis-canvas-button-wrapper,
  .jp-gis-domain-inputs {
    flex: 1 0 100%;
    max-width: 100%;
  }
}

.jp-gis-transparent-label {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-top: 6px;
  font-size: var(--jp-ui-font-size1);
  cursor: pointer;
  user-select: none;
}
`,""]),e.d(r,{},{A:n})},1885(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jgis-panel-tab-content {
  font-size: var(--jp-ui-font-size0);
  padding-bottom: 50px;
}
`,""]),e.d(r,{},{A:n})},8448(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`/*! tailwindcss v4.3.3 | MIT License | https://tailwindcss.com */
@layer properties;
@layer theme, base, components, utilities;
@layer theme {
  :root, :host {
    --spacing: 0.25rem;
    --text-xs: 0.75rem;
    --text-xs--line-height: calc(1 / 0.75);
    --text-sm: 0.875rem;
    --text-sm--line-height: calc(1.25 / 0.875);
    --text-base: var(--jp-ui-font-size1);
    --text-base--line-height: calc(1.5 / 1);
    --font-weight-normal: 400;
    --font-weight-medium: 500;
    --radius-md: calc(var(--radius) * 0.8);
    --default-transition-duration: 150ms;
    --default-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    --radius: var(--jp-border-radius, 0.625rem);
    --color-background: var(--jp-layout-color0);
    --color-foreground: var(--jp-ui-font-color0);
    --color-popover: var(--jp-layout-color0);
    --color-popover-foreground: var(--jp-ui-font-color0);
    --color-primary: var(--jp-brand-color1);
    --color-primary-foreground: var(--jp-ui-inverse-font-color1);
    --color-secondary: var(--jp-layout-color2);
    --color-secondary-foreground: var(--jp-ui-font-color0);
    --color-muted: var(--jp-layout-color2);
    --color-muted-foreground: var(--jp-ui-font-color2);
    --color-accent: var(--jp-layout-color2);
    --color-accent-foreground: var(--jp-ui-font-color0);
    --color-destructive: var(--jp-error-color0);
    --color-border: var(--jp-border-color1);
    --color-input: var(--jp-input-border-color, var(--jp-border-color1));
    --color-ring: var(--jp-brand-color2);
  }
}
@layer utilities {
  .pointer-events-auto {
    pointer-events: auto;
  }
  .pointer-events-none {
    pointer-events: none;
  }
  .invisible {
    visibility: hidden;
  }
  .visible {
    visibility: visible;
  }
  .sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
    border-width: 0;
  }
  .absolute {
    position: absolute;
  }
  .fixed {
    position: fixed;
  }
  .relative {
    position: relative;
  }
  .static {
    position: static;
  }
  .right-2 {
    right: calc(var(--spacing) * 2);
  }
  .isolate {
    isolation: isolate;
  }
  .z-50 {
    z-index: 50;
  }
  .order-first {
    order: -9999;
  }
  .order-last {
    order: 9999;
  }
  .container {
    width: 100%;
    @media (width >= 40rem) {
      max-width: 40rem;
    }
    @media (width >= 48rem) {
      max-width: 48rem;
    }
    @media (width >= 64rem) {
      max-width: 64rem;
    }
    @media (width >= 80rem) {
      max-width: 80rem;
    }
    @media (width >= 96rem) {
      max-width: 96rem;
    }
  }
  .-mx-1 {
    margin-inline: calc(var(--spacing) * -1);
  }
  .my-1 {
    margin-block: var(--spacing);
  }
  .-ml-1 {
    margin-left: calc(var(--spacing) * -1);
  }
  .block {
    display: block;
  }
  .contents {
    display: contents;
  }
  .flex {
    display: flex;
  }
  .grid {
    display: grid;
  }
  .hidden {
    display: none;
  }
  .inline {
    display: inline;
  }
  .inline-block {
    display: inline-block;
  }
  .inline-flex {
    display: inline-flex;
  }
  .table {
    display: table;
  }
  .field-sizing-content {
    field-sizing: content;
  }
  .size-4 {
    width: calc(var(--spacing) * 4);
    height: calc(var(--spacing) * 4);
  }
  .size-6 {
    width: calc(var(--spacing) * 6);
    height: calc(var(--spacing) * 6);
  }
  .size-7 {
    width: calc(var(--spacing) * 7);
    height: calc(var(--spacing) * 7);
  }
  .size-8 {
    width: calc(var(--spacing) * 8);
    height: calc(var(--spacing) * 8);
  }
  .size-9 {
    width: calc(var(--spacing) * 9);
    height: calc(var(--spacing) * 9);
  }
  .h-4 {
    height: calc(var(--spacing) * 4);
  }
  .h-6 {
    height: calc(var(--spacing) * 6);
  }
  .h-7 {
    height: calc(var(--spacing) * 7);
  }
  .h-8 {
    height: calc(var(--spacing) * 8);
  }
  .h-9 {
    height: calc(var(--spacing) * 9);
  }
  .h-\\[calc\\(--spacing\\(5\\.25\\)\\)\\] {
    height: calc(calc(var(--spacing) * 5.25));
  }
  .h-auto {
    height: auto;
  }
  .h-px {
    height: 1px;
  }
  .max-h-\\(--available-height\\) {
    max-height: var(--available-height);
  }
  .max-h-\\[min\\(calc\\(--spacing\\(72\\)---spacing\\(9\\)\\)\\,calc\\(var\\(--available-height\\)---spacing\\(9\\)\\)\\)\\] {
    max-height: min(calc(calc(var(--spacing) * 72) - calc(var(--spacing) * 9)), calc(var(--available-height) - calc(var(--spacing) * 9)));
  }
  .min-h-8 {
    min-height: calc(var(--spacing) * 8);
  }
  .min-h-16 {
    min-height: calc(var(--spacing) * 16);
  }
  .w-\\(--anchor-width\\) {
    width: var(--anchor-width);
  }
  .w-4 {
    width: calc(var(--spacing) * 4);
  }
  .w-auto {
    width: auto;
  }
  .w-fit {
    width: fit-content;
  }
  .w-full {
    width: 100%;
  }
  .max-w-\\(--available-width\\) {
    max-width: var(--available-width);
  }
  .min-w-\\(--anchor-width\\)\\! {
    min-width: var(--anchor-width) !important;
  }
  .min-w-0 {
    min-width: 0px;
  }
  .min-w-16 {
    min-width: calc(var(--spacing) * 16);
  }
  .min-w-\\[calc\\(var\\(--anchor-width\\)\\+--spacing\\(7\\)\\)\\] {
    min-width: calc(var(--anchor-width) + calc(var(--spacing) * 7));
  }
  .flex-1 {
    flex: 1;
  }
  .shrink {
    flex-shrink: 1;
  }
  .shrink-0 {
    flex-shrink: 0;
  }
  .grow {
    flex-grow: 1;
  }
  .origin-\\(--transform-origin\\) {
    transform-origin: var(--transform-origin);
  }
  .transform {
    transform: var(--tw-rotate-x,) var(--tw-rotate-y,) var(--tw-rotate-z,) var(--tw-skew-x,) var(--tw-skew-y,);
  }
  .cursor-pointer {
    cursor: pointer;
  }
  .cursor-text {
    cursor: text;
  }
  .resize {
    resize: both;
  }
  .resize-none {
    resize: none;
  }
  .scroll-py-1 {
    scroll-padding-block: var(--spacing);
  }
  .flex-wrap {
    flex-wrap: wrap;
  }
  .items-center {
    align-items: center;
  }
  .justify-between {
    justify-content: space-between;
  }
  .justify-center {
    justify-content: center;
  }
  .justify-start {
    justify-content: flex-start;
  }
  .gap-1 {
    gap: var(--spacing);
  }
  .gap-1\\.5 {
    gap: calc(var(--spacing) * 1.5);
  }
  .gap-2 {
    gap: calc(var(--spacing) * 2);
  }
  .truncate {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .overflow-hidden {
    overflow: hidden;
  }
  .overflow-y-auto {
    overflow-y: auto;
  }
  .overscroll-contain {
    overscroll-behavior: contain;
  }
  .rounded-\\[calc\\(var\\(--radius\\)-3px\\)\\] {
    border-radius: calc(var(--radius) - 3px);
  }
  .rounded-\\[min\\(var\\(--radius-md\\)\\,10px\\)\\] {
    border-radius: min(var(--radius-md), 10px);
  }
  .rounded-\\[min\\(var\\(--radius-md\\)\\,12px\\)\\] {
    border-radius: min(var(--radius-md), 12px);
  }
  .rounded-lg {
    border-radius: var(--radius);
  }
  .rounded-md {
    border-radius: calc(var(--radius) * 0.8);
  }
  .rounded-none {
    border-radius: 0;
  }
  .rounded-sm {
    border-radius: calc(var(--radius) * 0.6);
  }
  .border {
    border-style: var(--tw-border-style);
    border-width: 1px;
  }
  .border-0 {
    border-style: var(--tw-border-style);
    border-width: 0px;
  }
  .border-border {
    border-color: var(--color-border);
  }
  .border-input {
    border-color: var(--color-input);
  }
  .border-transparent {
    border-color: transparent;
  }
  .bg-background {
    background-color: var(--color-background);
  }
  .bg-border {
    background-color: var(--color-border);
  }
  .bg-destructive\\/10 {
    background-color: var(--color-destructive);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-destructive) 10%, transparent);
    }
  }
  .bg-muted {
    background-color: var(--color-muted);
  }
  .bg-popover {
    background-color: var(--color-popover);
  }
  .bg-primary {
    background-color: var(--color-primary);
  }
  .bg-secondary {
    background-color: var(--color-secondary);
  }
  .bg-transparent {
    background-color: transparent;
  }
  .bg-clip-padding {
    background-clip: padding-box;
  }
  .p-0 {
    padding: 0px;
  }
  .p-1 {
    padding: var(--spacing);
  }
  .px-1\\.5 {
    padding-inline: calc(var(--spacing) * 1.5);
  }
  .px-2 {
    padding-inline: calc(var(--spacing) * 2);
  }
  .px-2\\.5 {
    padding-inline: calc(var(--spacing) * 2.5);
  }
  .py-1 {
    padding-block: var(--spacing);
  }
  .py-1\\.5 {
    padding-block: calc(var(--spacing) * 1.5);
  }
  .py-2 {
    padding-block: calc(var(--spacing) * 2);
  }
  .py-6 {
    padding-block: calc(var(--spacing) * 6);
  }
  .pt-2 {
    padding-top: calc(var(--spacing) * 2);
  }
  .pr-2 {
    padding-right: calc(var(--spacing) * 2);
  }
  .pr-8 {
    padding-right: calc(var(--spacing) * 8);
  }
  .pb-2 {
    padding-bottom: calc(var(--spacing) * 2);
  }
  .pl-1\\.5 {
    padding-left: calc(var(--spacing) * 1.5);
  }
  .pl-2 {
    padding-left: calc(var(--spacing) * 2);
  }
  .text-center {
    text-align: center;
  }
  .text-base {
    font-size: var(--text-base);
    line-height: var(--tw-leading, var(--text-base--line-height));
  }
  .text-sm {
    font-size: var(--text-sm);
    line-height: var(--tw-leading, var(--text-sm--line-height));
  }
  .text-xs {
    font-size: var(--text-xs);
    line-height: var(--tw-leading, var(--text-xs--line-height));
  }
  .text-\\[0\\.8rem\\] {
    font-size: 0.8rem;
  }
  .font-medium {
    --tw-font-weight: var(--font-weight-medium);
    font-weight: var(--font-weight-medium);
  }
  .font-normal {
    --tw-font-weight: var(--font-weight-normal);
    font-weight: var(--font-weight-normal);
  }
  .whitespace-nowrap {
    white-space: nowrap;
  }
  .text-destructive {
    color: var(--color-destructive);
  }
  .text-foreground {
    color: var(--color-foreground);
  }
  .text-muted-foreground {
    color: var(--color-muted-foreground);
  }
  .text-popover-foreground {
    color: var(--color-popover-foreground);
  }
  .text-primary {
    color: var(--color-primary);
  }
  .text-primary-foreground {
    color: var(--color-primary-foreground);
  }
  .text-secondary-foreground {
    color: var(--color-secondary-foreground);
  }
  .italic {
    font-style: italic;
  }
  .underline-offset-4 {
    text-underline-offset: 4px;
  }
  .opacity-50 {
    opacity: 50%;
  }
  .shadow-md {
    --tw-shadow: 0 4px 6px -1px var(--tw-shadow-color, rgb(0 0 0 / 0.1)), 0 2px 4px -2px var(--tw-shadow-color, rgb(0 0 0 / 0.1));
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .shadow-none {
    --tw-shadow: 0 0 #0000;
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .ring-0 {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .ring-1 {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .ring-foreground\\/10 {
    --tw-ring-color: var(--color-foreground);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-foreground) 10%, transparent);
    }
  }
  .outline-hidden {
    --tw-outline-style: none;
    outline-style: none;
    @media (forced-colors: active) {
      outline: 2px solid transparent;
      outline-offset: 2px;
    }
  }
  .outline {
    outline-style: var(--tw-outline-style);
    outline-width: 1px;
  }
  .blur {
    --tw-blur: blur(8px);
    filter: var(--tw-blur,) var(--tw-brightness,) var(--tw-contrast,) var(--tw-grayscale,) var(--tw-hue-rotate,) var(--tw-invert,) var(--tw-saturate,) var(--tw-sepia,) var(--tw-drop-shadow,);
  }
  .filter {
    filter: var(--tw-blur,) var(--tw-brightness,) var(--tw-contrast,) var(--tw-grayscale,) var(--tw-hue-rotate,) var(--tw-invert,) var(--tw-saturate,) var(--tw-sepia,) var(--tw-drop-shadow,);
  }
  .\\!transition {
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to, opacity, box-shadow, transform, translate, scale, rotate, filter, -webkit-backdrop-filter, backdrop-filter, display, content-visibility, overlay, pointer-events !important;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function)) !important;
    transition-duration: var(--tw-duration, var(--default-transition-duration)) !important;
  }
  .transition {
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to, opacity, box-shadow, transform, translate, scale, rotate, filter, -webkit-backdrop-filter, backdrop-filter, display, content-visibility, overlay, pointer-events;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-all {
    transition-property: all;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .transition-colors {
    transition-property: color, background-color, border-color, outline-color, text-decoration-color, fill, stroke, --tw-gradient-from, --tw-gradient-via, --tw-gradient-to;
    transition-timing-function: var(--tw-ease, var(--default-transition-timing-function));
    transition-duration: var(--tw-duration, var(--default-transition-duration));
  }
  .duration-100 {
    --tw-duration: 100ms;
    transition-duration: 100ms;
  }
  .outline-none {
    --tw-outline-style: none;
    outline-style: none;
  }
  .select-none {
    -webkit-user-select: none;
    user-select: none;
  }
  .group-has-data-\\[slot\\=combobox-clear\\]\\/input-group\\:hidden:is(:where(.group\\/input-group):has([data-slot="combobox-clear"]) *) {
    display: none;
  }
  .group-has-\\[\\>input\\]\\/input-group\\:pt-2:is(:where(.group\\/input-group):has( > input) *) {
    padding-top: calc(var(--spacing) * 2);
  }
  .group-has-\\[\\>input\\]\\/input-group\\:pb-2:is(:where(.group\\/input-group):has( > input) *) {
    padding-bottom: calc(var(--spacing) * 2);
  }
  .group-data-empty\\/combobox-content\\:flex:is(:where(.group\\/combobox-content)[data-empty] *) {
    display: flex;
  }
  .group-data-\\[disabled\\=true\\]\\/input-group\\:opacity-50:is(:where(.group\\/input-group)[data-disabled="true"] *) {
    opacity: 50%;
  }
  .file\\:inline-flex::file-selector-button {
    display: inline-flex;
  }
  .file\\:h-6::file-selector-button {
    height: calc(var(--spacing) * 6);
  }
  .file\\:border-0::file-selector-button {
    border-style: var(--tw-border-style);
    border-width: 0px;
  }
  .file\\:bg-transparent::file-selector-button {
    background-color: transparent;
  }
  .file\\:text-sm::file-selector-button {
    font-size: var(--text-sm);
    line-height: var(--tw-leading, var(--text-sm--line-height));
  }
  .file\\:font-medium::file-selector-button {
    --tw-font-weight: var(--font-weight-medium);
    font-weight: var(--font-weight-medium);
  }
  .file\\:text-foreground::file-selector-button {
    color: var(--color-foreground);
  }
  .placeholder\\:text-muted-foreground::placeholder {
    color: var(--color-muted-foreground);
  }
  .focus-within\\:border-ring:focus-within {
    border-color: var(--color-ring);
  }
  .focus-within\\:ring-3:focus-within {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .focus-within\\:ring-ring\\/50:focus-within {
    --tw-ring-color: var(--color-ring);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-ring) 50%, transparent);
    }
  }
  @media (hover: hover) {
    .hover\\:bg-\\[color-mix\\(in_oklch\\,var\\(--color-secondary\\)\\,var\\(--color-foreground\\)_5\\%\\)\\]:hover {
      background-color: var(--color-secondary);
    }
    @supports (color: color-mix(in lab, red, red)) {
      .hover\\:bg-\\[color-mix\\(in_oklch\\,var\\(--color-secondary\\)\\,var\\(--color-foreground\\)_5\\%\\)\\]:hover {
        background-color: color-mix(in oklch,var(--color-secondary),var(--color-foreground) 5%);
      }
    }
    .hover\\:bg-destructive\\/20:hover {
      background-color: var(--color-destructive);
    }
    @supports (color: color-mix(in lab, red, red)) {
      .hover\\:bg-destructive\\/20:hover {
        background-color: color-mix(in oklab, var(--color-destructive) 20%, transparent);
      }
    }
    .hover\\:bg-muted:hover {
      background-color: var(--color-muted);
    }
    .hover\\:bg-primary\\/80:hover {
      background-color: var(--color-primary);
    }
    @supports (color: color-mix(in lab, red, red)) {
      .hover\\:bg-primary\\/80:hover {
        background-color: color-mix(in oklab, var(--color-primary) 80%, transparent);
      }
    }
    .hover\\:text-foreground:hover {
      color: var(--color-foreground);
    }
    .hover\\:underline:hover {
      text-decoration-line: underline;
    }
    .hover\\:opacity-100:hover {
      opacity: 100%;
    }
  }
  .focus-visible\\:border-destructive\\/40:focus-visible {
    border-color: var(--color-destructive);
    @supports (color: color-mix(in lab, red, red)) {
      border-color: color-mix(in oklab, var(--color-destructive) 40%, transparent);
    }
  }
  .focus-visible\\:border-ring:focus-visible {
    border-color: var(--color-ring);
  }
  .focus-visible\\:ring-0:focus-visible {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .focus-visible\\:ring-3:focus-visible {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .focus-visible\\:ring-destructive\\/20:focus-visible {
    --tw-ring-color: var(--color-destructive);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-destructive) 20%, transparent);
    }
  }
  .focus-visible\\:ring-ring\\/50:focus-visible {
    --tw-ring-color: var(--color-ring);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-ring) 50%, transparent);
    }
  }
  .active\\:not-aria-\\[haspopup\\]\\:translate-y-px:active:not([aria-haspopup]) {
    --tw-translate-y: 1px;
    translate: var(--tw-translate-x) var(--tw-translate-y);
  }
  .disabled\\:pointer-events-none:disabled {
    pointer-events: none;
  }
  .disabled\\:cursor-not-allowed:disabled {
    cursor: not-allowed;
  }
  .disabled\\:bg-input\\/50:disabled {
    background-color: var(--color-input);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-input) 50%, transparent);
    }
  }
  .disabled\\:bg-transparent:disabled {
    background-color: transparent;
  }
  .disabled\\:opacity-50:disabled {
    opacity: 50%;
  }
  :where([data-slot="button-group"]) .in-data-\\[slot\\=button-group\\]\\:rounded-lg {
    border-radius: var(--radius);
  }
  :where([data-slot="combobox-content"]) .in-data-\\[slot\\=combobox-content\\]\\:focus-within\\:border-inherit:focus-within {
    border-color: inherit;
  }
  :where([data-slot="combobox-content"]) .in-data-\\[slot\\=combobox-content\\]\\:focus-within\\:ring-0:focus-within {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .has-disabled\\:pointer-events-none:has(:disabled) {
    pointer-events: none;
  }
  .has-disabled\\:cursor-not-allowed:has(:disabled) {
    cursor: not-allowed;
  }
  .has-disabled\\:bg-input\\/50:has(:disabled) {
    background-color: var(--color-input);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-input) 50%, transparent);
    }
  }
  .has-disabled\\:opacity-50:has(:disabled) {
    opacity: 50%;
  }
  .has-aria-invalid\\:border-destructive:has([aria-invalid="true"]) {
    border-color: var(--color-destructive);
  }
  .has-aria-invalid\\:ring-3:has([aria-invalid="true"]) {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .has-aria-invalid\\:ring-destructive\\/20:has([aria-invalid="true"]) {
    --tw-ring-color: var(--color-destructive);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-destructive) 20%, transparent);
    }
  }
  .has-data-\\[icon\\=inline-end\\]\\:pr-1\\.5:has([data-icon="inline-end"]) {
    padding-right: calc(var(--spacing) * 1.5);
  }
  .has-data-\\[icon\\=inline-end\\]\\:pr-2:has([data-icon="inline-end"]) {
    padding-right: calc(var(--spacing) * 2);
  }
  .has-data-\\[icon\\=inline-start\\]\\:pl-1\\.5:has([data-icon="inline-start"]) {
    padding-left: calc(var(--spacing) * 1.5);
  }
  .has-data-\\[icon\\=inline-start\\]\\:pl-2:has([data-icon="inline-start"]) {
    padding-left: calc(var(--spacing) * 2);
  }
  .has-data-\\[slot\\=combobox-chip\\]\\:px-1:has([data-slot="combobox-chip"]) {
    padding-inline: var(--spacing);
  }
  .has-data-\\[slot\\=combobox-chip-remove\\]\\:pr-0:has([data-slot="combobox-chip-remove"]) {
    padding-right: 0px;
  }
  .has-\\[\\[data-slot\\=input-group-control\\]\\:focus-visible\\]\\:border-ring:has(:is([data-slot=input-group-control]:focus-visible)) {
    border-color: var(--color-ring);
  }
  .has-\\[\\[data-slot\\=input-group-control\\]\\:focus-visible\\]\\:ring-3:has(:is([data-slot=input-group-control]:focus-visible)) {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .has-\\[\\[data-slot\\=input-group-control\\]\\:focus-visible\\]\\:ring-ring\\/50:has(:is([data-slot=input-group-control]:focus-visible)) {
    --tw-ring-color: var(--color-ring);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-ring) 50%, transparent);
    }
  }
  .has-\\[\\[data-slot\\]\\[aria-invalid\\=true\\]\\]\\:border-destructive:has(:is([data-slot][aria-invalid=true])) {
    border-color: var(--color-destructive);
  }
  .has-\\[\\[data-slot\\]\\[aria-invalid\\=true\\]\\]\\:ring-3:has(:is([data-slot][aria-invalid=true])) {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .has-\\[\\[data-slot\\]\\[aria-invalid\\=true\\]\\]\\:ring-destructive\\/20:has(:is([data-slot][aria-invalid=true])) {
    --tw-ring-color: var(--color-destructive);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-destructive) 20%, transparent);
    }
  }
  .has-\\[\\>\\[data-align\\=block-end\\]\\]\\:h-auto:has( > [data-align=block-end]) {
    height: auto;
  }
  .has-\\[\\>\\[data-align\\=block-end\\]\\]\\:flex-col:has( > [data-align=block-end]) {
    flex-direction: column;
  }
  .has-\\[\\>\\[data-align\\=block-start\\]\\]\\:h-auto:has( > [data-align=block-start]) {
    height: auto;
  }
  .has-\\[\\>\\[data-align\\=block-start\\]\\]\\:flex-col:has( > [data-align=block-start]) {
    flex-direction: column;
  }
  .has-\\[\\>button\\]\\:mr-\\[-0\\.3rem\\]:has( > button) {
    margin-right: -0.3rem;
  }
  .has-\\[\\>button\\]\\:ml-\\[-0\\.3rem\\]:has( > button) {
    margin-left: -0.3rem;
  }
  .has-\\[\\>kbd\\]\\:mr-\\[-0\\.15rem\\]:has( > kbd) {
    margin-right: -0.15rem;
  }
  .has-\\[\\>kbd\\]\\:ml-\\[-0\\.15rem\\]:has( > kbd) {
    margin-left: -0.15rem;
  }
  .has-\\[\\>svg\\]\\:p-0:has( > svg) {
    padding: 0px;
  }
  .has-\\[\\>textarea\\]\\:h-auto:has( > textarea) {
    height: auto;
  }
  .aria-expanded\\:bg-muted[aria-expanded="true"] {
    background-color: var(--color-muted);
  }
  .aria-expanded\\:bg-secondary[aria-expanded="true"] {
    background-color: var(--color-secondary);
  }
  .aria-expanded\\:text-foreground[aria-expanded="true"] {
    color: var(--color-foreground);
  }
  .aria-expanded\\:text-secondary-foreground[aria-expanded="true"] {
    color: var(--color-secondary-foreground);
  }
  .aria-invalid\\:border-destructive[aria-invalid="true"] {
    border-color: var(--color-destructive);
  }
  .aria-invalid\\:ring-0[aria-invalid="true"] {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .aria-invalid\\:ring-3[aria-invalid="true"] {
    --tw-ring-shadow: var(--tw-ring-inset,) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color, currentcolor);
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  .aria-invalid\\:ring-destructive\\/20[aria-invalid="true"] {
    --tw-ring-color: var(--color-destructive);
    @supports (color: color-mix(in lab, red, red)) {
      --tw-ring-color: color-mix(in oklab, var(--color-destructive) 20%, transparent);
    }
  }
  .data-disabled\\:pointer-events-none[data-disabled] {
    pointer-events: none;
  }
  .data-disabled\\:opacity-50[data-disabled] {
    opacity: 50%;
  }
  .data-empty\\:p-0[data-empty] {
    padding: 0px;
  }
  .data-highlighted\\:bg-accent[data-highlighted] {
    background-color: var(--color-accent);
  }
  .data-highlighted\\:text-accent-foreground[data-highlighted] {
    color: var(--color-accent-foreground);
  }
  :is(.not-data-\\[variant\\=destructive\\]\\:data-highlighted\\:\\*\\*\\:text-accent-foreground:not([data-variant="destructive"])[data-highlighted] *) {
    color: var(--color-accent-foreground);
  }
  .data-pressed\\:bg-transparent[data-pressed] {
    background-color: transparent;
  }
  .data-\\[chips\\=true\\]\\:min-w-\\(--anchor-width\\)[data-chips="true"] {
    min-width: var(--anchor-width);
  }
  :is(.\\*\\:data-\\[slot\\=input-group\\]\\:m-1 > *)[data-slot="input-group"] {
    margin: var(--spacing);
  }
  :is(.\\*\\:data-\\[slot\\=input-group\\]\\:mb-0 > *)[data-slot="input-group"] {
    margin-bottom: 0px;
  }
  :is(.\\*\\:data-\\[slot\\=input-group\\]\\:h-8 > *)[data-slot="input-group"] {
    height: calc(var(--spacing) * 8);
  }
  :is(.\\*\\:data-\\[slot\\=input-group\\]\\:border-input\\/30 > *)[data-slot="input-group"] {
    border-color: var(--color-input);
    @supports (color: color-mix(in lab, red, red)) {
      border-color: color-mix(in oklab, var(--color-input) 30%, transparent);
    }
  }
  :is(.\\*\\:data-\\[slot\\=input-group\\]\\:bg-input\\/30 > *)[data-slot="input-group"] {
    background-color: var(--color-input);
    @supports (color: color-mix(in lab, red, red)) {
      background-color: color-mix(in oklab, var(--color-input) 30%, transparent);
    }
  }
  :is(.\\*\\:data-\\[slot\\=input-group\\]\\:shadow-none > *)[data-slot="input-group"] {
    --tw-shadow: 0 0 #0000;
    box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow);
  }
  @media (width >= 48rem) {
    .md\\:text-sm {
      font-size: var(--text-sm);
      line-height: var(--tw-leading, var(--text-sm--line-height));
    }
  }
  .\\[\\&_svg\\]\\:pointer-events-none svg {
    pointer-events: none;
  }
  .\\[\\&_svg\\]\\:shrink-0 svg {
    flex-shrink: 0;
  }
  .\\[\\&_svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-3 svg:not([class*='size-']) {
    width: calc(var(--spacing) * 3);
    height: calc(var(--spacing) * 3);
  }
  .\\[\\&_svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-3\\.5 svg:not([class*='size-']) {
    width: calc(var(--spacing) * 3.5);
    height: calc(var(--spacing) * 3.5);
  }
  .\\[\\&_svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-4 svg:not([class*='size-']) {
    width: calc(var(--spacing) * 4);
    height: calc(var(--spacing) * 4);
  }
  .\\[\\.border-b\\]\\:pb-2:is(.border-b) {
    padding-bottom: calc(var(--spacing) * 2);
  }
  .\\[\\.border-t\\]\\:pt-2:is(.border-t) {
    padding-top: calc(var(--spacing) * 2);
  }
  .has-\\[\\>\\[data-align\\=block-end\\]\\]\\:\\[\\&\\>input\\]\\:pt-3:has( > [data-align=block-end]) > input {
    padding-top: calc(var(--spacing) * 3);
  }
  .has-\\[\\>\\[data-align\\=block-start\\]\\]\\:\\[\\&\\>input\\]\\:pb-3:has( > [data-align=block-start]) > input {
    padding-bottom: calc(var(--spacing) * 3);
  }
  .has-\\[\\>\\[data-align\\=inline-end\\]\\]\\:\\[\\&\\>input\\]\\:pr-1\\.5:has( > [data-align=inline-end]) > input {
    padding-right: calc(var(--spacing) * 1.5);
  }
  .has-\\[\\>\\[data-align\\=inline-start\\]\\]\\:\\[\\&\\>input\\]\\:pl-1\\.5:has( > [data-align=inline-start]) > input {
    padding-left: calc(var(--spacing) * 1.5);
  }
  .\\[\\&\\>kbd\\]\\:rounded-\\[calc\\(var\\(--radius\\)-5px\\)\\] > kbd {
    border-radius: calc(var(--radius) - 5px);
  }
  .\\[\\&\\>svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-3\\.5 > svg:not([class*='size-']) {
    width: calc(var(--spacing) * 3.5);
    height: calc(var(--spacing) * 3.5);
  }
  .\\[\\&\\>svg\\:not\\(\\[class\\*\\=\\'size-\\'\\]\\)\\]\\:size-4 > svg:not([class*='size-']) {
    width: calc(var(--spacing) * 4);
    height: calc(var(--spacing) * 4);
  }
}
@layer base {
  :is(:where([class^='jgis-'], [class*=' jgis-'], [data-slot])), :where([class^='jgis-'], [class*=' jgis-'], [data-slot])  *, :where([class^='jgis-'], [class*=' jgis-'], [data-slot])::before, :where([class^='jgis-'], [class*=' jgis-'], [data-slot])::after, :where([class^='jgis-'], [class*=' jgis-'], [data-slot])  *::before, :where([class^='jgis-'], [class*=' jgis-'], [data-slot])  *::after {
    box-sizing: border-box;
  }
}
@property --tw-rotate-x {
  syntax: "*";
  inherits: false;
}
@property --tw-rotate-y {
  syntax: "*";
  inherits: false;
}
@property --tw-rotate-z {
  syntax: "*";
  inherits: false;
}
@property --tw-skew-x {
  syntax: "*";
  inherits: false;
}
@property --tw-skew-y {
  syntax: "*";
  inherits: false;
}
@property --tw-border-style {
  syntax: "*";
  inherits: false;
  initial-value: solid;
}
@property --tw-font-weight {
  syntax: "*";
  inherits: false;
}
@property --tw-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-shadow-color {
  syntax: "*";
  inherits: false;
}
@property --tw-shadow-alpha {
  syntax: "<percentage>";
  inherits: false;
  initial-value: 100%;
}
@property --tw-inset-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-inset-shadow-color {
  syntax: "*";
  inherits: false;
}
@property --tw-inset-shadow-alpha {
  syntax: "<percentage>";
  inherits: false;
  initial-value: 100%;
}
@property --tw-ring-color {
  syntax: "*";
  inherits: false;
}
@property --tw-ring-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-inset-ring-color {
  syntax: "*";
  inherits: false;
}
@property --tw-inset-ring-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-ring-inset {
  syntax: "*";
  inherits: false;
}
@property --tw-ring-offset-width {
  syntax: "<length>";
  inherits: false;
  initial-value: 0px;
}
@property --tw-ring-offset-color {
  syntax: "*";
  inherits: false;
  initial-value: #fff;
}
@property --tw-ring-offset-shadow {
  syntax: "*";
  inherits: false;
  initial-value: 0 0 #0000;
}
@property --tw-outline-style {
  syntax: "*";
  inherits: false;
  initial-value: solid;
}
@property --tw-blur {
  syntax: "*";
  inherits: false;
}
@property --tw-brightness {
  syntax: "*";
  inherits: false;
}
@property --tw-contrast {
  syntax: "*";
  inherits: false;
}
@property --tw-grayscale {
  syntax: "*";
  inherits: false;
}
@property --tw-hue-rotate {
  syntax: "*";
  inherits: false;
}
@property --tw-invert {
  syntax: "*";
  inherits: false;
}
@property --tw-opacity {
  syntax: "*";
  inherits: false;
}
@property --tw-saturate {
  syntax: "*";
  inherits: false;
}
@property --tw-sepia {
  syntax: "*";
  inherits: false;
}
@property --tw-drop-shadow {
  syntax: "*";
  inherits: false;
}
@property --tw-drop-shadow-color {
  syntax: "*";
  inherits: false;
}
@property --tw-drop-shadow-alpha {
  syntax: "<percentage>";
  inherits: false;
  initial-value: 100%;
}
@property --tw-drop-shadow-size {
  syntax: "*";
  inherits: false;
}
@property --tw-duration {
  syntax: "*";
  inherits: false;
}
@property --tw-translate-x {
  syntax: "*";
  inherits: false;
  initial-value: 0;
}
@property --tw-translate-y {
  syntax: "*";
  inherits: false;
  initial-value: 0;
}
@property --tw-translate-z {
  syntax: "*";
  inherits: false;
  initial-value: 0;
}
@layer properties {
  @supports ((-webkit-hyphens: none) and (not (margin-trim: inline))) or ((-moz-orient: inline) and (not (color:rgb(from red r g b)))) {
    *, ::before, ::after, ::backdrop {
      --tw-rotate-x: initial;
      --tw-rotate-y: initial;
      --tw-rotate-z: initial;
      --tw-skew-x: initial;
      --tw-skew-y: initial;
      --tw-border-style: solid;
      --tw-font-weight: initial;
      --tw-shadow: 0 0 #0000;
      --tw-shadow-color: initial;
      --tw-shadow-alpha: 100%;
      --tw-inset-shadow: 0 0 #0000;
      --tw-inset-shadow-color: initial;
      --tw-inset-shadow-alpha: 100%;
      --tw-ring-color: initial;
      --tw-ring-shadow: 0 0 #0000;
      --tw-inset-ring-color: initial;
      --tw-inset-ring-shadow: 0 0 #0000;
      --tw-ring-inset: initial;
      --tw-ring-offset-width: 0px;
      --tw-ring-offset-color: #fff;
      --tw-ring-offset-shadow: 0 0 #0000;
      --tw-outline-style: solid;
      --tw-blur: initial;
      --tw-brightness: initial;
      --tw-contrast: initial;
      --tw-grayscale: initial;
      --tw-hue-rotate: initial;
      --tw-invert: initial;
      --tw-opacity: initial;
      --tw-saturate: initial;
      --tw-sepia: initial;
      --tw-drop-shadow: initial;
      --tw-drop-shadow-color: initial;
      --tw-drop-shadow-alpha: 100%;
      --tw-drop-shadow-size: initial;
      --tw-duration: initial;
      --tw-translate-x: 0;
      --tw-translate-y: 0;
      --tw-translate-z: 0;
    }
  }
}
`,""]),e.d(r,{},{A:n})},3301(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a)()(i());n.push([o.id,`.jp-gis-temporal-slider-container {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  padding: 0.5rem;
  background-color: var(--jp-layout-color1);
  border-bottom: 1px solid var(--jp-border-color1);
  z-index: 99;
}

.jp-gis-temporal-slider-container span,
.jp-gis-temporal-slider-container label {
  font-weight: bold;
}

.jp-gis-temporal-slider-row {
  display: flex;
  gap: 0.25rem;
  justify-content: space-between;
  align-items: center;
}

.jp-gis-temporal-slider-controls {
  display: flex;
  flex-grow: 1;
  justify-content: space-around;
}

.jp-gis-temporal-slider-sub-controls {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0.25rem;
}

.jp-gis-temporal-slider-sub-controls > input {
  width: 35px;
}

select,
select option {
  text-transform: capitalize;
}

.jp-gis-temporal-slider {
  flex: 1 0 40%;
  min-width: 300px;
}
`,""]),e.d(r,{},{A:n})},4296(o,r,e){var t=e(6758),i=e.n(t),a=e(935),n=e.n(a),s=e(1378),l=e(62),d=e.n(l),p=new URL(e(7248),e.b),c=n()(i());c.i(s.A);var g=d()(p);c.push([o.id,`.jGIS-Spinner {
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  outline: none;
  background: #00000075;
}

.jGIS-SpinnerContent {
  border: solid #f376269e;
  margin: 50px auto;
  text-indent: -9999em;
  width: 6em;
  height: 6em;
  border-radius: 50%;
  position: relative;
  animation:
    load3 1s infinite linear,
    fadeIn 1s;
}

.jGIS-SpinnerContent:before {
  width: 50%;
  height: 50%;
  background: #f3762605;
  border-radius: 100% 0 100% 0;
  box-shadow: inset 6px 5px 0 1px #f37626;
  position: absolute;
  top: 0;
  left: 0;
  content: '';
}

.jGIS-SpinnerContent:after {
  width: 75%;
  height: 75%;
  border-radius: 50%;
  content: '';
  margin: auto;
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
}

.jGIS-camera-client {
  width: 15px;
  height: 15px;
  position: absolute;
  z-index: 10;
  background-color: var(--jp-private-notebook-active-color);
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.jGIS-control-panel {
  color: var(--jp-ui-font-color1);
  background: var(--jp-layout-color1);
  height: 100%;
}

.jGIS-control-panel * {
  font-family: var(--jp-ui-font-family);
}

.jGIS-control-panel-title {
  border-bottom: solid var(--jp-border-width) var(--jp-border-color1);
  box-shadow: var(--jp-toolbar-box-shadow);
  display: flex;
  flex-direction: row;
  align-items: center;
  min-height: 24px;
  height: var(--jp-debugger-header-height);
  background-color: var(--jp-layout-color2);
}

.jGIS-control-panel-title h2 {
  text-transform: uppercase;
  font-weight: 600;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color1);
  padding-left: 8px;
  padding-right: 4px;
}

.jGIS-sidepanel-widget {
  overflow: auto;
  height: 100%;
}

.jGIS-sidebar-treepanel {
  display: flex;
  flex-direction: column;
  min-height: 50px;
  padding-top: 3px;
}

.jGIS-sidebar-propertiespanel {
  display: flex;
  flex-direction: column;
  min-height: 50px;
  padding-top: 3px;
}

.jGIS-treeview-wrapper {
  overflow: auto;
  height: 100%;
}

.jGIS-treeview-wrapper > div {
  padding: 0 !important;
}
/* TODO: More robust selector */
.jGIS-treeview-wrapper div[style*='align-items: center;']:first-of-type {
  flex-grow: 1;
}

.jGIS-control-panel-tree {
  flex-grow: 1;
}

.jGIS-sidebar-propertiespanel > div {
  overflow: auto;
}

.jGIS-property-outer {
  padding: 10px;
  flex-grow: 1;
  overflow: auto;
}

.jGIS-property-buttons {
  display: flex;
  justify-content: end;
  padding: 10px;
}

.jGIS-property-panel {
  display: flex;
  flex-flow: column;
  height: 100%;
  overflow: hidden;
}

.jGIS-hidden-field {
  display: none;
}

div.field.field-array > label + span {
  display: none;
}

.jGIS-layer-CreationFormDialog .jp-Dialog-content {
  width: 60%;
}

.jGIS-layer-CreationFormDialog form {
  padding: 10px;
}

/* TODO Upstream this to jupyterlab jrfs */
.jGIS-property-panel .rjsf .control-label,
.jGIS-property-panel .rjsf legend {
  position: inherit;
  text-transform: capitalize;
}

div.jGIS-toolbar-widget > div.jp-Toolbar-item:last-child {
  flex-grow: 1;
}

.jGIS-toolbar-usertoolbar {
  flex-grow: 1;
  display: flex;
  flex-direction: row-reverse;
}
.jGIS-toolbar-react-widget {
  display: flex;
  flex-direction: row;
  align-items: center;
  flex-grow: 1;
}

.jGIS-Toolbar-Separator {
  min-height: 25px;
  width: var(--jp-border-width);
  background-color: var(--jp-border-color1);
  padding-left: 0px !important;
  padding-right: 0px !important;
}

.jGIS-toolbar-usertoolbar .jp-MenuBar-anonymousIcon,
.jGIS-toolbar-usertoolbar .jp-MenuBar-imageIcon {
  position: unset !important;
  margin-right: 2px;
  height: 22px;
  box-sizing: border-box;
}

.jGIS-toolbar-usertoolbar .jp-MenuBar-anonymousIcon.selected,
.jGIS-toolbar-usertoolbar .jp-MenuBar-imageIcon.selected {
  border: solid 1.5px red;
}

.jGIS-toolbar-widget svg path {
  fill: var(--jp-ui-font-color2) !important;
}
.jGIS-toolbar-widget .fa {
  color: var(--jp-ui-font-color2) !important;
}
.jGIS-toolbar-widget svg .jp-icon-accent1 {
  fill: #ffffff !important;
}

.jGIS-Mainview-Container {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.jGIS-Mainview {
  width: 100%;
  box-sizing: border-box;
  flex: 1;
  position: relative;
  display: flex;
}

.jGIS-Popup-Wrapper {
  position: absolute;
  opacity: 1;
  transition: opacity 0.1s linear 0.15s;
  z-index: 40;
}

.jGIS-Annotation {
  z-index: 1;
  margin-left: 1px;
  margin-top: 1px;
  padding: 1em;
  color: var(--jp-ui-font-color0);
  background: var(--jp-layout-color1);
  border-radius: 0.5em;
  font-size: 12px;
  line-height: 1.2;
  transition: opacity 0.5s;
}

.jGIS-FloatingAnnotation {
  position: absolute;
  width: 250px;
  box-shadow: var(--jp-elevation-z6);
  z-index: 40;
  max-height: 400px;
  overflow: auto;
}

.jGIS-FeatureFloater {
  min-width: 180px;
  max-width: 300px;
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
  padding: 0.5rem;
  border-radius: 0.375rem;
  border: 1px solid var(--jp-border-color1);
  background: var(--jp-layout-color1);
  box-shadow: var(--jp-elevation-z6);
}

.jGIS-FeatureFloater-Wrapper {
  transform: translate(10px, calc(-100% - 10px));
}

.jGIS-FeatureFloater-title {
  font-weight: 700;
  margin-bottom: 0.25rem;
  padding-bottom: 0.25rem;
  border-bottom: 1px solid var(--jp-border-color2);
}

.jGIS-FeatureFloater-row {
  display: flex;
  gap: 0.375rem;
  align-items: flex-start;
}

.jGIS-FeatureFloater-key {
  flex: 0 0 auto;
  font-weight: 600;
}

.jGIS-FeatureFloater-value {
  min-width: 0;
  overflow-wrap: anywhere;
}

.jGIS-Annotation-Card {
  max-height: 400px;
  overflow: auto;
}

.jGIS-Annotations-Separator {
  border-color: var(--jp-layout-color4);
  border-style: solid;
  border-width: 1px;
}

.jGIS-Annotation-Handler {
  position: absolute;
  top: -5px;
  left: -5px;
  width: 8px;
  height: 8px;
  border: 1px solid #ffffffc2;
  border-radius: 50%;
  background: rgb(0 0 0 / 63%);
  cursor: pointer;
  transition-property: width, height, left, top;
  transition-duration: 0.2s;
  z-index: 20;
}

.jGIS-Annotation-Handler:hover {
  top: -9px;
  left: -9px;
  width: 16px;
  height: 16px;
}

.jGIS-Annotation-Message {
  display: flex;
  margin-top: 10px;
  gap: 5px;
  align-items: center;
  justify-content: center;
}

.jGIS-Annotation-Message .jGIS-Annotation-User-Icon {
  border-radius: 100%;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  vertical-align: middle;
  color: var(--jp-ui-font-color1);
}

.jGIS-Annotation-Message textarea {
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color2);
  flex-grow: 1;
  resize: none;
  border: none;
  padding: 0.5em;
  outline: thin solid var(--jp-border-color0);
}

.jGIS-Annotation-Message-Content {
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color2);
  border-radius: var(--jp-border-radius);
  flex-grow: 1;
}

.jGIS-Popup-Topbar {
  display: flex;
  flex-direction: row-reverse;
}

.jGIS-Popup-TopBarIcon {
  cursor: pointer;
  transform: rotate(180deg);
}

.jGIS-Annotation-Submit > svg {
  width: 30px;
  height: 30px;
}

.jGIS-Annotation-Submit g {
  fill: #f6f7f8 !important;
}

.jGIS-Annotation-Submit:hover {
  opacity: 70%;
  cursor: pointer;
}

.jGIS-Annotation-Submit {
  background-color: var(--jp-brand-color1);
  border-radius: 100%;
  width: 30px;
  height: 30px;
}

.jGIS-Annotation-Buttons {
  display: flex;
  justify-content: space-around;
  padding-top: 1em;
}

.jGIS-Annotation-Buttons > button {
  border-radius: var(--jp-border-radius);
  flex-grow: 1;
  max-width: 68px;
}

.jGIS-Remote-Pointer {
  position: absolute;
  transition-property: left, top, width, height;
  transition-duration: 150ms;
  transition-timing-function: ease;
  z-index: 20;
}

.jGIS-Remote-Pointer-Icon {
  filter: drop-shadow(-1px 0px white) drop-shadow(1px 0px white)
    drop-shadow(0px -1px white) drop-shadow(0px 1px white)
    drop-shadow(0px 0px 1px black);
}
.jGIS-Remote-Pointer-Icon:hover {
  scale: 1.3;
}

.jGIS-Floating-Pointer-Popup {
  position: absolute;
  width: 160px;
  box-shadow: var(--jp-elevation-z6);
  z-index: 40;
  max-height: 400px;
  overflow: auto;
}

.jGIS-Remote-Pointer-Popup {
  margin-left: 7px;
  margin-top: 14px;
  color: #fff;
  padding: 1em;
  border-radius: 0.5em;
  font-size: 12px;
  line-height: 1.2;
}

.jGIS-Remote-Pointer-Popup-Name {
  font-size: 16px;
  color: #333;
}

.jGIS-Remote-Pointer-Popup-Coordinates {
  font-size: 14px;
}

/* Hack to remove the malformed form button */
.object-property-expand {
  display: none;
}

.highlight {
  background-color: var(--jp-layout-color2) !important;
}
.jupytergis-notebook-widget {
  height: 600px;
  width: 100%;
}

/* Support output views, created with "Create new view for cell output" context menu */
.jp-LinkedOutputView .jp-OutputArea-child:only-child {
  /* NOTE: This will eventually be supported directly in JupyterLab
   * (https://github.com/jupyterlab/jupyterlab/pull/17487), but we should keep
   * it around for a while for backwards compatibility. */
  height: 100%;
}
.jp-LinkedOutputView .jupytergis-notebook-widget {
  height: 100%;
}

.jupytergis-notebook-widget > div {
  height: 100%;
  width: 100%;
}

.jGIS-property-panel .rjsf .control-label,
.jGIS-property-panel .rjsf legend {
  width: 100%;
}

.jpgis-console {
  border-top: var(--jp-border-width) solid var(--jp-toolbar-border-color);
}

.jpgis-console .jp-CodeConsole-banner {
  display: none;
}

/* FormComponent CSS */
.jGIS-property-panel .rjsf {
  color: var(--jp-ui-font-color1);
}

.jGIS-property-panel .rjsf > form {
  padding: var(--jp-ui-font-size1);
}

.jGIS-property-panel .rjsf fieldset {
  border: 0;
  margin: 0;
  padding: 0;
}

.jGIS-property-panel .rjsf button[type='submit'] {
  display: none;
}

.jGIS-property-panel .rjsf legend > :first-child,
.jGIS-property-panel .rjsf .control-label > :first-child {
  margin-top: 0;
  padding-top: 0;
}

.jGIS-property-panel .rjsf .form-group .form-group {
  margin-bottom: var(--jp-ui-font-size1);
}

.jGIS-property-panel .rjsf .form-group:last-child {
  margin-bottom: 0;
}

.jGIS-property-panel .rjsf .jp-FormGroup-description,
.jGIS-property-panel .rjsf .field-description,
.jGIS-property-panel .rjsf .help-block {
  color: var(--jp-ui-font-color2);
  margin-top: 2px;
  margin-bottom: 2px;
}

.jGIS-property-panel
  .jp-FormGroup-content
  fieldset
  .jp-inputFieldWrapper
  > input,
.jGIS-property-panel
  .jp-FormGroup-content
  fieldset
  .jp-inputFieldWrapper
  > textarea {
  box-sizing: border-box;
  border: var(--jp-border-width) solid var(--jp-border-color1);
  background-color: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  font-size: var(--jp-ui-font-size2);
  min-width: 0;
  outline: none !important;
  padding: 2px 7px;
  width: 100%;
  max-width: 100%;
}

.jGIS-property-panel
  .jp-FormGroup-content
  fieldset
  .jp-inputFieldWrapper
  > input#root_Color,
.jGIS-property-panel
  .jp-FormGroup-content
  fieldset
  .jp-inputFieldWrapper
  > input#root_shadowColor {
  height: revert;
}

.jGIS-property-panel .jp-FormGroup-contentNormal {
  display: flex;
  flex-direction: column;
  align-items: inherit;
}

.jGIS-property-panel .jp-FormGroup-contentNormal .jp-FormGroup-fieldLabel {
  font-weight: bold;
  order: 1;
  margin-top: 2px;
  margin-bottom: 2px;
  text-transform: capitalize;
}

.jGIS-property-panel
  .jp-FormGroup-content
  .jp-FormGroup-contentNormal
  .jp-FormGroup-description,
.jGIS-property-panel .field-description {
  order: 2;
  color: var(--jp-ui-font-color2);
}

.jGIS-property-panel .jp-FormGroup-content .jp-inputFieldWrapper {
  order: 3;
}

.jGIS-property-panel .jp-FormGroup-contentNormal .validationErrors,
.jGIS-property-panel .jp-FormGroup-contentNormal .validationErrors ul {
  order: 4;
  list-style: none;
  color: var(--jp-warn-color0);
  margin: 0;
  padding: 0;
}

.jGIS-property-panel .array-item {
  border: none;
}

.jGIS-property-panel
  .jp-FormGroup-content
  .jp-FormGroup-contentNormal
  .jp-arrayFieldWrapper
  + .jp-FormGroup-description {
  display: none;
}

.jGIS-property-panel .rjsf .errors ul,
.jGIS-property-panel .rjsf .validationErrors ul,
.jGIS-property-panel .rjsf .validationErrors li,
.jGIS-property-panel .rjsf .errors li {
  list-style: none;
  margin: 0;
  padding: 0;
}

.jGIS-property-panel .rjsf .jp-ArrayOperationsButton {
  display: none;
}

/* Hide additional property fields with remove buttons that should not be displayed in the form */
.jGIS-property-panel
  .form-group:has(.jp-FormGroup-removeButton):not(:has(.jp-root)) {
  display: none;
}

.jGIS-property-panel .jp-arrayFieldWrapper .array-item legend,
.jGIS-property-panel
  .jp-arrayFieldWrapper
  .field-array-of-array
  .field-array-of-number
  legend,
.jGIS-property-panel
  .jp-arrayFieldWrapper
  .field-array-of-array
  .field-array-of-number
  .jp-FormGroup-fieldLabel {
  display: none;
}
.jGIS-property-panel
  .jp-arrayFieldWrapper
  .field-array-of-array
  .array-item
  .form-group
  .field-array-of-number {
  display: flex;
}

.jGIS-property-panel
  .jp-arrayFieldWrapper
  .field-array-of-array
  .array-item
  .form-group
  .field-array-of-number
  > div:nth-child(1) {
  order: 2;
}

.jGIS-property-panel
  .jp-arrayFieldWrapper
  .field-array-of-array
  .array-item
  .form-group
  .field-array-of-number
  > div:nth-child(2) {
  order: 1;
}

.jGIS-property-panel .required {
  font-size: var(--jp-ui-font-size3);
  color: var(--jp-warn-color1);
  font-weight: 800;
  position: absolute;
  top: 0;
  right: 0;
  display: block;
}

.jGIS-property-panel
  .jp-FormGroup-content
  fieldset
  .jp-inputFieldWrapper
  select {
  width: 100%;
  font-size: var(--jp-ui-font-size1);
  background: var(--jp-input-background);
  color: var(--jp-ui-font-color0);
  padding: calc(var(--jp-ui-font-size1) / 2);
  padding-right: var(--jp-ui-font-size3);
  background-image: url(${g});
  background-repeat: no-repeat;
  background-position: 99% center;
  background-size: 18px;
  border: var(--jp-border-width) solid var(--jp-input-border-color);
  border-radius: 0;
  outline: none;
  appearance: none;
}

.jGIS-property-panel .jp-select-wrapper select {
  background-image: unset !important;
}

.lm-TabBar-tabIcon .jgis-main-logo[fill] {
  fill: var(--jp-inverse-layout-color3);
}

.jGIS-point-selection-tool {
  cursor: crosshair;
}

.jgis-scrollable {
  overflow: auto;
  height: 100%;
}

/* Style the file path text */
.file-container {
  display: flex;
  align-items: center;
  margin-bottom: 16px;
  gap: 10px;
}

.jp-gis-stop-container-wrapper {
  display: flex;
  flex-direction: row;
  gap: 2rem;
}

.jp-gis-stop-container-wrapper > * {
  flex: 1;
}

.jp-gis-stop-container-wrapper > *:only-child {
  flex: 1 1 100%;
}

.jp-gis-symbology-tabs {
  display: flex;
  border-bottom: 1px solid #ccc;
  margin: 12px 0;
}

.jp-gis-tab {
  flex: 1;
  text-align: center;
  padding: 10px 16px;
  border: none;
  border-bottom: 2px solid transparent;
  cursor: pointer;
  font-size: var(--jp-ui-font-size2);
  color: var(--jp-ui-font-color1);
  background-color: var(--jp-layout-color1);
}

.jp-gis-tab:not(.active):hover {
  background-color: var(--jp-layout-color2);
}

.jp-gis-tab.active {
  background-color: var(--jp-layout-color2);
  color: var(--jp-brand-color1);
  border-bottom: 2px solid var(--jp-brand-color1);
  font-weight: 500;
}

.jp-toolbar-users-item > .lm-MenuBar-itemIcon {
  cursor: pointer !important;
  border: 2px solid transparent;
  border-radius: 50%;
}

.jp-toolbar-users-item > .lm-MenuBar-itemIcon.selected {
  border-color: var(--jp-brand-color1);
}
`,""]),e.d(r,{},{A:c})},935(o){o.exports=function(o){var r=[];return r.toString=function(){return this.map(function(r){var e="",t=void 0!==r[5];return r[4]&&(e+="@supports (".concat(r[4],") {")),r[2]&&(e+="@media ".concat(r[2]," {")),t&&(e+="@layer".concat(r[5].length>0?" ".concat(r[5]):""," {")),e+=o(r),t&&(e+="}"),r[2]&&(e+="}"),r[4]&&(e+="}"),e}).join("")},r.i=function(o,e,t,i,a){"string"==typeof o&&(o=[[null,o,void 0]]);var n={};if(t)for(var s=0;s<this.length;s++){var l=this[s][0];null!=l&&(n[l]=!0)}for(var d=0;d<o.length;d++){var p=[].concat(o[d]);t&&n[p[0]]||(void 0!==a&&(void 0===p[5]||(p[1]="@layer".concat(p[5].length>0?" ".concat(p[5]):""," {").concat(p[1],"}")),p[5]=a),e&&(p[2]&&(p[1]="@media ".concat(p[2]," {").concat(p[1],"}")),p[2]=e),i&&(p[4]?(p[1]="@supports (".concat(p[4],") {").concat(p[1],"}"),p[4]=i):p[4]="".concat(i)),r.push(p))}},r}},62(o){o.exports=function(o,r){return(r||(r={}),o&&(o=String(o.__esModule?o.default:o),/^['"].*['"]$/.test(o)&&(o=o.slice(1,-1)),r.hash&&(o+=r.hash),/["'() \t\n]|(%20)/.test(o)||r.needQuotes))?'"'.concat(o.replace(/"/g,'\\"').replace(/\n/g,"\\n"),'"'):o}},6758(o){o.exports=function(o){return o[1]}},2591(o){var r=[];function e(o){for(var e=-1,t=0;t<r.length;t++)if(r[t].identifier===o){e=t;break}return e}function t(o,t){for(var i={},a=[],n=0;n<o.length;n++){var s=o[n],l=t.base?s[0]+t.base:s[0],d=i[l]||0,p="".concat(l," ").concat(d);i[l]=d+1;var c=e(p),g={css:s[1],media:s[2],sourceMap:s[3],supports:s[4],layer:s[5]};if(-1!==c)r[c].references++,r[c].updater(g);else{var m=function(o,r){var e=r.domAPI(r);return e.update(o),function(r){r?(r.css!==o.css||r.media!==o.media||r.sourceMap!==o.sourceMap||r.supports!==o.supports||r.layer!==o.layer)&&e.update(o=r):e.remove()}}(g,t);t.byIndex=n,r.splice(n,0,{identifier:p,updater:m,references:1})}a.push(p)}return a}o.exports=function(o,i){var a=t(o=o||[],i=i||{});return function(o){o=o||[];for(var n=0;n<a.length;n++){var s=e(a[n]);r[s].references--}for(var l=t(o,i),d=0;d<a.length;d++){var p=e(a[d]);0===r[p].references&&(r[p].updater(),r.splice(p,1))}a=l}}},8128(o){var r={};o.exports=function(o,e){var t=function(o){if(void 0===r[o]){var e=document.querySelector(o);if(window.HTMLIFrameElement&&e instanceof window.HTMLIFrameElement)try{e=e.contentDocument.head}catch(o){e=null}r[o]=e}return r[o]}(o);if(!t)throw Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");t.appendChild(e)}},3051(o){o.exports=function(o){var r=document.createElement("style");return o.setAttributes(r,o.attributes),o.insert(r,o.options),r}},855(o,r,e){o.exports=function(o){var r=e.nc;r&&o.setAttribute("nonce",r)}},1740(o){o.exports=function(o){if("u"<typeof document)return{update:function(){},remove:function(){}};var r=o.insertStyleElement(o);return{update:function(e){var t,i,a;t="",e.supports&&(t+="@supports (".concat(e.supports,") {")),e.media&&(t+="@media ".concat(e.media," {")),(i=void 0!==e.layer)&&(t+="@layer".concat(e.layer.length>0?" ".concat(e.layer):""," {")),t+=e.css,i&&(t+="}"),e.media&&(t+="}"),e.supports&&(t+="}"),(a=e.sourceMap)&&"u">typeof btoa&&(t+="\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(a))))," */")),o.styleTagTransform(t,r,o.options)},remove:function(){var o;null===(o=r).parentNode||o.parentNode.removeChild(o)}}}},3656(o){o.exports=function(o,r){if(r.styleSheet)r.styleSheet.cssText=o;else{for(;r.firstChild;)r.removeChild(r.firstChild);r.appendChild(document.createTextNode(o))}}},8579(o,r,e){var t=e(2591),i=e.n(t),a=e(1740),n=e.n(a),s=e(8128),l=e.n(s),d=e(855),p=e.n(d),c=e(3051),g=e.n(c),m=e(3656),u=e.n(m),b=e(4296),h={};h.styleTagTransform=u(),h.setAttributes=p(),h.insert=l().bind(null,"head"),h.domAPI=n(),h.insertStyleElement=g(),i()(b.A,h),b.A&&b.A.locals&&b.A.locals},7248(o){o.exports="data:image/svg+xml,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%2716%27 viewBox=%270 0 20 20%27%3e %3cg class=%27jp-icon3%27 fill=%27%23616161%27 shape-rendering=%27geometricPrecision%27%3e %3cpolygon class=%27st1%27 points=%279.9%2c13.6 3.6%2c7.4 4.4%2c6.6 9.9%2c12.2 15.4%2c6.7 16.1%2c7.4 %27/%3e %3c/g%3e %3c/svg%3e"}}]);